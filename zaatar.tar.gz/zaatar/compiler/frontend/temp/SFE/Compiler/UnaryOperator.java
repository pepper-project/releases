package SFE.Compiler;

/**
 * Marks operators which are unary.
 */
public interface UnaryOperator {

}
