#include <apps/polyeval_d2_v.h>

PolyEvalD2Verifier::PolyEvalD2Verifier(int batch, int reps, int ip_size,
                                       int optimize_answers, char *prover_url)
  : Verifier(batch, reps, ip_size, optimize_answers, prover_url, NAME_PROVER) {
  init_state();
}

void PolyEvalD2Verifier::init_state() {
  num_bits_in_prime = 128;
  num_bits_in_input = 32;
  crypto_in_use = CRYPTO_ELGAMAL;
  png_in_use = PNG_CHACHA;

  num_lin_pcp_queries = NUM_LIN_PCP_QUERIES_F1 + NUM_LIN_PCP_QUERIES_F2;

  Verifier::init_state();

  num_coefficients = (input_size * input_size + 3*input_size)/2 + 1;

  alloc_init_vec(&coefficients, num_coefficients);
  alloc_init_vec(&input, input_size);
  alloc_init_vec(&f1_commitment, expansion_factor*input_size);
  alloc_init_vec(&f2_commitment, expansion_factor*input_size*input_size);
  alloc_init_vec(&f1_consistency, input_size);
  alloc_init_vec(&f2_consistency, input_size*input_size);

  alloc_init_vec(&f1_con_coins, num_repetitions * NUM_LIN_PCP_QUERIES_F1);
  alloc_init_vec(&f2_con_coins, num_repetitions * NUM_LIN_PCP_QUERIES_F2);

  alloc_init_vec(&f1_q1, input_size);
  alloc_init_vec(&f1_q2, input_size);
  alloc_init_vec(&f1_q3, input_size);
  alloc_init_vec(&f2_q1, input_size*input_size);
  alloc_init_vec(&f2_q2, input_size*input_size);
  alloc_init_vec(&f2_q3, input_size*input_size);
  alloc_init_vec(&alpha, input_size+1);
  alloc_init_vec(&f_answers,
                 num_repetitions * num_lin_pcp_queries);
  alloc_init_vec(&f1_answers, num_repetitions * NUM_LIN_PCP_QUERIES_F1);
  alloc_init_vec(&f2_answers, num_repetitions * NUM_LIN_PCP_QUERIES_F2);
  alloc_init_vec(&ckt_answers, 4);
  alloc_init_vec(&temp_arr, expansion_factor);
  alloc_init_vec(&temp_arr2, expansion_factor);

  alloc_init_scalar(a1);
  alloc_init_scalar(a2);
  alloc_init_scalar(f1_s);
  alloc_init_scalar(f2_s);
  mpz_init(temp);
  mpz_init(output);
  mpz_init(neg);
  mpz_init(neg_i);

  // To create consistency and commitment queries.
  commitment_query_sizes.clear();
  commitment_query_sizes.push_back(input_size);
  commitment_query_sizes.push_back(input_size*input_size);

  f_commitment_ptrs.clear();
  f_commitment_ptrs.push_back(f1_commitment);
  f_commitment_ptrs.push_back(f2_commitment);

  f_consistency_ptrs.clear();
  f_consistency_ptrs.push_back(f1_consistency);
  f_consistency_ptrs.push_back(f2_consistency);

  con_coins_ptrs.clear();
  con_coins_ptrs.push_back(f1_con_coins);
  con_coins_ptrs.push_back(f2_con_coins);

  temp_arr_ptrs.clear();
  temp_arr_ptrs.push_back(temp_arr);
  temp_arr_ptrs.push_back(temp_arr2);

  scalar_s_ptrs.clear();
  scalar_s_ptrs.push_back(&f1_s);
  scalar_s_ptrs.push_back(&f2_s);

  scalar_a_ptrs.clear();
  scalar_a_ptrs.push_back(&a1);
  scalar_a_ptrs.push_back(&a2);

  answers_rfetch_ptrs.clear();
  answers_rfetch_ptrs.push_back(f1_answers);
  answers_rfetch_ptrs.push_back(f2_answers);

  answers_ptrs.clear();
  answers_ptrs.push_back(f1_answers);
  answers_ptrs.push_back(f2_answers);

  Q_list.clear();
  Q_list.push_back(Q1);
  Q_list.push_back(Q2);
  Q_list.push_back(Q3);
  Q_list.push_back(Q4);
  Q_list.push_back(Q5);
  Q_list.push_back(Q6);

  pcp_queries.clear();
  pcp_queries.push_back(NUM_LIN_PCP_QUERIES_F1);
  pcp_queries.push_back(NUM_LIN_PCP_QUERIES_F2);
}

void PolyEvalD2Verifier::create_input() {
  v->get_random_vec(num_coefficients, coefficients, num_bits_in_input);
  v->add_sign(num_coefficients, coefficients);
  dump_vector(num_coefficients, coefficients, (char *)"input0");
  send_file((char *)"input0");

  // as many computations as inputs
  for (int k=0; k<batch_size; k++) {
    v->get_random_vec(input_size, input, num_bits_in_input);
    v->add_sign(input_size, input);
    snprintf(scratch_str, BUFLEN-1, "input1_b_%d", k);
    dump_vector(input_size, input, scratch_str);
    send_file(scratch_str);
  }
}

void PolyEvalD2Verifier::create_plain_queries() {
  // keeps track of #filled coins
  int f1_con_filled = -1;
  int f2_con_filled = -1;

  load_vector(num_coefficients, coefficients, (char *)"input0");

  for (int rho=0; rho<num_repetitions; rho++) {
    if (rho == 0) m_plainq.begin_with_init();
    else m_plainq.begin_with_history();
    // f1_q1 = q1
    // f1_q2 = q2
    // f2_q1 = q3
    // f2_q2 = q4
    v->create_corr_test_queries(input_size, f1_q1, input_size, f1_q2,
                                f2_q1, f2_q2, f1_consistency, f1_consistency, f2_consistency,
                                f1_con_filled, f1_con_coins, f1_con_filled+1, f1_con_coins,
                                f2_con_filled, f2_con_coins, prime, false);

    f1_con_filled += 2;
    f2_con_filled += 2;

    snprintf(scratch_str, BUFLEN-1, "q1_qquery_r_%d", rho);
    dump_vector(input_size, f1_q1, scratch_str);
    send_file(scratch_str);

    snprintf(scratch_str, BUFLEN-1, "q2_qquery_r_%d", rho);
    dump_vector(input_size, f1_q2, scratch_str);
    send_file(scratch_str);

    snprintf(scratch_str, BUFLEN-1, "q4_qquery_r_%d", rho);
    dump_vector(input_size*input_size, f2_q2, scratch_str);
    send_file(scratch_str);

    //snprintf(scratch_str, BUFLEN-1, "q3_qquery_r_%d", rho);
    //dump_vector(input_size*input_size, f2_q1, scratch_str);
    //send_file(scratch_str);


    // circuit test
    v->get_random_vec(input_size+1, alpha, prime);

    // formulate a; a = -\alpha_0 \cdot degree-2 coefficients
    mpz_neg(neg, alpha[0]);

    for (int i=0; i<input_size*input_size; i++) {
      mpz_set_ui(f2_q1[i], 0);
    }

    int index;
    int k = 0;
    for (int i=0; i<input_size; i++) {
      for (int j=0; j<=i; j++) {
        index = input_size*i + j;
        mpz_mul(f2_q1[index], neg, coefficients[k]);
        mpz_mod(f2_q1[index], f2_q1[index], prime);
        k++;
      }
    }

    // formulate b; b = -\alpha_0 \cdot degree-1 coefficients + [\alpha_1,
    // \alpha_2, ... , \alpha_{input_size+1}]
    int m2 = (input_size*input_size + input_size)/2;
    for (int i=0; i<input_size; i++) {
      mpz_mul(f1_q2[i], neg, coefficients[m2+i]);

      mpz_add(f1_q2[i], alpha[i+1], f1_q2[i]);
      mpz_mod(f1_q2[i], f1_q2[i], prime);
    }

    v->create_ckt_test_queries(input_size, f1_q2, f1_q3, f1_q1,
                               f1_consistency, f1_con_filled, f1_con_coins, prime);

    v->create_ckt_test_queries(input_size*input_size, f2_q1, f2_q3,
                               f2_q2, f2_consistency, f2_con_filled, f2_con_coins, prime);

    snprintf(scratch_str, BUFLEN-1, "q5_qquery_r_%d", rho);
    dump_vector(input_size, f1_q3, scratch_str);
    send_file(scratch_str);

    snprintf(scratch_str, BUFLEN-1, "q6_qquery_r_%d", rho);
    dump_vector(input_size*input_size, f2_q3, scratch_str);
    send_file(scratch_str);
    m_plainq.end();

    if (rho == 0) m_runtests.begin_with_init();
    else m_runtests.begin_with_history();

    // finally compute c
    for (int i=0; i<batch_size; i++) {
      snprintf(scratch_str, BUFLEN-1, "input1_b_%d", i);
      load_vector(input_size, input, scratch_str);

      snprintf(scratch_str, BUFLEN-1, "output_b_%d", i);
      load_scalar(output, scratch_str);

      int c_index = i * num_repetitions + rho;
      mpz_set_ui(c_values[c_index], 0);

      for (int k=0; k<input_size; k++) {
        mpz_neg(neg_i, alpha[k+1]);
        mpz_mul(temp, neg_i, input[k]);
        mpz_add(c_values[c_index], c_values[c_index], temp);
      }
      mpz_mul(temp, neg, coefficients[m2+input_size]);
      mpz_add(c_values[c_index], c_values[c_index], temp);

      mpz_mul(temp, alpha[0], output);
      mpz_add(c_values[c_index], c_values[c_index], temp);
      mpz_mod(c_values[c_index], c_values[c_index], prime);
    }
    m_runtests.end();

    f1_con_filled += 1;
    f2_con_filled += 1;
  }

  dump_vector(input_size, f1_consistency, (char *)"f1_consistency_query");
  send_file((char *)"f1_consistency_query");

  dump_vector(input_size*input_size, f2_consistency, (char *)"f2_consistency_query");
  send_file((char *)"f2_consistency_query");
}

void PolyEvalD2Verifier::populate_answers(mpz_t *f_answers, int rho, int num_repetitions, int beta) {
  uint32_t i = rho * num_lin_pcp_queries;

  // fill in f_con_coins
  mpz_set(f_con_coins[i+Q1], f1_con_coins[i+0]);
  mpz_set(f_con_coins[i+Q2], f1_con_coins[i+1]);
  mpz_set(f_con_coins[i+Q3], f2_con_coins[i+0]);
  mpz_set(f_con_coins[i+Q4], f2_con_coins[i+1]);
  mpz_set(f_con_coins[i+Q5], f1_con_coins[i+2]);
  mpz_set(f_con_coins[i+Q6], f2_con_coins[i+2]);
}

void PolyEvalD2Verifier::run_correction_and_circuit_tests(uint32_t beta) {
  for (int rho=0; rho<num_repetitions; rho++) {
    // Quad Correction test and Circuit test
    bool cor1 = v->corr_test(f_answers[rho*num_lin_pcp_queries + Q1],
                             f_answers[rho*num_lin_pcp_queries + Q2],
                             f_answers[rho*num_lin_pcp_queries + Q3],
                             f_answers[rho*num_lin_pcp_queries + Q4],
                             prime);

    if (false == cor1)
      cout<<"LOG: F1, F2 failed the correction test"<<endl;
    else
      cout<<"LOG: F1, F2 passed correction test"<<endl;

    mpz_set(ckt_answers[0], f_answers[rho*num_lin_pcp_queries + Q5]);
    mpz_set(ckt_answers[1], f_answers[rho*num_lin_pcp_queries + Q1]);
    mpz_set(ckt_answers[2], f_answers[rho*num_lin_pcp_queries + Q6]);
    mpz_set(ckt_answers[3], f_answers[rho*num_lin_pcp_queries + Q4]);

    bool ckt2 = v->ckt_test(4, ckt_answers, c_values[beta * num_repetitions + rho], prime);

    if (false == ckt2)
      cout <<"LOG: F1, F2 failed the circuit test"<<endl;
    else
      cout <<"LOG: F1, F2 passed the circuit test"<<endl;
  }
}
