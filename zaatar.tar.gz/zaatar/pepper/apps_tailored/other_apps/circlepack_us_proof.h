#ifndef CODE_PEPPER_APPS_CIRCLEPACK_US_PROOF_H_
#define CODE_PEPPER_APPS_CIRCLEPACK_US_PROOF_H_
#include <common/constraint_gen.h>

class CirclePackUSProof{
public:
  CirclePackUSProof();
  void circlepack_us_proof(ConstraintGenerator& cg, int m);
private:
  mpz_t one, neg1, neg3, two;
  mpq_t alpha, oneminalpha;
};

#endif  //CODE_PEPPER_APPS_CIRCLEPACK_US_PROOF_H_
