#ifndef CODE_PEPPER_APPS_sample_V_H_
#define CODE_PEPPER_APPS_sample_V_H_

#include <libv/computation_v.h>

#define NAME_PROVER "sample"

#ifdef INTERFACE_MPI
#include <apps/sample_p.h>
#endif

class SampleVerifier : public ComputationVerifier {
  public:
    SampleVerifier(int batch, int reps, int optimize_answers, char *prover_url, int in_size, int out_size, int num_v, int num_c);
    void create_gamma0(int rho_i);
    void create_gamma12();
};
#endif  // CODE_PEPPER_APPS_sample_V_H_
