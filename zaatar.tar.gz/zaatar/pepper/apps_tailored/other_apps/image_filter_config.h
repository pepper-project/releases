#ifndef CODE_PEPPER_APPS_IMAGE_FILTER_CONFIG_H_  
#define CODE_PEPPER_APPS_IMAGE_FILTER_CONFIG_H_  

#include <libv/libv.h>

#define NUM_PCP_FN         3
#define INPUT_L1 0
#define INPUT_L2 1
#define INPUT_L3 2
#define INPUT_Q1 3
#define INPUT_C1 4

#define OUTPUT_L1 0
#define OUTPUT_L2 1
#define OUTPUT_L3 2
#define OUTPUT_Q1 3
#define OUTPUT_Q2 4
#define OUTPUT_C1 5
#define OUTPUT_C2 6

extern uint32_t num_bits_in_prime;
extern uint32_t num_bits_in_input;
extern int crypto_in_use;
extern int png_in_use;
extern mpz_t prime;
extern int expansion_factor;
extern char scratch_str[BUFLEN];


// Number of PCP queries per function.
const uint32_t num_pcp_queries[NUM_PCP_FN] = {
  5,      // F^{m*m}
  5,      // F^{k*k}
  7       // F^{m*m*k*k}
};

// The size of each query.
uint32_t sizes[NUM_PCP_FN];

// The size of the commitment query (i.e. the size of the encrypted query).
uint32_t commitment_sizes[NUM_PCP_FN];

uint32_t k;     // Size of kernel

void init_state()
{
  num_bits_in_prime = 128;
  num_bits_in_input = 40;
  crypto_in_use = CRYPTO_ELGAMAL;
  png_in_use = PNG_MT;

  // k is hardwired for now, since it doesn't fit into the current API.
  k = 7;

  mpz_init(prime);

  // REVISIT: get this from crypto library
  if (crypto_in_use == CRYPTO_ELGAMAL)
    expansion_factor = 2;
  else
    expansion_factor = 1;

  snprintf(scratch_str, BUFLEN-1, "prime_%d.txt", num_bits_in_prime);
  load_txt_scalar(prime, scratch_str, (char *)"static_state"); 
}

// Initializes the various bookeeping arrays. This function should be called
// at the start of each function.
// TODO: fix me. There are better ways to initialize (say in a class
// constructor).
void set_sizes(uint32_t m, uint32_t k)
{
  sizes[0] = m*m;
  sizes[1] = k*k;
  sizes[2] = sizes[0] * sizes[1];

  for (int i = 0; i < NUM_PCP_FN; i++)
    commitment_sizes[i] = expansion_factor * sizes[i];
}
#endif  // CODE_PEPPER_APPS_IMAGE_FILTER_CONFIG_H_
