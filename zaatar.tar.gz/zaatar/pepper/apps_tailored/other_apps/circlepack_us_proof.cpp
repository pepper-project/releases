#include<apps/circlepack_us_proof.h>
#include<common/utility.h>
#include<gmp.h>

CirclePackUSProof::CirclePackUSProof()
{
  alloc_init_scalar(one);
  alloc_init_scalar(neg1);
  alloc_init_scalar(two);
  alloc_init_scalar(neg3);
  alloc_init_scalar(alpha);
  alloc_init_scalar(oneminalpha);
  mpz_set_si(one, 1); 
  mpz_set_si(neg1, -1); 
  mpz_set_si(two, 2); 
  mpz_set_si(neg3, -3); 
  mpq_set_si(alpha, 1, 16);
  mpq_set_si(oneminalpha, 15, 16);
}

void CirclePackUSProof::circlepack_us_proof(ConstraintGenerator& cg, int m){

  //Input variables
  int RADII = cg.create_new_variables(m);
  //Output variables
  int POINTS = cg.create_new_variables(m*2);
  
  //Input / Output matching constraints.
  for(int i = 0; i < m*3; i++){
    int poly = cg.create_new_constraint();
    cg.add_term(one, i, -1, poly);
    //These are unfinished constraints, the constant terms will be added to gamma_0 by the verifier.
  }

  int ALPHA = cg.create_constant(alpha);  
  //int ONE_MINUS_ALPHA = cg.create_constant(oneminalpha);  
  int R = 8;
  int T = 3;
  //Check that each point is in the unit square
  /* Offload to verifier.
  for(int i = 0; i < m*2; i++){
    cg.create_constraint_XgeY(POINTS + i, ALPHA, R, T);
    cg.create_constraint_XleY(POINTS + i, ONE_MINUS_ALPHA, R, T);
  }
  */

  //Verify that x is sufficiently distant from y 
  for(int i = 0; i < m; i++){
    for(int j = i+1; j < m; j++){
      int DISTXY = cg.create_distance_squared(POINTS + i*2, POINTS + j*2, 2);
      cg.create_constraint_XgeY(DISTXY, ALPHA, R, T); 
    }
  } 
}
