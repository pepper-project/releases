#include <apps/circlepack_us_v.h>
#include <apps/circlepack_us_p.h>

bool MICROBENCHMARKS = false;

// driver to run the phases of the verifier and the prover
// this doesn't ever seem to contain any problem-specific code.
int main(int argc, char **argv)
{
  int phase;
  int batch_size;
  int num_repetitions;
  char prover_url[BUFLEN];

  int input_size; //Number of points for which to generate a 
		  //circle packing. Also called m in CirclePackingUSVerifier
		  // / Prover.

  char actor;
  parse_args(argc, argv, &actor, &phase, &batch_size, &num_repetitions,
    &input_size, prover_url);
  int optimize_answers = 1;

#ifdef INTERFACE_MPI

  MPI_Init(&argc, &argv);
  int rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

  if (rank == 0) {  // verifier
    CirclePackUSVerifier verifier(batch_size, num_repetitions, input_size,
      optimize_answers, prover_url);          
    verifier.begin_pepper();
  } else {  // prover
    CirclePackUSProver prover(0 /*phase*/, batch_size, num_repetitions, input_size);
    prover.handle_requests();
  }

#else
  if (actor == 'v') {
    CirclePackUSVerifier verifier(batch_size, num_repetitions, input_size,
      optimize_answers, prover_url);

    verifier.begin_pepper();
  } else {
    if (argc > 2)
    {
      CirclePackUSProver prover(phase, batch_size, num_repetitions, input_size);
      prover.handle_terminal_request();
    }
    else
    {
      phase = 0;
      batch_size = 100;
      num_repetitions = 1;
      input_size = 200;
      CirclePackUSProver prover(phase, batch_size, num_repetitions, input_size);
      prover.handle_http_requests();
    }
  }
#endif

   return 0;
}
