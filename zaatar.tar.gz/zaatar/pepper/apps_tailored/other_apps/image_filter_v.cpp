#include <apps/image_filter_v.h>
/*

// VERIFIER's CODE
void verifier_create_commitment_query_and_input(int batch_size, int m)
{
  cout << "\nVERIFIER CREATE COMMITMENT QUERY AND INPUT" << endl;

  // all our computations will be defined over Z_prime
  set_sizes(m, k);

  //
  mpz_t *A, *B;

  alloc_init_vec(&A, sizes[0]);
  alloc_init_vec(&B, sizes[1]);

  // as many computations as inputs
  for (int b = 0; b < batch_size; b++)
  {
    v->get_random_vec(sizes[0], A, num_bits_in_input);

    v->get_random_vec(sizes[1], B, num_bits_in_input);

    sprintf(scratch_str, "input0_b_%d", b); 
    dump_vector(sizes[0], A, scratch_str);

    sprintf(scratch_str, "input1_b_%d", b); 
    dump_vector(sizes[1], B, scratch_str);
  }

  // prover's function consists of three function F:
  //    F^{m^2} -> F
  //    F^{k^2} -> F
  //    F^{k^2m^2} -> F
  // consistency == r == random vector
  // commitment == enc(consistency)
  mpz_t *f_commitment[NUM_PCP_FN];
  mpz_t *f_consistency[NUM_PCP_FN];

  alloc_init_vec_array(commitment_sizes, f_commitment, NUM_PCP_FN);
  alloc_init_vec_array(sizes, f_consistency, NUM_PCP_FN);

  measurement.verifier_gen_commit = 0;

  start = measurement.rdtsc();
  for (int i = 0; i < NUM_PCP_FN; i++)
  {
    v->create_commitment_query(sizes[i], f_commitment[i], f_consistency[i], prime);
  }
  end = measurement.rdtsc();

  if(overhead > end-start)
    measurement.verifier_gen_commit = end-start;
  else
    measurement.verifier_gen_commit = end-start-overhead;

  cout << "v_commitmentq_create_cycles " << measurement.verifier_gen_commit<< endl;

  dump_vector_array(NUM_PCP_FN, commitment_sizes, f_commitment, "commitment_query");
  dump_vector_array(NUM_PCP_FN, sizes, f_consistency, "consistency_query");
}

void verifier_create_plain_queries(int batch_size, int num_r, int m)
{
  cout << "\nVERIFIER CREATE PLAIN QUERIES" << endl;

  set_sizes(m, k);

  int f_con_filled[] = {-1, -1, -1};
  uint32_t num_coins[NUM_PCP_FN];
  for (int i = 0; i < NUM_PCP_FN; i++)
    num_coins[i] = num_r * num_pcp_queries[i];

  // Linear test queries. One for each function.
  mpz_t *pcp_queries[3][NUM_PCP_FN];
  mpz_t *f_consistency[NUM_PCP_FN];   // t, consistency query.
  mpz_t *f_con_coins[NUM_PCP_FN];     // coefficients alpha to be used to verify consistency.
  mpz_t *A, *B, *C;
  mpz_t c;                            // Constant term of circuit.
  mpz_t temp;

  mpz_init(c);
  mpz_init(temp);

  for (int i = 0; i < 3; i++)
    alloc_init_vec_array(sizes, pcp_queries[i], NUM_PCP_FN);

  alloc_init_vec_array(sizes, f_consistency, NUM_PCP_FN);
  alloc_init_vec_array(num_coins, f_con_coins, NUM_PCP_FN);
  alloc_init_vec(&A, sizes[0]);
  alloc_init_vec(&B, sizes[1]);
  alloc_init_vec(&C, sizes[2]);

  // Aliases for code readability
  mpz_t *gamma_a, *gamma_b, *gamma_c, *big_gamma_c, *X, *gamma_query;
  gamma_a = pcp_queries[0][0];
  gamma_b = pcp_queries[0][1];
  gamma_c = pcp_queries[1][0];
  gamma_query = pcp_queries[0][2];
  X = pcp_queries[1][2];
  big_gamma_c = pcp_queries[2][2];

  // load consistency vectors.
  load_vector_array(NUM_PCP_FN, sizes, f_consistency, "consistency_query");

  for (int rho=0; rho<num_r; rho++)
  {
    for (int i = 0; i < NUM_PCP_FN; i++)
    {
      start = measurement.rdtsc();
      v->create_lin_test_queries(
          sizes[i], pcp_queries[0][i], pcp_queries[1][i], pcp_queries[2][i],
          f_consistency[i], f_con_filled[i], f_con_coins[i], prime); 
      end = measurement.rdtsc();
      if(overhead > end-start)
        measurement.verifier += end-start;
      else
        measurement.verifier += end-start-overhead;

      f_con_filled[i] += 3; 

      sprintf(scratch_str, "f%d_lin1_query_r_%d", i, rho);
      dump_vector(sizes[i], pcp_queries[0][i], scratch_str);

      sprintf(scratch_str, "f%d_lin2_query_r_%d", i, rho);
      dump_vector(sizes[i], pcp_queries[1][i], scratch_str);

      sprintf(scratch_str, "f%d_lin3_query_r_%d", i, rho);
      dump_vector(sizes[i], pcp_queries[2][i], scratch_str);
    }

    start = measurement.rdtsc();
    // Reuses the pcp_queries to save space. Sorry about the huge list of
    // arguments. By the time this is done:
    //      [0][0] == q_a => F^{m*m}
    //      [0][1] == q_b => F^{k*k}
    //      [1][2] == q_s => F^{m*m*k*k}
    //      [0][2] == q_a * q_b + q_s => F^{m*m*k*k}
    v->create_corr_test_queries(
        sizes[0], pcp_queries[0][0], sizes[1], pcp_queries[0][1], pcp_queries[0][2],
        pcp_queries[1][2], f_consistency[0], f_consistency[1], f_consistency[2],
        f_con_filled[0], f_con_coins[0],
        f_con_filled[1], f_con_coins[1],
        f_con_filled[2], f_con_coins[2],
        prime);
    end = measurement.rdtsc();
    if(overhead > end-start)
      measurement.verifier += end-start;
    else
      measurement.verifier += end-start-overhead;

    f_con_filled[0]++;
    f_con_filled[1]++;
    f_con_filled[2] += 2;

    sprintf(scratch_str, "corr1_query_r_%d", rho);
    dump_vector_array(NUM_PCP_FN, sizes, pcp_queries[0], scratch_str);

    sprintf(scratch_str, "f2_corr2_query_r_%d", rho);
    dump_vector(sizes[2], pcp_queries[1][2], scratch_str);

    // circuit test - Reusing the pcp_queries arrays.
    v->get_random_vec(sizes[0], gamma_a, prime);
    v->get_random_vec(sizes[1], gamma_b, prime);
    v->get_random_vec(sizes[0], gamma_c, prime);

    // Update the consistency query manually since we'll never use the
    // create_ckt_queries function.
    for (int i = 0; i < 2; i++)
    {
      v->get_random(f_con_coins[i][++f_con_filled[i]], prime);
      v->update_con_query_vec(sizes[i], f_consistency[i],
          f_con_coins[i][f_con_filled[i]],
          pcp_queries[0][i], prime);
    }

    // Init big_gamma_c first, since we're reusing it.
    for (uint32_t i = 0; i < sizes[2]; i++)
      mpz_set_ui(big_gamma_c[i], 0);

    // Generate gamma_c, the m*m*k*k vector that is the query for F2.
    int a_i, a_j;
    uint32_t a_index, b_index, c_index, gamma_index, shift;
    shift = (k - 1) / 2;

    for (uint32_t i = 0; i < (uint32_t)m; i++)
    {
      for (uint32_t j = 0; j < (uint32_t)m; j++)
      {
        c_index = i * m + j;

        for (uint32_t x = 0; x < k; x++)
        {
          for (uint32_t y = 0; y < k; y++)
          {
            a_i = i + x - shift;
            a_j = j + y - shift;

            a_index = a_i * m + a_j;
            b_index = x * k + y;

            gamma_index = a_index * sizes[1] + b_index;

            // Edge Condition.
            if ((a_i >= 0) && (a_i < (int)m) && (a_j >= 0) && (a_j < (int)m))
            {
              mpz_set(big_gamma_c[gamma_index], gamma_c[c_index]);
            }
          }
        }
      }
    }

    v->create_ckt_test_queries(
        sizes[2], big_gamma_c, gamma_query, X, 
        f_consistency[2], f_con_filled[2], f_con_coins[2], prime);

    f_con_filled[2] += 2;

    // Serializes gamma_a, gamma_b, gamma_query.
    for (int i = 0; i < NUM_PCP_FN; i++)
    {
      sprintf(scratch_str, "f%d_ckt1_query_r_%d", i, rho);
      dump_vector(sizes[i], pcp_queries[0][i], scratch_str);
    }
    sprintf(scratch_str, "f2_ckt2_query_r_%d", rho);
    dump_vector(sizes[2], X, scratch_str);

    // finally compute c
    for (int batch = 0; batch < batch_size; batch++)
    {
      sprintf(scratch_str, "input0_b_%d", batch);
      load_vector(sizes[0], A, scratch_str);

      sprintf(scratch_str, "input1_b_%d", batch);
      load_vector(sizes[1], B, scratch_str);

      sprintf(scratch_str, "output0_b_%d", batch);
      load_vector(sizes[0], C, scratch_str);

      mpz_set_ui(c, 0);

      start = measurement.rdtsc();
      for (uint32_t i = 0; i < sizes[0]; i++)
      {
        mpz_mul(temp, gamma_c[i], C[i]);
        mpz_add(c, c, temp);

        mpz_mul(temp, gamma_a[i], A[i]);
        mpz_add(c, c, temp);
      }

      for (uint32_t i = 0; i < sizes[1]; i++)
      {
        mpz_mul(temp, gamma_b[i], B[i]);
        mpz_add(c, c, temp);
      }

      // c should be negative.
      mpz_ui_sub(c, 0, c);
      end = measurement.rdtsc();

      if(overhead > end-start)
        measurement.verifier += end-start;
      else
        measurement.verifier += end-start-overhead;

      sprintf(scratch_str, "c_b_%d_r_%d", batch, rho); 
      dump_scalar(c, scratch_str);
    }
  }

  dump_vector_array(NUM_PCP_FN, sizes, f_consistency, "consistency_query");
  dump_vector_array(NUM_PCP_FN, num_coins, f_con_coins, "con_coins");

  cout << "Verifier (query creation): " << measurement.verifier << endl;
}

void verifier_run_tests(int batch_size, int num_r)
{
  cout << "\nVERIFIER RUN TEST" << endl;

  uint32_t num_answers[NUM_PCP_FN];
  for (int i = 0; i < NUM_PCP_FN; i++)
    num_answers[i] = num_r * num_pcp_queries[i];

  mpz_t *answers[NUM_PCP_FN];
  mpz_t *f_con_coins[NUM_PCP_FN];
  mpz_t *ckt_answers;

  mpz_t commitment_ans[NUM_PCP_FN];
  mpz_t consistency_ans[NUM_PCP_FN];
  mpz_t *temp[NUM_PCP_FN];

  mpz_t c;

  alloc_init_vec_array(num_answers, answers, NUM_PCP_FN);
  alloc_init_vec_array(num_answers, f_con_coins, NUM_PCP_FN);
  alloc_init_vec_array(expansion_factor, temp, NUM_PCP_FN);
  alloc_init_vec(&ckt_answers, 6);
  alloc_init_scalar(c);

  for (int i = 0; i < NUM_PCP_FN; i++)
  {
    alloc_init_scalar(commitment_ans[i]);
    alloc_init_scalar(consistency_ans[i]);

    sprintf(scratch_str, "f%d_con_coins", i);
    load_vector(num_answers[i], f_con_coins[i], scratch_str);
  }

  // measurements
  measurement.verifier_dec_commit = 0;
  measurement.verifier_tests = 0;

  for (int beta=0; beta<batch_size; beta++)
  {
    cout<<endl<<"Batch "<<beta<<endl;

    sprintf(scratch_str, "commitment_answer_b_%d", beta);
    load_vector_array(NUM_PCP_FN, expansion_factor, temp, scratch_str);

    sprintf(scratch_str, "consistency_answer_b_%d", beta);
    load_scalar_array(NUM_PCP_FN, consistency_ans, scratch_str);

    start = measurement.rdtsc();
    for (int i = 0; i < NUM_PCP_FN; i++)
    {
      if (crypto_in_use == CRYPTO_PAILLIER)
      { 
        v->paillier_dec(commitment_ans[i], temp[i][0]);
        mpz_mod(commitment_ans[i], commitment_ans[i], prime);
      }
      else
      {
        v->elgamal_dec(commitment_ans[i], temp[i][0], temp[i][1]);
      }
    }
    end = measurement.rdtsc();

    if(overhead > end-start)
      measurement.verifier_dec_commit += end-start;
    else
      measurement.verifier_dec_commit += end-start-overhead;


    for (int rho=0; rho<num_r; rho++)
    {
      for (int i = 0; i < 2; i++)
      {
        sprintf(scratch_str, "f%d_lin1_answer_b_%d_r_%d", i, beta, rho);
        load_scalar(answers[i][rho * num_pcp_queries[i] + INPUT_L1], scratch_str);

        sprintf(scratch_str, "f%d_lin2_answer_b_%d_r_%d", i, beta, rho);
        load_scalar(answers[i][rho * num_pcp_queries[i] + INPUT_L2], scratch_str);

        sprintf(scratch_str, "f%d_lin3_answer_b_%d_r_%d", i, beta, rho);
        load_scalar(answers[i][rho * num_pcp_queries[i] + INPUT_L3], scratch_str);

        sprintf(scratch_str, "f%d_corr1_answer_b_%d_r_%d", i, beta, rho);
        load_scalar(answers[i][rho * num_pcp_queries[i] + INPUT_Q1], scratch_str);

        sprintf(scratch_str, "f%d_ckt1_answer_b_%d_r_%d", i, beta, rho);
        load_scalar(answers[i][rho * num_pcp_queries[i] + INPUT_C1], scratch_str);
      }

      sprintf(scratch_str, "f2_lin1_answer_b_%d_r_%d", beta, rho);
      load_scalar(answers[2][rho * num_pcp_queries[2] + OUTPUT_L1], scratch_str);

      sprintf(scratch_str, "f2_lin2_answer_b_%d_r_%d", beta, rho);
      load_scalar(answers[2][rho * num_pcp_queries[2] + OUTPUT_L2], scratch_str);

      sprintf(scratch_str, "f2_lin3_answer_b_%d_r_%d", beta, rho);
      load_scalar(answers[2][rho * num_pcp_queries[2] + OUTPUT_L3], scratch_str);

      sprintf(scratch_str, "f2_corr1_answer_b_%d_r_%d", beta, rho);
      load_scalar(answers[2][rho * num_pcp_queries[2] + OUTPUT_Q1], scratch_str);

      sprintf(scratch_str, "f2_corr2_answer_b_%d_r_%d", beta, rho);
      load_scalar(answers[2][rho * num_pcp_queries[2] + OUTPUT_Q2], scratch_str);

      sprintf(scratch_str, "f2_ckt1_answer_b_%d_r_%d", beta, rho);
      load_scalar(answers[2][rho * num_pcp_queries[2] + OUTPUT_C1], scratch_str);

      sprintf(scratch_str, "f2_ckt2_answer_b_%d_r_%d", beta, rho);
      load_scalar(answers[2][rho * num_pcp_queries[2] + OUTPUT_C2], scratch_str);

    }

    // consistency test
    for (int i = 0; i < NUM_PCP_FN; i++)
    {
      start = measurement.rdtsc();
      bool con1 = v->consistency_test(
          num_answers[i], consistency_ans[i], commitment_ans[i],
          answers[i], f_con_coins[i], prime);
      end = measurement.rdtsc();
      if(overhead > end-start)
        measurement.verifier_tests += end-start;
      else
        measurement.verifier_tests +=  end-start-overhead;

      if (false == con1) 
        cout <<"F" << i << " failed the consistency test."<<endl;
      else
        cout <<"F" << i << " passed the consistency test."<<endl;
    }

    for (int rho=0; rho<num_r; rho++)
    {
      for (int i = 0; i < NUM_PCP_FN; i++)
      {
        // Linearity test
        start = measurement.rdtsc();
        bool lin1 = v->lin_test(
            answers[i][rho * num_pcp_queries[i] + INPUT_L1],
            answers[i][rho * num_pcp_queries[i] + INPUT_L2],
            answers[i][rho * num_pcp_queries[i] + INPUT_L3],
            prime);
        end = measurement.rdtsc();

        if(overhead > end-start)
          measurement.verifier_tests += end-start;
        else
          measurement.verifier_tests += end-start-overhead;

        if (false == lin1)
          cout<<"F" << i << " failed lin test"<<endl;
        else
          cout<<"F" << i << " passed lin test"<<endl;
      }

      // Quad Correction test and Circuit test
      sprintf(scratch_str, "c_b_%d_r_%d", beta, rho);
      load_scalar(c, scratch_str);

      mpz_set(ckt_answers[0], answers[0][rho * num_pcp_queries[0] + INPUT_C1]);
      mpz_set_ui(ckt_answers[1], 0);
      mpz_set(ckt_answers[2], answers[1][rho * num_pcp_queries[1] + INPUT_C1]);
      mpz_set_ui(ckt_answers[3], 0);
      mpz_set(ckt_answers[4], answers[2][rho * num_pcp_queries[2] + OUTPUT_C1]);
      mpz_set(ckt_answers[5], answers[2][rho * num_pcp_queries[2] + OUTPUT_C2]);

      start = measurement.rdtsc();
      bool cor1 = v->corr_test(
          answers[0][rho * num_pcp_queries[0] + INPUT_Q1],
          answers[1][rho * num_pcp_queries[1] + INPUT_Q1],
          answers[2][rho * num_pcp_queries[2] + OUTPUT_Q1],
          answers[2][rho * num_pcp_queries[2] + OUTPUT_Q2],
          prime);
      bool ckt2 = v->ckt_test(6, ckt_answers, c, prime);
      end = measurement.rdtsc();

      if(overhead > end-start)
        measurement.verifier_tests += end-start;
      else
        measurement.verifier_tests += end-start-overhead;

      if (false == cor1)
        cout<<"F failed the correction test"<<endl;
      else
        cout<<"F passed correction test"<<endl;

      if (false == ckt2)
        cout <<"F failed the circuit test"<<endl;
      else
        cout <<"F passed the circuit test"<<endl;
    }
  }

  cout << "Dec Commit: " << measurement.verifier_dec_commit << endl;
  cout << "Verifier tests: "<<measurement.verifier_tests<<endl;
}
*/
int main() {
}
