#include<apps/graph_embedding_proof.h>
#include<common/utility.h>
#include<gmp.h>

GraphEmbeddingProof::GraphEmbeddingProof()
{
  alloc_init_scalar(one);
  alloc_init_scalar(neg1);
  mpz_set_si(one, 1);
  mpz_set_si(neg1, -1);
  alloc_init_scalar(maxValue);
  alloc_init_scalar(zeroq);
  mpq_set_si(maxValue, 1000, 1);
  mpq_set_si(zeroq, 0, 1);
}

void GraphEmbeddingProof::graph_embedding_proof(ConstraintGenerator& cg, int m){
 
  int R = 8;
  int T = 3;

  //Graph vertices
  int GVERTICES = cg.create_new_variables(m*2); //x, y coordinates of vertices v_i
  std::vector<int> vertices;
  for(int v = 0; v < m; v++){
    vertices.push_back(GVERTICES+v*2);
    for(int d = 0; d < 2; d++){
      int outputMatchingConstraint = cg.create_new_constraint();
      cg.create_constraint_term(one, GVERTICES+v*2+d, -1, outputMatchingConstraint);
    }
  }

  //Path intermediate vertices and segments
  int maxPathLength = 2; //Require each path to use at most 2 segments.
  //TODO: Read in a graph from an input file, and use its edges. For now, the edges that exist are v_i is connected to v_i+1.
  std::vector<int> segments;
  for(int i = 0; i < m-1; i++){
    int PATH = cg.create_new_variables((maxPathLength+1)*2); 
    //output matching constraint? TODO

    for(int j = 0; j < maxPathLength; j++){
      segments.push_back(PATH + j*2);
    }
    for(int j = 1; j < maxPathLength; j++){
      vertices.push_back(PATH + j*2);
    }
    //Verify that the path begins at graph vertex v
    cg.create_constraint_eq_vec(PATH, GVERTICES + i*2, 2);
    //Verify that the path ends at graph vertex v+1
    cg.create_constraint_eq_vec(PATH + maxPathLength * 2, GVERTICES + (i+1)*2, 2);
  }
  
  //Verify that all vertices are within the bounding box
  /* Offloaded to the verifier.
  int MAX_VALUE = cg.create_constant(maxValue);
  int ZERO = cg.create_constant(zeroq);
  int R = 14;
  int T = 3;
  for(uint32_t i = 0; i < vertices.size(); i++){
    cg.create_constraint_XleY(vertices[i]+0, MAX_VALUE, R, T);
    cg.create_constraint_XleY(vertices[i]+1, MAX_VALUE, R, T);
    cg.create_constraint_XgeY(vertices[i]+0, ZERO, R, T);
    cg.create_constraint_XgeY(vertices[i]+1, ZERO, R, T);
  }
  */

  //TODO: This code is BROKEN until more work gets put into it.
    //Essentially, we must count the number of times the graph embedding intersects itself (sum over possibleConflicts)
  //However, it was deemed that graph embedding is less likely to be a win than circle packing, and circle packing was not a win.
  //So, this code was ABANDONED.

  std::vector<int> possibleConflicts; 
  //Count the vertex x vertex intersections
  for(uint32_t i = 0; i < vertices.size(); i++){
    for(uint32_t j = i+1; j < vertices.size(); j++){
      int x = vertices[i];
      int y = vertices[j];
      int OPTED_OUT = cg.create_optional_constraint_neq_vec(x, y, 2);
      possibleConflicts.push_back(OPTED_OUT);
    }
  } 
  
  return;

  //Count the vertex x segment intersections
  for(uint32_t i = 0; i < vertices.size(); i++){
    for(uint32_t j = 0; j < segments.size(); j++){
      int x = vertices[i];
      int e = segments[j];
      int OPTED_OUT = cg.create_optional_constraint_segment_not_contains_2d(e, x, R, T);
      possibleConflicts.push_back(OPTED_OUT);
    }
  } 
  //Count the segment x segment intersections
  for(uint32_t i = 0; i < segments.size(); i++){
    for(uint32_t j = i+1; j < segments.size(); j++){
      int e = segments[i];
      int f = segments[j];
      int OPTED_OUT = cg.create_optional_constraint_segments_intersect_2d(e, f, R, T);
      possibleConflicts.push_back(OPTED_OUT);
    }
  } 

  int INTERSECTCTR = cg.create_sum(possibleConflicts);
  //Assert that the intersectctr is 0
  int INTERSECTCTR_CHECK = cg.create_new_constraint();
  cg.create_constraint_term(one, INTERSECTCTR, -1, INTERSECTCTR_CHECK);
}

