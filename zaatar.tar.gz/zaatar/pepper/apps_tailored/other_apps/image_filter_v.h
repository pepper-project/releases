
//bool MICROBENCHMARKS = 0;
/*
#ifndef VERIFIER_H 
#define VERIFIER_H
#include <libv/libv.h>
#include <common/measurement.h>
#include <common/utility.h>
#include <apps/image_filter_config.h>

// global state used by the verifier
Venezia *v;
Measurement measurement;
uint32_t num_bits_in_input;
uint32_t num_bits_in_prime;
char scratch_str[BUFLEN];
char scratch_str2[BUFLEN];
int crypto_in_use;
int png_in_use;
int expansion_factor;
mpz_t prime;
uint64_t start, end, overhead;

// methods to be implemented by the application
void init_state();
void verifier_create_commitment_query_and_input(int, int);
void verifier_create_plain_queries(int, int, int);
void verifier_run_tests(int, int);

// driver to run the phases of the verifier
int main(int argc, char **argv)
{
  int phase;
  int batch_size = 1;
  int num_repetitions = 1;
  int m = 100;
  measurement.calc_overhead();
  parse_args(argc, argv, &phase, &batch_size, &num_repetitions, &m, NULL);
  init_state();
  
  v = new Venezia(ROLE_VERIFIER, CRYPTO_ELGAMAL, PNG_MT);

  if (phase == 1)
  {
    cout<<"batch_size "<<batch_size<<endl; 
    cout<<"num_reps "<<num_repetitions<<endl;
    cout<<"input_size "<<m<<endl;
    cout<<"num_bits_in_input "<<num_bits_in_input<<endl;
    cout<<"num_bits_in_prime "<<num_bits_in_prime<<endl;
    verifier_create_commitment_query_and_input(batch_size, m);
  }
  else if (phase == 2)
    verifier_create_plain_queries(batch_size, num_repetitions, m);
  else if (phase == 3)
    verifier_run_tests(batch_size, num_repetitions);
  else
    cout<<"Undefined verifier phase "<<phase<<endl;
  return 0;
}
#endif
*/
