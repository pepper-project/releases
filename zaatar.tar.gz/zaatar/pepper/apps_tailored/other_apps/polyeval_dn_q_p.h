#ifndef CODE_PEPPER_APPS_POLYEVAL_DN_Q_P_H_
#define CODE_PEPPER_APPS_POLYEVAL_DN_Q_P_H_
#include <libv/prover.h>
#include <apps/polyeval_dn_q_proof.h>

#define PROVER_NAME "/polyeval_dn_q_p"
#define NUM_LIN_PCP_QUERIES 6
#define Q1 0 
#define Q2 1
#define Q3 2
#define Q4 3
#define Q5 4
#define Q6 5

class PolyevalDnQProver : public Prover {
  
  private:
    mpz_t *output, *f1_commitment, *f2_commitment, *f1_q1, *f1_q2, *f2_q1, *f2_q2, *F1, *F2, *poly_coeffs;
    mpq_t *qF1, *poly_coeffs_q;
    mpq_t tempq;
    mpz_t temp;
    int num_variables, num_variables2, input_file_size, output_file_size, poly_degree, num_poly_coeffs, n_a, n_b;

    PolyevalDnQProof proof;    

  public:
    PolyevalDnQProver(int, int, int, int);
    void init_state();
    void find_cur_qlengths();
    void prover_computation_commitment();
    void computation_polyeval_dn_q();
    void deduce_answers();
    void simulate_local_computation();
    double local_randval();
};
#endif  
