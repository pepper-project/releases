#ifndef CODE_PEPPER_APPS_GRAPH_EMBEDDING_P_H_
#define CODE_PEPPER_APPS_GRAPH_EMBEDDING_P_H_
#include <libv/prover.h>
#include <apps/graph_embedding_proof.h>

#define PROVER_NAME "/graph_embedding_p"
#define NUM_LIN_PCP_QUERIES 6
#define Q1 0 
#define Q2 1
#define Q3 2
#define Q4 3
#define Q5 4
#define Q6 5

class GraphEmbeddingProver : public Prover {
  
  private:
    mpz_t *output, *f1_commitment, *f2_commitment, *f1_q1, *f1_q2, *f2_q1, *f2_q2, *F1, *F2;
    mpq_t *qF1;
    int num_variables, num_variables2, input_file_size, output_file_size;
  
    GraphEmbeddingProof proof;

  public:
    GraphEmbeddingProver(int, int, int, int);
    void init_state();
    void find_cur_qlengths();
    void prover_computation_commitment();
    void computation_graph_embedding();
    void deduce_answers();
};
#endif  
