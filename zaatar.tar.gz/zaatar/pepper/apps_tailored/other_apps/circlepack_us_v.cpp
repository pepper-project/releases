#include <apps/circlepack_us_v.h>

CirclePackUSVerifier::CirclePackUSVerifier(int batch, int reps, int
  ip_size, int optimize_answers, char *prover_url)
  : Verifier(batch, reps, ip_size, optimize_answers, prover_url, NAME_PROVER)
{
  init_state();
}
      
void CirclePackUSVerifier::init_state()
{
  num_bits_in_prime = 320;
  num_bits_in_input = 32;
  crypto_in_use = CRYPTO_ELGAMAL;
  png_in_use = PNG_CHACHA;

  Verifier::init_state();

  m = input_size;

  input_file_size = m;
  ConstraintGenerator cg(prime);
  cg.init_size();

  proof.circlepack_us_proof(cg, m);
  
  num_variables = cg.variables_size();
  num_variables2 = num_variables*num_variables;
  chi = cg.constraints_size();

  gmp_printf("This proof will have %d variables over %d constraints\n", cg.variables_size(), cg.constraints_size());

  num_lin_pcp_queries = NUM_LIN_PCP_QUERIES_F1 + NUM_LIN_PCP_QUERIES_F2;

  alloc_init_vec(&gamma, chi);
  alloc_init_vec(&output, num_variables);
  alloc_init_vec(&q_output, num_variables);
  alloc_init_vec(&ckt_cooefs1, num_variables);
  alloc_init_vec(&ckt_cooefs2, num_variables2);
  alloc_init_vec(&input, input_file_size);
  alloc_init_vec(&q_input, input_file_size);
  alloc_init_vec(&f1_commitment, expansion_factor*num_variables);
  alloc_init_vec(&f2_commitment, expansion_factor*num_variables2);
  alloc_init_vec(&f1_consistency, num_variables);
  alloc_init_vec(&f2_consistency, num_variables2);
  alloc_init_vec(&f1_con_coins, num_repetitions * NUM_LIN_PCP_QUERIES_F1);
  alloc_init_vec(&f2_con_coins, num_repetitions * NUM_LIN_PCP_QUERIES_F2);
  alloc_init_vec(&f1_q1, num_variables);
  alloc_init_vec(&f1_q2, num_variables);
  alloc_init_vec(&f1_q3, num_variables);
  alloc_init_vec(&f2_q1, num_variables2);
  alloc_init_vec(&f2_q2, num_variables2);
  alloc_init_vec(&f2_q3, num_variables2);
  //alloc_init_vec(&alpha, input_size+1); 
  alloc_init_vec(&f_answers,
    num_repetitions * (NUM_LIN_PCP_QUERIES_F1 + NUM_LIN_PCP_QUERIES_F2));
  alloc_init_vec(&f1_answers, num_repetitions * NUM_LIN_PCP_QUERIES_F1);
  alloc_init_vec(&f2_answers, num_repetitions * NUM_LIN_PCP_QUERIES_F2);
  alloc_init_vec(&ckt_answers, 4);
  alloc_init_vec(&temp_arr, expansion_factor);
  alloc_init_vec(&temp_arr2, expansion_factor);

  alloc_init_scalar(a1);
  alloc_init_scalar(a2);
  alloc_init_scalar(f1_s);
  alloc_init_scalar(f2_s);
  alloc_init_scalar(temp);
  alloc_init_scalar(temp2);
  alloc_init_scalar(temp3);
  alloc_init_scalar(temp4);
  alloc_init_scalar(temp_cvalue);

  // To create consistency and commitment queries.
  commitment_query_sizes.clear();
  commitment_query_sizes.push_back(num_variables);
  commitment_query_sizes.push_back(num_variables2);
  f_commitment_ptrs.clear();
  f_commitment_ptrs.push_back(f1_commitment);
  f_commitment_ptrs.push_back(f2_commitment);
  f_consistency_ptrs.clear();
  f_consistency_ptrs.push_back(f1_consistency);
  f_consistency_ptrs.push_back(f2_consistency);
  con_coins_ptrs.clear();
  con_coins_ptrs.push_back(f1_con_coins);
  con_coins_ptrs.push_back(f2_con_coins);
  //must have length equal to the number of commitment queries
  temp_arr_ptrs.clear();
  temp_arr_ptrs.push_back(temp_arr);
  temp_arr_ptrs.push_back(temp_arr2);
  scalar_s_ptrs.clear();
  scalar_s_ptrs.push_back(&f1_s);
  scalar_s_ptrs.push_back(&f2_s);
  scalar_a_ptrs.clear();
  scalar_a_ptrs.push_back(&a1);
  scalar_a_ptrs.push_back(&a2);
  answers_rfetch_ptrs.clear();
  answers_rfetch_ptrs.push_back(f1_answers);
  answers_rfetch_ptrs.push_back(f2_answers);
  answers_ptrs.clear();
  answers_ptrs.push_back(f1_answers);
  answers_ptrs.push_back(f2_answers);
  Q_list.clear();
  Q_list.push_back(Q1);
  Q_list.push_back(Q2);
  Q_list.push_back(Q3);
  Q_list.push_back(Q4);
  Q_list.push_back(Q5);
  Q_list.push_back(Q6);
  
  num_lin_pcp_queries = NUM_LIN_PCP_QUERIES_F1 + NUM_LIN_PCP_QUERIES_F2;
  pcp_queries.clear();
  pcp_queries.push_back(NUM_LIN_PCP_QUERIES_F1);
  pcp_queries.push_back(NUM_LIN_PCP_QUERIES_F2);
}

void CirclePackUSVerifier::create_input()
{
  for (int k=0; k<batch_size; k++)
  {
    v->get_random_rational_vec(m, q_input, 4);
   
    convert_to_z(m, input, q_input, prime);
 
    snprintf(scratch_str, BUFLEN-1, "input_b_%d", k); 
    dump_vector(m, input, scratch_str);
    send_file(scratch_str); 
  }
}

//This method chooses a random set of scalars, gamma, which scale each of the 
//constraints in the verification problem. It fills cooefs1 and cooefs2 with the
//cooeficients of the variables in verification formed by summing over all of the scaled constraints.
//The constant term (c_values) is also formed for each individual problem in the batch.
void CirclePackUSVerifier::create_circuit_test(int rho)
{
    if (rho == 0) m_runtests.begin_with_init();
    else m_runtests.begin_with_history();

    //Generate the random scaling factors
    v->get_random_vec(chi, gamma, prime);
    //Compute a linear combination of the constraints, using these scaling factors. First initialize to zero...
    mpz_set_ui(temp_cvalue, 0); 
    for (int i=0; i<num_variables2; i++)
    {
      mpz_set_ui(ckt_cooefs2[i], 0);
    }
    for (int i=0; i<num_variables; i++)
    {
      mpz_set_ui(ckt_cooefs1[i], 0);
    }

    ConstraintGenerator cg(prime);
    cg.init_v(&temp_cvalue, ckt_cooefs1, ckt_cooefs2, gamma, num_variables); 

    proof.circlepack_us_proof(cg, m);

    //Add input or output dependent constant terms seperately
    for (int i=0; i<batch_size; i++)
    {
      int output_file_size = 2*m;
    
      snprintf(scratch_str, BUFLEN-1, "input_b_%d", i); 
      load_vector(input_file_size, input, scratch_str);

      snprintf(scratch_str, BUFLEN-1, "output_b_%d", i); 
      load_vector(output_file_size, q_output, scratch_str);

      snprintf(scratch_str, BUFLEN-1, "outputz_b_%d", i); 
      load_vector(output_file_size, output, scratch_str);
	
      if (!verify_conversion_to_z(output_file_size, output, q_output, prime)){
        return;
      }

      //Compute c_value by adding any input / output dependent constant terms to temp_cvalue.
      int c_index = i * num_repetitions + rho;
      mpz_set(c_values[c_index], temp_cvalue);
     
      for(int k = 0; k < input_file_size; k++){
	mpz_mul(temp, input[k], gamma[k]);
	mpz_sub(c_values[c_index], c_values[c_index], temp);
      } 
      for(int k = 0; k < output_file_size; k++){
	mpz_mul(temp, output[k], gamma[input_file_size + k]);
    	mpz_sub(c_values[c_index], c_values[c_index], temp);
      } 
      mpz_mod(c_values[c_index], c_values[c_index], prime);
    }
    m_runtests.end();
}

void CirclePackUSVerifier::create_plain_queries()
{
  // keeps track of #filled coins
  int f1_con_filled = -1;
  int f2_con_filled = -1;

  //load_vector(num_coefficients, coefficients, (char *)"input0");
 
  for (int rho=0; rho<num_repetitions; rho++)
  { 
    //consistency and quadratic correction
    if (rho == 0) m_plainq.begin_with_init();
    else m_plainq.begin_with_history();
    // f1_q1 = q1
    // f1_q2 = q2
    // f2_q1 = q3
    // f2_q2 = q4
    v->create_corr_test_queries(num_variables, f1_q1, num_variables, f1_q2,
        f2_q1, f2_q2, f1_consistency, f1_consistency, f2_consistency,
        f1_con_filled, f1_con_coins, f1_con_filled+1, f1_con_coins,
        f2_con_filled, f2_con_coins, prime, false);

    f1_con_filled += 2;
    f2_con_filled += 2;

    snprintf(scratch_str, BUFLEN-1, "q1_qquery_r_%d", rho);
    dump_vector(num_variables, f1_q1, scratch_str);
    send_file(scratch_str);

    snprintf(scratch_str, BUFLEN-1, "q2_qquery_r_%d", rho);
    dump_vector(num_variables, f1_q2, scratch_str);
    send_file(scratch_str);

    //f2_q1 would be q3, but we don't need it.

    snprintf(scratch_str, BUFLEN-1, "q4_qquery_r_%d", rho);
    dump_vector(num_variables2, f2_q2, scratch_str);
    send_file(scratch_str);

    // circuit test
    create_circuit_test(rho);
    
    //f1_q3 = q5, derived from cooefs1, q1, and the consistency check
    v->create_ckt_test_queries(num_variables, ckt_cooefs1, f1_q3, f1_q1,
      f1_consistency, f1_con_filled, f1_con_coins, prime);
    
    //f2_q3 = q6, derived from cooefs2, q4, and the consistency check
    v->create_ckt_test_queries(num_variables2, ckt_cooefs2, f2_q3,
      f2_q2, f2_consistency, f2_con_filled, f2_con_coins, prime);

    snprintf(scratch_str, BUFLEN-1, "q5_qquery_r_%d", rho);
    dump_vector(num_variables, f1_q3, scratch_str);
    send_file(scratch_str);

    snprintf(scratch_str, BUFLEN-1, "q6_qquery_r_%d", rho);
    dump_vector(num_variables2, f2_q3, scratch_str);
    send_file(scratch_str);
    
    m_plainq.end();


    f1_con_filled += 1;
    f2_con_filled += 1;
  }

  dump_vector(num_variables, f1_consistency, (char *)"f1_consistency_query");
  send_file((char *)"f1_consistency_query");
    
  dump_vector(num_variables2, f2_consistency, (char *)"f2_consistency_query");
  send_file((char *)"f2_consistency_query");

  //dump_vector(NUM_LIN_PCP_QUERIES*num_repetitions+1, f1_con_coins, (char *)"f1_con_coins");
  //dump_vector(NUM_LIN_PCP_QUERIES*num_repetitions+1, f2_con_coins, (char *)"f2_con_coins");
}

void CirclePackUSVerifier::populate_answers(mpz_t *f_answers, int rho, int num_repetitions, int beta)
{ 
  mpz_t *t1 = f1_answers;
  mpz_t *t2 = f2_answers;
  mpz_t *t = f_answers;
  uint32_t i = rho * num_lin_pcp_queries;
  mpz_init_set(t1[i+0], t[i+Q1]);
  mpz_init_set(t1[i+1], t[i+Q2]);
  mpz_init_set(t1[i+2], t[i+Q5]);
  mpz_init_set(t2[i+0], t[i+Q3]);
  mpz_init_set(t2[i+1], t[i+Q4]);
  mpz_init_set(t2[i+2], t[i+Q6]);
}

void CirclePackUSVerifier::run_correction_and_circuit_tests(uint32_t beta){
    for (int rho=0; rho<num_repetitions; rho++)
    {
      // Quad Correction test and Circuit test
      bool cor1 = v->corr_test(f_answers[rho*num_lin_pcp_queries + Q1],
          f_answers[rho*num_lin_pcp_queries + Q2],
          f_answers[rho*num_lin_pcp_queries + Q3],
          f_answers[rho*num_lin_pcp_queries + Q4],
          prime);

      if (false == cor1)
        cout<<"LOG: F1, F2 failed the correction test"<<endl;
      else
        cout<<"LOG: F1, F2 passed correction test"<<endl;

      mpz_set(ckt_answers[0], f_answers[rho*num_lin_pcp_queries + Q5]);
      mpz_set(ckt_answers[1], f_answers[rho*num_lin_pcp_queries + Q1]);
      mpz_set(ckt_answers[2], f_answers[rho*num_lin_pcp_queries + Q6]);
      mpz_set(ckt_answers[3], f_answers[rho*num_lin_pcp_queries + Q4]);

      bool ckt2 = v->ckt_test(4, ckt_answers, c_values[beta * num_repetitions + rho], prime);

      if (false == ckt2)
        cout <<"LOG: F1, F2 failed the circuit test"<<endl;
      else
        cout <<"LOG: F1, F2 passed the circuit test"<<endl;
    }
}


