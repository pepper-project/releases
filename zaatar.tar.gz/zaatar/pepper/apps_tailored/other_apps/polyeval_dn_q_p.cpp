#include <apps/polyeval_dn_q_p.h>

PolyevalDnQProver::
PolyevalDnQProver(int ph, int b_size, int num_r, int input_size)
  : Prover(ph, b_size, num_r, input_size, PROVER_NAME)
{
  init_state();
}

void PolyevalDnQProver::
init_state()
{
  num_bits_in_prime = 320;
  num_bits_in_input = 32;
  crypto_in_use = CRYPTO_ELGAMAL;
  png_in_use = PNG_CHACHA;
 
  Prover::init_state();
  
  num_lin_pcp_queries = NUM_LIN_PCP_QUERIES;
  ConstraintGenerator cg(prime);
  cg.init_size();

  /* 
  n_a = 16;
  n_b = 3;
  poly_degree = 4;
  num_poly_coeffs = (24 + 50*m + 35*m*m + 10*m*m*m + m*m*m*m) / 24;
  */
   
  n_a = 32;
  n_b = 32;
  poly_degree = 2;
  num_poly_coeffs = (2 + 3*m + 1*m*m) / 2;
  
  cout << "Note that p must have at least this many bits: " << ceil(log2(num_poly_coeffs)) + 3*(poly_degree - 1) * (n_a + n_b) + 1 << endl;
  alloc_init_vec(&poly_coeffs, num_poly_coeffs);
  alloc_init_vec(&poly_coeffs_q, num_poly_coeffs);

  proof.polyeval_dn_q_proof(cg, m, poly_degree, num_poly_coeffs, poly_coeffs, n_a, n_b);

  num_variables = cg.variables_size();
  num_variables2 = num_variables*num_variables;
  
  alloc_init_vec(&F1, num_variables);
  alloc_init_vec(&F2, num_variables2);
  alloc_init_vec(&qF1, num_variables);
  alloc_init_vec(&output, expansion_factor);
  alloc_init_vec(&f1_commitment, expansion_factor*num_variables);
  alloc_init_vec(&f2_commitment, expansion_factor*num_variables2);
  alloc_init_vec(&f1_q1, num_variables);
  alloc_init_vec(&f2_q1, num_variables2);

  alloc_init_vec(&f_answers, num_lin_pcp_queries);
  alloc_init_scalar(answer);
  alloc_init_scalar(temp);
  alloc_init_scalar(tempq);

  F_ptrs.clear(); 
  F_ptrs.push_back(F1);
  F_ptrs.push_back(F2);
  f_q_ptrs.clear();
  f_q_ptrs.push_back(f1_q1);
  f_q_ptrs.push_back(f2_q1);
  
  find_cur_qlengths();
}

void PolyevalDnQProver::
find_cur_qlengths()
{
  sizes.clear();
  sizes.push_back(num_variables);
  sizes.push_back(num_variables2);
  
  qquery_sizes.clear();
  qquery_sizes.push_back(num_variables);
  qquery_sizes.push_back(num_variables);
  qquery_sizes.push_back(num_variables2);
  qquery_sizes.push_back(num_variables);
  qquery_sizes.push_back(num_variables2);
  qquery_f_ptrs.clear();
  qquery_f_ptrs.push_back(f1_q1);
  qquery_f_ptrs.push_back(f1_q1);
  qquery_f_ptrs.push_back(f2_q1);
  qquery_f_ptrs.push_back(f1_q1);
  qquery_f_ptrs.push_back(f2_q1);
  qquery_F_ptrs.clear();
  qquery_F_ptrs.push_back(F1);
  qquery_F_ptrs.push_back(F1);
  qquery_F_ptrs.push_back(F2);
  qquery_F_ptrs.push_back(F1);
  qquery_F_ptrs.push_back(F2);
}

double PolyevalDnQProver::local_randval()
{
  uint32_t num = rand() & 0xff;
  num |= (rand() & 0xff) << 8;
  num |= (rand() & 0xff) << 16;
  num |= (rand() & 0xff) << 24;

  double den = exp2(rand() % (n_b + 1));  

  return num / den;
}

void PolyevalDnQProver::
simulate_local_computation()
{

  //Create the input (not measured).
  double poly_coeffs_d[num_poly_coeffs];
  double input_d[m];
  for(int i = 0; i < num_poly_coeffs; i++){
    poly_coeffs_d[i] = local_randval();
  }
  for(int i = 0; i < m; i++){
    input_d[i] = local_randval();
  }
  Measurement m_local;

  double output_d[batch_size];
  m_local.begin_with_init();
  for (int b=0; b<batch_size; b++)
  {
    if (b == 0)
      m_local.begin_with_init();
    else
      m_local.begin_with_history();

    output_d[b] = 0;
    if (poly_degree == 2)
    {    
      int k = 0;
      int a[2];
      for(a[0] = -1; a[0] < m; a[0]++){
	for(a[1] = a[0]; a[1] < m; a[1]++){
	  double tmp = poly_coeffs_d[k];
	  for(int i = 0; i < 2; i++){
	    if (a[i] != -1){
	      tmp *=  input_d[a[i]];
	    }
	  }
	  output_d[b] += tmp; 
	  k++;
	}
      }
    } else if (poly_degree == 4){
      int a[4];
      int k = 0;
      for(a[0] = -1; a[0] < m; a[0]++){
	for(a[1] = a[0]; a[1] < m; a[1]++){
	  for(a[2] = a[1]; a[2] < m; a[2]++){
	    for(a[3] = a[2]; a[3] < m; a[3]++){
	      double tmp = poly_coeffs_d[k];
	      for(int i = 0; i < 4; i++){
		  if (a[i] != -1){
		  tmp *=  input_d[a[i]];
		}
	      }
	      output_d[b] += tmp; 

	      k++;
	    }
	  }
	}
      }
    } else {
      cout << "ERROR: Only degree 2 and degree 4 polynomial evaluation implemented " << endl;
    }


    m_local.end();
  }
  cout << "slush: " << output_d[rand() % batch_size] << endl; //Just to make sure output_d is not optimized out
  double time = m_local.get_papi_elapsed_time();
  cout << "local_latency " << time << endl;
}

void PolyevalDnQProver::
computation_polyeval_dn_q()
{
  //TODO: implement me
  //Given that the first input_file_size elements of qF1 are filled with the values from 
  //the input file, this method should set elements input_file_size through input_file_size + output_file_size - 1
  //with the elements of the output for the computation.

  output_file_size = 1; 
  int VARS = 0;
  int OUTPUT = input_file_size;
  mpq_set_ui(qF1[OUTPUT + 0], 0, 1);
  if (poly_degree == 4)
  {
    int a[4];
    int k = 0;
    for(a[0] = -1; a[0] < m; a[0]++){
      for(a[1] = a[0]; a[1] < m; a[1]++){
	for(a[2] = a[1]; a[2] < m; a[2]++){
	  for(a[3] = a[2]; a[3] < m; a[3]++){
	    mpq_set(tempq, poly_coeffs_q[k]);
	    for(int i = 0; i < 4; i++){
	      if (a[i] != -1){
		mpq_mul(tempq, tempq, qF1[VARS + a[i]]);
	      }		
	    }
	    mpq_add(qF1[OUTPUT + 0], qF1[OUTPUT + 0], tempq);
	    k++;	     
	  }
	}
      }
    }
  } else if (poly_degree == 2)
  {    
    int k = 0;
    int a[2];
    for(a[0] = -1; a[0] < m; a[0]++){
      for(a[1] = a[0]; a[1] < m; a[1]++){
	mpq_set(tempq, poly_coeffs_q[k]);
	for(int i = 0; i < 2; i++){
	  if (a[i] != -1){
	    mpq_mul(tempq, tempq, qF1[VARS + a[i]]);
	  }
	}
	mpq_add(qF1[OUTPUT + 0], qF1[OUTPUT + 0], tempq);
	k++;
      }
    }
    //cout << "Cooeficients: " << k << endl;
  } else {
    cout << "ERROR: evaluation only implemented for degree 2,4 polynomials thus far." << endl;
  }
}

//PROVER's CODE
void PolyevalDnQProver::
prover_computation_commitment()
{
  // execute the computation
  load_vector(expansion_factor*num_variables, f1_commitment, (char *)"f1_commitment_query", FOLDER_WWW_DOWNLOAD);
  load_vector(expansion_factor*num_variables2, f2_commitment, (char *)"f2_commitment_query", FOLDER_WWW_DOWNLOAD);
 
  //The first input_file_size elements of qF1 are filled with the content of the input file.
  snprintf(scratch_str, BUFLEN-1, "input_coeffs_q");
  load_vector(num_poly_coeffs, poly_coeffs_q, scratch_str, FOLDER_WWW_DOWNLOAD);
  snprintf(scratch_str, BUFLEN-1, "input_coeffs");
  load_vector(num_poly_coeffs, poly_coeffs, scratch_str, FOLDER_WWW_DOWNLOAD);
 
  for (int i=batch_start; i<=batch_end; i++)
  {
    m_comp.begin_with_init(); 
    
    input_file_size = m; 
    snprintf(scratch_str, BUFLEN-1, "input_b_%d", i);
    load_vector(input_file_size, qF1 + 0, scratch_str, FOLDER_WWW_DOWNLOAD);

    //The next output_file_size elements of qF1 are filled with the output size.
    computation_polyeval_dn_q();

    //The remainder of qF1 is filled with intermediate proof variables. These are autogenerated.
    ConstraintGenerator cg(prime);
    cg.init_p(qF1);

    proof.polyeval_dn_q_proof(cg, m, poly_degree, num_poly_coeffs, poly_coeffs, n_a, n_b);

    convert_to_z(num_variables, F1, qF1, prime);

    // Useful for debugging. 
    //for(int j = 0; j < num_poly_coeffs; j++){
    //  gmp_printf("%Zd\n", poly_coeffs[j]); 
    //}
    

    //Compute F2
    int index = 0;
    for (int a = 0; a < num_variables; a++){
      for(int b = 0; b < a; b++){
	mpz_set(F2[index], F2[b*num_variables + a]);
	index++;
      }
      for(int b = a; b < num_variables; b++){
	mpz_mul(F2[index], F1[a], F1[b]);
	index++;
      }
    }

    // start saving the state
    snprintf(scratch_str, BUFLEN-1, "output_b_%d", i); 
    dump_vector(output_file_size, qF1 + input_file_size, scratch_str, FOLDER_WWW_DOWNLOAD);

    snprintf(scratch_str, BUFLEN-1, "outputz_b_%d", i); 
    dump_vector(output_file_size, F1 + input_file_size, scratch_str, FOLDER_WWW_DOWNLOAD);
    m_comp.end();
    
    snprintf(scratch_str, BUFLEN-1, "f1_assignment_vector_b_%d", i); 
    dump_vector(num_variables, F1, scratch_str, FOLDER_WWW_DOWNLOAD);
    
    snprintf(scratch_str, BUFLEN-1, "f2_assignment_vector_b_%d", i); 
    dump_vector(num_variables2, F2, scratch_str, FOLDER_WWW_DOWNLOAD);
  }

  for (int i=batch_start; i<=batch_end; i++)
  { 
    if (i == 0)
      m_proof_work.begin_with_init();
    else
      m_proof_work.begin_with_history();

    snprintf(scratch_str, BUFLEN-1, "f1_assignment_vector_b_%d", i); 
    load_vector(num_variables, F1, scratch_str, FOLDER_WWW_DOWNLOAD);
    
    snprintf(scratch_str, BUFLEN-1, "f2_assignment_vector_b_%d", i); 
    load_vector(num_variables2, F2, scratch_str, FOLDER_WWW_DOWNLOAD);

    if (crypto_in_use == CRYPTO_ELGAMAL)
      v->dot_product_enc(num_variables, f1_commitment, F1, output[0], output[1]);
    
    snprintf(scratch_str, BUFLEN-1, "f1_commitment_answer_b_%d", i); 
    dump_vector(expansion_factor, output, scratch_str, FOLDER_WWW_DOWNLOAD);
  
    if (crypto_in_use == CRYPTO_ELGAMAL)
      v->dot_product_enc(num_variables2, f2_commitment, F2, output[0], output[1]);
    
    snprintf(scratch_str, BUFLEN-1, "f2_commitment_answer_b_%d", i); 
    dump_vector(expansion_factor, output, scratch_str, FOLDER_WWW_DOWNLOAD);
    m_proof_work.end();
  }

}

void PolyevalDnQProver::deduce_answers()
{
  //q1, q2, q4 => q3. 
  mpz_init_set_ui(f_answers[Q3], 0);
  mpz_t tmp;
  mpz_init_set_ui(tmp, 1);
  mpz_mul(tmp, f_answers[Q1], f_answers[Q2]);
  mpz_add(f_answers[Q3], tmp, f_answers[Q4]);
}

