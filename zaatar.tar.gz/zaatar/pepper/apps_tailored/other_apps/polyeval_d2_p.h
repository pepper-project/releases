#ifndef CODE_PEPPER_APPS_POLYEVAL_D2_P_H_
#define CODE_PEPPER_APPS_POLYEVAL_D2_P_H_

#include <libv/prover.h>

#define PROVER_NAME "polyeval_d2"
#define NUM_LIN_PCP_QUERIES 6
#define Q1 0 
#define Q2 1
#define Q3 2
#define Q4 3
#define Q5 4
#define Q6 5

class PolyEvalD2Prover : public Prover {
  private:
    mpz_t *variables, *coefficients, *output, *F1, *F2;
    mpz_t *f1_commitment, *f2_commitment;
    mpz_t *f1_consistency, *f2_consistency;
    mpz_t *f1_q, *f2_q, *f1_q2, *f2_q2, *f1_q3, *f2_q3;
    int num_coefficients;
    mpz_t *alpha, neg;

  public:
    PolyEvalD2Prover(int, int, int, int);
    void init_state();
    void find_cur_qlengths();
    void prover_computation_commitment();
    void computation_polyeval(mpz_t);
    void computation_assignment(mpz_t);
    void deduce_queries();
};

#endif  // CODE_PEPPER_APPS_POLYEVAL_D2_P_H_
