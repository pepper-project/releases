#include <apps/graph_embedding_v.h>
#include <apps/graph_embedding_p.h>

bool MICROBENCHMARKS = false;

// driver to run the phases of the verifier and the prover
// this doesn't ever seem to contain any problem-specific code.
int main(int argc, char **argv)
{
  int phase;
  int batch_size;
  int num_repetitions;
  char prover_url[BUFLEN];
  int variant;

  int input_size; 
  char actor;

  parse_args(argc, argv, &actor, &phase, &batch_size, &num_repetitions,
    &input_size, prover_url, &variant);
  int optimize_answers = 1;

#ifdef INTERFACE_MPI

  MPI_Init(&argc, &argv);
  int rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

  if (rank == 0) {  // verifier
    GraphEmbeddingVerifier verifier(batch_size, num_repetitions, input_size,
      optimize_answers, prover_url);          
    if (variant == VARIANT_PEPPER)
      verifier.begin_pepper();
    else
      verifier.begin_habanero();
  } else {  // prover
    GraphEmbeddingProver prover(0 /*phase*/, batch_size, num_repetitions, input_size);
    prover.handle_requests();
  }

#else
  if (actor == 'v') {
  GraphEmbeddingVerifier verifier(batch_size, num_repetitions, input_size,
        optimize_answers, prover_url);

    if (variant == VARIANT_PEPPER)
      verifier.begin_pepper();
    else
      verifier.begin_habanero();
  } else {
    if (argc > 2)
    {
      GraphEmbeddingProver prover(phase, batch_size, num_repetitions, input_size);
      prover.handle_terminal_request();
    }
    else
    {
      phase = 0;
      batch_size = 100;
      num_repetitions = 1;
      input_size = 200;
      GraphEmbeddingProver prover(phase, batch_size, num_repetitions, input_size);
      prover.handle_http_requests();
    }
  }
#endif

   return 0;
}
