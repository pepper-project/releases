#ifndef CODE_PEPPER_APPS_MATRIX_CUBICP_V_H_
#define CODE_PEPPER_APPS_MATRIX_CUBICP_V_H_

#include <libv/verifier.h>

#define NAME_PROVER "lt"
#define NUM_LIN_PCP_QUERIES_F1 2
#define NUM_LIN_PCP_QUERIES_F2 3
#define NUM_LIN_PCP_QUERIES_F3 3
#define NUM_LIN_PCP_QUERIES_F4 3
#define Q1 0
#define Q2 1
#define Q3 2 
#define Q4 3
#define Q5 4
#define Q6 5
#define Q7 6
#define Q8 7
#define Q9 8
#define Q10 9
#define Q11 10

#ifdef INTERFACE_MPI
#include <apps/knn_p.h>
#endif

class KNNVerifier : public Verifier {
  private:
    mpz_t *f1_commitment, *f1_consistency;
    mpz_t *f3_commitment, *f3_consistency;
    mpz_t *f4_commitment, *f4_consistency;
    mpz_t *Fin, *A, *C;
    mpz_t *f1_q1, *f1_q2, *f1_q3;
    mpz_t *f3_q1, *f3_q2, *f3_q3;
    mpz_t *f4_q1, *f4_q2, *f4_q3;
    mpz_t *f2_q1, *f2_q2;
    mpz_t *f1_con_coins, *f3_con_coins, *f4_con_coins;
    mpz_t *gamma;
    mpz_t temp, temp2, f1_s, f3_s, f4_s, a1, a2, a3, a4, a5;
    mpz_t *f1_answers, *f2_answers, *ckt_answers;
    mpz_t *f3_answers, *f4_answers;
    mpz_t *temp_arr, *temp_arr2, *temp_arr3;
    int hadamard_code_size;
    int hadamard_code_size2, num_vars2, num_cons2;
    int m, n;
    int f3_con_filled, f4_con_filled;
  public:
    KNNVerifier(int batch, int reps, int ip_size, int optimize_answers, char *prover_url);
    void init_state();
    void create_input();
    void create_plain_queries();
    void run_correction_and_circuit_tests(uint32_t beta);
    void populate_answers(mpz_t *f_answers, int rho, int num_repetitions, int beta);
};
#endif  // CODE_PEPPER_APPS_MATRIX_CUBICP_V_H_
