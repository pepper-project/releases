#include <apps/knn_p.h>
#define NUM_BITS_PRIME 128
#define NUM_BITS_INPUT 32

KNNProver::
KNNProver(int ph, int b_size, int num_r, int input_size)
  : Prover(ph, b_size, num_r, input_size, PROVER_NAME) {
  m = 2*input_size+1;
  n = 32;
  init_state();
}

void KNNProver::
init_state() {
  cout<<"m is "<<m<<endl;
  num_bits_in_prime = NUM_BITS_PRIME;
  num_bits_in_input = NUM_BITS_INPUT;
  crypto_in_use = CRYPTO_ELGAMAL;
  png_in_use = PNG_CHACHA;
  cout<<"Running the prover with a prime of size "<<num_bits_in_prime<<endl;

  Prover::init_state();


  hadamard_code_size = m*m*n;
  num_vars2 = 83;
  hadamard_code_size2 = num_vars2*num_vars2;
  num_lin_pcp_queries = NUM_LIN_PCP_QUERIES;

  alloc_init_vec(&F1, hadamard_code_size);
  alloc_init_vec(&F3, num_vars2);
  alloc_init_vec(&F4, hadamard_code_size2);

  alloc_init_vec(&A, m*n);
  alloc_init_vec(&C, 3);
  Fin = &A[(m-1)*n];

  alloc_init_vec(&output, expansion_factor);
  alloc_init_vec(&f1_commitment, expansion_factor*hadamard_code_size);
  alloc_init_vec(&f1_q1, hadamard_code_size);
  alloc_init_vec(&f1_q2, hadamard_code_size);
  alloc_init_vec(&f1_q3, hadamard_code_size);

  alloc_init_vec(&f3_commitment, expansion_factor*num_vars2);
  alloc_init_vec(&f3_q, num_vars2);
  alloc_init_vec(&f3_q2, num_vars2);
  alloc_init_vec(&f3_q3, num_vars2);

  alloc_init_vec(&f4_commitment, expansion_factor*hadamard_code_size2);
  alloc_init_vec(&f4_q, hadamard_code_size2);
  alloc_init_vec(&f4_q2, hadamard_code_size2);
  alloc_init_vec(&f4_q3, hadamard_code_size2);

  alloc_init_vec(&f2_q1, m*m);
  alloc_init_vec(&f2_q2, m*m);
  alloc_init_vec(&f_answers, num_lin_pcp_queries);
  alloc_init_scalar(answer);
  alloc_init_scalar(temp);

  F_ptrs.clear();
  F_ptrs.push_back(F1);
  F_ptrs.push_back(F3);
  F_ptrs.push_back(F4);

  f_q_ptrs.clear();
  f_q_ptrs.push_back(f1_q1);
  f_q_ptrs.push_back(f3_q);
  f_q_ptrs.push_back(f4_q);

  f_q2_ptrs.clear();
  f_q2_ptrs.push_back(f1_q2);
  f_q2_ptrs.push_back(f3_q2);
  f_q2_ptrs.push_back(f4_q2);


  find_cur_qlengths();
}

void KNNProver::
find_cur_qlengths() {
  sizes.clear();
  sizes.push_back(hadamard_code_size);
  sizes.push_back(num_vars2);
  sizes.push_back(hadamard_code_size2);

  qquery_sizes.clear();
  qquery_sizes.push_back(hadamard_code_size);
  qquery_sizes.push_back(hadamard_code_size);
  qquery_sizes.push_back(hadamard_code_size);
  qquery_sizes.push_back(num_vars2);
  qquery_sizes.push_back(num_vars2);
  qquery_sizes.push_back(hadamard_code_size2);
  qquery_sizes.push_back(hadamard_code_size2);
  qquery_sizes.push_back(num_vars2);
  qquery_sizes.push_back(hadamard_code_size2);

  qquery_f_ptrs.clear();
  qquery_f_ptrs.push_back(f1_q1);
  qquery_f_ptrs.push_back(f1_q1);
  qquery_f_ptrs.push_back(f1_q1);
  qquery_f_ptrs.push_back(f3_q);
  qquery_f_ptrs.push_back(f3_q);
  qquery_f_ptrs.push_back(f4_q);
  qquery_f_ptrs.push_back(f4_q);
  qquery_f_ptrs.push_back(f3_q);
  qquery_f_ptrs.push_back(f4_q);


  qquery_F_ptrs.clear();
  qquery_F_ptrs.push_back(F1);
  qquery_F_ptrs.push_back(F1);
  qquery_F_ptrs.push_back(F1);

  qquery_F_ptrs.push_back(F3);
  qquery_F_ptrs.push_back(F3);
  qquery_F_ptrs.push_back(F4);
  qquery_F_ptrs.push_back(F4);

  qquery_F_ptrs.push_back(F3);
  qquery_F_ptrs.push_back(F4);


  qquery_q_ptrs.clear();
  qquery_q_ptrs.push_back(Q3);
  qquery_q_ptrs.push_back(Q4);
  qquery_q_ptrs.push_back(Q5);
  qquery_q_ptrs.push_back(Q6);
  qquery_q_ptrs.push_back(Q7);
  qquery_q_ptrs.push_back(Q8);
  qquery_q_ptrs.push_back(Q9);
  qquery_q_ptrs.push_back(Q10);
  qquery_q_ptrs.push_back(Q11);
}

void KNNProver::
computation_matrixmult() {
  int index, index2;
  mpz_t temp;
  mpz_init(temp);

  // distance 1
  mpz_set_ui(C[1], 0);
  for (int i=0; i<(m-1)/2; i++) {
    for (int j=0; j<n; j++) {
      index = i*n+j;
      index2 = (m-1)*n+j;
      mpz_sub(temp, A[index], A[index2]);
      mpz_mul(temp, temp, temp);
      mpz_add(C[1], C[1], temp);
    }
  }

  // distance 2
  mpz_set_ui(C[2], 0);
  for (int i=(m-1)/2; i<(m-1); i++) {
    for (int j=0; j<n; j++) {
      index = i*n+j;
      index2 = (m-1)*n+j;
      mpz_sub(temp, A[index], A[index2]);
      mpz_mul(temp, temp, temp);
      mpz_add(C[2], C[2], temp);
    }
  }

  if (mpz_cmp(C[1], C[2]) <= 0)
    mpz_set_ui(C[0], 0);
  else
    mpz_set_ui(C[0], 1);
}

void KNNProver::
computation_assignment() {
  int index;
  for (int i = 0; i < m; i++) {
    for (int j = 0; j < m; j++) {
      for (int k = 0; k < n; k++) {
        index = (i*m+j)*n+k;
        mpz_mul(F1[index], A[i * n + k], A[j * n + k]);
        mpz_mod(F1[index], F1[index], prime);
      }
    }
  }

  // fill in F3 and F4
  mpz_set(F3[num_vars2-1], C[0]);
  mpz_set(F3[num_vars2-2], C[2]);
  mpz_set(F3[num_vars2-3], C[1]);

  if (mpz_cmp_ui(C[0], 0) == 0)
    mpz_sub(temp, C[2], C[1]);
  else
    mpz_sub(temp, C[1], C[2]);

  for (int i=0; i<num_vars2-3; i++)
    mpz_set_ui(F3[i], mpz_tstbit(temp, i));

  for (int i=0; i<num_vars2; i++)
    mpz_mod(F3[i], F3[i], prime);

  for (int i=0; i<num_vars2; i++)
    for (int j=0; j<num_vars2; j++) {
      mpz_mul(F4[i*num_vars2+j], F3[i], F3[j]);
      mpz_mod(F4[i*num_vars2+j], F4[i*num_vars2+j], prime);
    }
}

//PROVER's CODE
void KNNProver::
prover_computation_commitment() {
  // init prover
  load_vector(expansion_factor*hadamard_code_size, f1_commitment, (char *)"f1_commitment_query", FOLDER_WWW_DOWNLOAD);
  load_vector(expansion_factor*num_vars2, f3_commitment, (char *)"f2_commitment_query", FOLDER_WWW_DOWNLOAD);
  load_vector(expansion_factor*hadamard_code_size2, f4_commitment, (char *)"f3_commitment_query", FOLDER_WWW_DOWNLOAD);

  m_computation.begin_with_init();
  snprintf(scratch_str, BUFLEN-1, "input0");
  load_vector((m-1)*n, A, scratch_str, FOLDER_WWW_DOWNLOAD);
  m_computation.end();

  for (int i=batch_start; i<=batch_end; i++) {
    m_computation.begin_with_history();
    snprintf(scratch_str, BUFLEN-1, "input1_b_%d", i);
    load_vector(n, Fin, scratch_str, FOLDER_WWW_DOWNLOAD);

    computation_matrixmult();

    // start saving the state
    snprintf(scratch_str, BUFLEN-1, "output_b_%d", i);
    dump_vector(1, C, scratch_str, FOLDER_WWW_DOWNLOAD);
    m_computation.end();

    computation_assignment();
    snprintf(scratch_str, BUFLEN-1, "f1_assignment_vector_b_%d", i);
    dump_vector(m*m*n, F1, scratch_str, FOLDER_WWW_DOWNLOAD);

    snprintf(scratch_str, BUFLEN-1, "f2_assignment_vector_b_%d", i);
    dump_vector(num_vars2, F3, scratch_str, FOLDER_WWW_DOWNLOAD);

    snprintf(scratch_str, BUFLEN-1, "f3_assignment_vector_b_%d", i);
    dump_vector(hadamard_code_size2, F4, scratch_str, FOLDER_WWW_DOWNLOAD);
  }

  for (int i=batch_start; i<=batch_end; i++) {
    if (i == 0)
      m_answer_queries.begin_with_init();
    else
      m_answer_queries.begin_with_history();

    snprintf(scratch_str, BUFLEN-1, "f1_assignment_vector_b_%d", i);
    load_vector(m*m*n, F1, scratch_str, FOLDER_WWW_DOWNLOAD);
    v->dot_product_enc(m*m*n, f1_commitment, F1, dotp[0], dotp[1]);

    snprintf(scratch_str, BUFLEN-1, "f2_assignment_vector_b_%d", i);
    load_vector(num_vars2, F3, scratch_str, FOLDER_WWW_DOWNLOAD);
    v->dot_product_enc(num_vars2, f3_commitment, F3, output[0], output[1]);

    v->add_enc(dotp[0], dotp[1], dotp[0], dotp[1], output[0], output[1]);

    snprintf(scratch_str, BUFLEN-1, "f3_assignment_vector_b_%d", i);
    load_vector(hadamard_code_size2, F4, scratch_str, FOLDER_WWW_DOWNLOAD);
    v->dot_product_enc(hadamard_code_size2, f4_commitment, F4, output[0], output[1]);

    v->add_enc(dotp[0], dotp[1], dotp[0], dotp[1], output[0], output[1]);

    snprintf(scratch_str, BUFLEN-1, "f_commitment_answer_b_%d", i);
    dump_vector(expansion_factor, dotp, scratch_str, FOLDER_WWW_DOWNLOAD);
    m_answer_queries.end();
  }
}

void KNNProver::deduce_queries() {
// Nothing to deduce.
}

