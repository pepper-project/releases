#ifndef CODE_PEPPER_APPS_POLYEVAL_DN_Q_PROOF_H_
#define CODE_PEPPER_APPS_POLYEVAL_DN_Q_PROOF_H_
#include <common/constraint_gen.h>

class PolyevalDnQProof{
public:
  PolyevalDnQProof();
  void polyeval_dn_q_proof(ConstraintGenerator& cg, int m, int poly_degree, int num_poly_coeffs, mpz_t* poly_coeffs, int n_a, int n_b);
private:
  mpz_t one, neg1;
};

#endif  //CODE_PEPPER_APPS_POLYEVAL_DN_Q_PROOF_H_
