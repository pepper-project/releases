#ifndef CODE_PEPPER_APPS_GRAPH_EMBEDDING_V_H_
#define CODE_PEPPER_APPS_GRAPH_EMBEDDING_V_H_
#include <libv/verifier.h>
#include <apps/graph_embedding_proof.h>
#include <papi.h>

#define NAME_PROVER "graph_embedding"
#define NUM_LIN_PCP_QUERIES_F1 3
#define NUM_LIN_PCP_QUERIES_F2 3
#define Q1 0
#define Q2 1
#define Q3 2 
#define Q4 3
#define Q5 4
#define Q6 5

#ifdef INTERFACE_MPI
#include <apps/graph_embedding_p.h>
#endif

class GraphEmbeddingVerifier : public Verifier {
  private:
    mpz_t *f1_commitment, *f2_commitment, *f1_consistency, *f2_consistency, *input, *output;
    mpq_t *q_output, *q_input;
    mpz_t *f1_q1, *f1_q2, *f1_q3, *ckt_cooefs1;
    mpz_t *f2_q1, *f2_q2, *f2_q3, *ckt_cooefs2;
    mpz_t *f1_con_coins, *f2_con_coins;
    mpz_t *gamma; //constraint multipliers
    mpz_t temp, temp2, temp3, temp4, temp_cvalue, temp_constraint, f1_s, f2_s, a1, a2;//, a3;
    mpz_t *f1_answers, *f2_answers, *ckt_answers;
    mpz_t *temp_arr, *temp_arr2;

    int num_variables, num_variables2, chi, m, input_file_size, output_file_size;
  
    GraphEmbeddingProof proof;

  public:
    GraphEmbeddingVerifier(int batch, int reps, int ip_size, int optimize_answers, char *prover_url);
    void init_state();
    void create_input();
    void create_constraint_term(mpz_t cooef, int i, int j, int constraintID);
    void create_circuit_test(int rho);
    void create_plain_queries();
    void run_correction_and_circuit_tests(uint32_t beta);
    void populate_answers(mpz_t *f_answers, int rho, int num_repetitions, int beta);
};
#endif  //CODE_PEPPER_APPS_CIRCLEPACKUS_Q_V_H_
