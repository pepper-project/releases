#include <apps/sample_v.h>

SampleVerifier::SampleVerifier(int
batch, int reps, int optimize_answers, char *prover_url, int in_size,
int out_size, int num_v, int num_c): ComputationVerifier(batch, reps,
in_size, out_size, optimize_answers, num_v, num_c, prover_url, (char *) NAME_PROVER)
{
}

void SampleVerifier::create_gamma0(int rho_i) {

  
  // parsing - c00 - 10*A00*B00 - A01*B01
    
  for (int i=0; i<batch_size; i++) {

    snprintf(scratch_str, BUFLEN-1, "input_b_%d", i); 
    load_vector(input_size, input, scratch_str);

    snprintf(scratch_str, BUFLEN-1, "output_b_%d", i); 
    load_vector(output_size, output, scratch_str);
  
    int c_index = i * num_repetitions + rho_i;
    mpz_set_str(temp, (char *)"-1", 10);
    mpz_mul(temp, alpha[0], temp);
    mpz_mul(temp, temp, input_output[8]);
    mpz_add(c_values[c_index], c_values[c_index], temp);
  }
      
  // parsing A00 - a00
    
  for (int i=0; i<batch_size; i++) {

    snprintf(scratch_str, BUFLEN-1, "input_b_%d", i); 
    load_vector(input_size, input, scratch_str);

    snprintf(scratch_str, BUFLEN-1, "output_b_%d", i); 
    load_vector(output_size, output, scratch_str);
  
    int c_index = i * num_repetitions + rho_i;
    mpz_set_str(temp, (char *)"-1", 10);
    mpz_mul(temp, alpha[1], temp);
    mpz_mul(temp, temp, input_output[0]);
    mpz_add(c_values[c_index], c_values[c_index], temp);
  }
      
  // parsing A01 - a01
    
  for (int i=0; i<batch_size; i++) {

    snprintf(scratch_str, BUFLEN-1, "input_b_%d", i); 
    load_vector(input_size, input, scratch_str);

    snprintf(scratch_str, BUFLEN-1, "output_b_%d", i); 
    load_vector(output_size, output, scratch_str);
  
    int c_index = i * num_repetitions + rho_i;
    mpz_set_str(temp, (char *)"-1", 10);
    mpz_mul(temp, alpha[2], temp);
    mpz_mul(temp, temp, input_output[1]);
    mpz_add(c_values[c_index], c_values[c_index], temp);
  }
      
  // parsing A10 - a10
    
  for (int i=0; i<batch_size; i++) {

    snprintf(scratch_str, BUFLEN-1, "input_b_%d", i); 
    load_vector(input_size, input, scratch_str);

    snprintf(scratch_str, BUFLEN-1, "output_b_%d", i); 
    load_vector(output_size, output, scratch_str);
  
    int c_index = i * num_repetitions + rho_i;
    mpz_set_str(temp, (char *)"-1", 10);
    mpz_mul(temp, alpha[3], temp);
    mpz_mul(temp, temp, input_output[2]);
    mpz_add(c_values[c_index], c_values[c_index], temp);
  }
      
  // parsing A11 - a11
    
  for (int i=0; i<batch_size; i++) {

    snprintf(scratch_str, BUFLEN-1, "input_b_%d", i); 
    load_vector(input_size, input, scratch_str);

    snprintf(scratch_str, BUFLEN-1, "output_b_%d", i); 
    load_vector(output_size, output, scratch_str);
  
    int c_index = i * num_repetitions + rho_i;
    mpz_set_str(temp, (char *)"-1", 10);
    mpz_mul(temp, alpha[4], temp);
    mpz_mul(temp, temp, input_output[3]);
    mpz_add(c_values[c_index], c_values[c_index], temp);
  }
      
  // parsing B00 - b00
    
  for (int i=0; i<batch_size; i++) {

    snprintf(scratch_str, BUFLEN-1, "input_b_%d", i); 
    load_vector(input_size, input, scratch_str);

    snprintf(scratch_str, BUFLEN-1, "output_b_%d", i); 
    load_vector(output_size, output, scratch_str);
  
    int c_index = i * num_repetitions + rho_i;
    mpz_set_str(temp, (char *)"-1", 10);
    mpz_mul(temp, alpha[5], temp);
    mpz_mul(temp, temp, input_output[4]);
    mpz_add(c_values[c_index], c_values[c_index], temp);
  }
      
  // parsing B01 - b01
    
  for (int i=0; i<batch_size; i++) {

    snprintf(scratch_str, BUFLEN-1, "input_b_%d", i); 
    load_vector(input_size, input, scratch_str);

    snprintf(scratch_str, BUFLEN-1, "output_b_%d", i); 
    load_vector(output_size, output, scratch_str);
  
    int c_index = i * num_repetitions + rho_i;
    mpz_set_str(temp, (char *)"-1", 10);
    mpz_mul(temp, alpha[6], temp);
    mpz_mul(temp, temp, input_output[5]);
    mpz_add(c_values[c_index], c_values[c_index], temp);
  }
      
  // parsing B10 - b10
    
  for (int i=0; i<batch_size; i++) {

    snprintf(scratch_str, BUFLEN-1, "input_b_%d", i); 
    load_vector(input_size, input, scratch_str);

    snprintf(scratch_str, BUFLEN-1, "output_b_%d", i); 
    load_vector(output_size, output, scratch_str);
  
    int c_index = i * num_repetitions + rho_i;
    mpz_set_str(temp, (char *)"-1", 10);
    mpz_mul(temp, alpha[7], temp);
    mpz_mul(temp, temp, input_output[6]);
    mpz_add(c_values[c_index], c_values[c_index], temp);
  }
      
  // parsing B11 - b11
    
  for (int i=0; i<batch_size; i++) {

    snprintf(scratch_str, BUFLEN-1, "input_b_%d", i); 
    load_vector(input_size, input, scratch_str);

    snprintf(scratch_str, BUFLEN-1, "output_b_%d", i); 
    load_vector(output_size, output, scratch_str);
  
    int c_index = i * num_repetitions + rho_i;
    mpz_set_str(temp, (char *)"-1", 10);
    mpz_mul(temp, alpha[8], temp);
    mpz_mul(temp, temp, input_output[7]);
    mpz_add(c_values[c_index], c_values[c_index], temp);
  }
      
}

void SampleVerifier::create_gamma12() {

  // generate one random coefficient per constraint
  v->get_random_vec(num_cons, alpha, prime);
  
  // empty the gamma_1 and gamma_2
  for (int i=0; i<num_vars; i++)
    mpz_set_ui(f1_q2[i], 0);
  
  for (int i=0; i<num_vars*num_vars; i++)
    mpz_set_ui(f2_q1[i], 0);
  
  
  // parsing - c00 - 10*A00*B00 - A01*B01
    
  mpz_set_str(temp, (char *)"-10", 0);
  mpz_mul(temp, alpha[0], temp);
  mpz_add(f2_q1[4], f2_q1[4], temp);
      
  mpz_set_str(temp, (char *)"-1", 0);
  mpz_mul(temp, alpha[0], temp);
  mpz_add(f2_q1[13], f2_q1[13], temp);
      
  // parsing A00 - a00
    
  mpz_set_str(temp, (char *)"1", 10);
  mpz_mul(temp, alpha[1], temp);
  mpz_add(f1_q2[0], f1_q2[0], temp);
      
  // parsing A01 - a01
    
  mpz_set_str(temp, (char *)"1", 10);
  mpz_mul(temp, alpha[2], temp);
  mpz_add(f1_q2[1], f1_q2[1], temp);
      
  // parsing A10 - a10
    
  mpz_set_str(temp, (char *)"1", 10);
  mpz_mul(temp, alpha[3], temp);
  mpz_add(f1_q2[2], f1_q2[2], temp);
      
  // parsing A11 - a11
    
  mpz_set_str(temp, (char *)"1", 10);
  mpz_mul(temp, alpha[4], temp);
  mpz_add(f1_q2[3], f1_q2[3], temp);
      
  // parsing B00 - b00
    
  mpz_set_str(temp, (char *)"1", 10);
  mpz_mul(temp, alpha[5], temp);
  mpz_add(f1_q2[4], f1_q2[4], temp);
      
  // parsing B01 - b01
    
  mpz_set_str(temp, (char *)"1", 10);
  mpz_mul(temp, alpha[6], temp);
  mpz_add(f1_q2[5], f1_q2[5], temp);
      
  // parsing B10 - b10
    
  mpz_set_str(temp, (char *)"1", 10);
  mpz_mul(temp, alpha[7], temp);
  mpz_add(f1_q2[6], f1_q2[6], temp);
      
  // parsing B11 - b11
    
  mpz_set_str(temp, (char *)"1", 10);
  mpz_mul(temp, alpha[8], temp);
  mpz_add(f1_q2[7], f1_q2[7], temp);
      
}
