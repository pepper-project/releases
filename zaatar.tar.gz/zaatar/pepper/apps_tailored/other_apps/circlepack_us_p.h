#ifndef CODE_PEPPER_APPS_CIRCLEPACK_US_P_H_
#define CODE_PEPPER_APPS_CIRCLEPACK_US_P_H_
#include <libv/prover.h>
#include <apps/circlepack_us_proof.h>

#define PROVER_NAME "/circlepack_us_p"
#define NUM_LIN_PCP_QUERIES 6
#define Q1 0 
#define Q2 1
#define Q3 2
#define Q4 3
#define Q5 4
#define Q6 5

class CirclePackUSProver : public Prover {
  
  private:
    mpz_t *output, *f1_commitment, *f2_commitment, *f1_q1, *f1_q2, *f2_q1, *f2_q2, *F1, *F2;
    mpq_t *qF1;
    int num_variables, num_variables2;
    CirclePackUSProof proof;

  public:
    CirclePackUSProver(int, int, int, int);
    void init_state();
    void find_cur_qlengths();
    void prover_computation_commitment();
    void computation_circlePacking();
    void deduce_answers();
};
#endif  
