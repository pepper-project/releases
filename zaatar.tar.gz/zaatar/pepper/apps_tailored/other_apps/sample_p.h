#ifndef CODE_PEPPER_APPS_sample_P_H_
#define CODE_PEPPER_APPS_sample_P_H_

#include <libv/computation_p.h>

#define PROVER_NAME "sample"
    
class SampleProver : public ComputationProver {
  public:
    SampleProver(int ph, int b_size, int num_r, int in_size, int out_size, int num_v, int num_c);
    void computation();
    void compute_assignment_vectors();
};
#endif  // CODE_PEPPER_APPS_sample_P_H_
