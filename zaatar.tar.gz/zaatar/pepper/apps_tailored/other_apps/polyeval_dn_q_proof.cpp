#include<apps/polyeval_dn_q_proof.h>
#include<common/utility.h>
#include<gmp.h>

PolyevalDnQProof::PolyevalDnQProof()
{
  alloc_init_scalar(one);
  alloc_init_scalar(neg1);
  mpz_set_si(one, 1); 
  mpz_set_si(neg1, -1); 
}

void PolyevalDnQProof::polyeval_dn_q_proof(ConstraintGenerator& cg, int m, int poly_degree, int num_poly_coeffs, mpz_t* poly_coeffs, int n_a, int n_b){
  int VARS = 0;
  cg.create_new_variables(m);
  int OUTPUT = cg.create_new_variables(1);

  int io_size = OUTPUT + 1;

  //Input / Output matching constraints.
  for(int i = 0; i < io_size; i++){
    int poly = cg.create_new_constraint();
    cg.add_term(one, i, -1, poly);
    //These are unfinished constraints, the i/o dependent terms will be added to gamma_0 by the verifier.
  }

  if (poly_degree == 2){
    int poly = cg.create_new_constraint(); 
    int a[2];
    int k = 0;
    for(a[0] = -1; a[0] < m; a[0]++){
      for(a[1] = a[0]; a[1] < m; a[1]++){
	cg.add_term(poly_coeffs[k], a[0], a[1], poly);
	k++;
      }
    }
    cg.add_term(neg1, OUTPUT + 0, -1, poly);
    //cout << "Coeffients: " << k << endl;
  } else if (poly_degree == 4){
    int VAR_SQUARED = -1; 
    for(int a = -1; a < m; a++){
      for(int b = -1; b < m; b++){
	int prod = cg.create_product(a, b);	
	if ((a == -1) && (b == -1)){
	  VAR_SQUARED = prod;
	}
      }
    }
    int poly = cg.create_new_constraint(); 
    int a[4];
    int k = 0;
    for(a[0] = -1; a[0] < m; a[0]++){
      for(a[1] = a[0]; a[1] < m; a[1]++){
	for(a[2] = a[1]; a[2] < m; a[2]++){
	  for(a[3] = a[2]; a[3] < m; a[3]++){
	    cg.add_term(poly_coeffs[k], VAR_SQUARED + (a[0] + 1) * (m+1) + (a[1] + 1), VAR_SQUARED + (a[2] + 1) * (m+1) + (a[3] + 1), poly);
	    k++;
	  }
	}
      }
    }
    cg.add_term(neg1, OUTPUT + 0, -1, poly);
   
  } else {
    cout << "ERROR: Only degree 2,4 polynomial evaluation implemented. " << endl;
  }
}
