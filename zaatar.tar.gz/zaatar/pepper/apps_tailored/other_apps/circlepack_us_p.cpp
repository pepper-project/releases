#include <apps/circlepack_us_p.h>

CirclePackUSProver::
CirclePackUSProver(int ph, int b_size, int num_r, int input_size)
  : Prover(ph, b_size, num_r, input_size, PROVER_NAME)
{
  init_state();
}

void CirclePackUSProver::
init_state()
{
  num_bits_in_prime = 320;
  num_bits_in_input = 32;
  crypto_in_use = CRYPTO_ELGAMAL;
  png_in_use = PNG_CHACHA;
 
  Prover::init_state();
 
  num_lin_pcp_queries = NUM_LIN_PCP_QUERIES;
  ConstraintGenerator cg(prime);
  cg.init_size();

  proof.circlepack_us_proof(cg, m);

  num_variables = cg.variables_size();
  num_variables2 = num_variables*num_variables;
  
  alloc_init_vec(&F1, num_variables);
  alloc_init_vec(&F2, num_variables2);
  alloc_init_vec(&qF1, num_variables);
  alloc_init_vec(&output, expansion_factor);
  alloc_init_vec(&f1_commitment, expansion_factor*num_variables);
  alloc_init_vec(&f2_commitment, expansion_factor*num_variables2);
  alloc_init_vec(&f1_q1, num_variables);
  //alloc_init_vec(&f1_q2, hadamard_code_size);
  alloc_init_vec(&f2_q1, num_variables2);
  //alloc_init_vec(&f2_q2, m*m);

  alloc_init_vec(&f_answers, num_lin_pcp_queries);
  alloc_init_scalar(answer);

  F_ptrs.clear(); 
  F_ptrs.push_back(F1);
  F_ptrs.push_back(F2);
  //passed to prover_answer_query
  f_q_ptrs.clear();
  f_q_ptrs.push_back(f1_q1);
  f_q_ptrs.push_back(f2_q1);
  //doesn't seem to be used
  //f_q2_ptrs.clear();
  //f_q2_ptrs.push_back(f1_q2);
  //f_q2_ptrs.push_back(f2_q2);
  
  find_cur_qlengths();
}

void CirclePackUSProver::
find_cur_qlengths()
{
  sizes.clear();
  sizes.push_back(num_variables);
  sizes.push_back(num_variables2);
  
  qquery_sizes.clear();
  qquery_sizes.push_back(num_variables);
  qquery_sizes.push_back(num_variables);
  qquery_sizes.push_back(num_variables2);
  qquery_sizes.push_back(num_variables);
  qquery_sizes.push_back(num_variables2);
  qquery_f_ptrs.clear();
  qquery_f_ptrs.push_back(f1_q1);
  qquery_f_ptrs.push_back(f1_q1);
  qquery_f_ptrs.push_back(f2_q1);
  qquery_f_ptrs.push_back(f1_q1);
  qquery_f_ptrs.push_back(f2_q1);
  qquery_F_ptrs.clear();
  qquery_F_ptrs.push_back(F1);
  qquery_F_ptrs.push_back(F1);
  qquery_F_ptrs.push_back(F2);
  qquery_F_ptrs.push_back(F1);
  qquery_F_ptrs.push_back(F2);
}

void CirclePackUSProver::
computation_circlePacking()
{
  int input_file_size = m;
  int POINTS = input_file_size;
  //Insert the points into the proof
  for (int i=0; i<m; i++){
    mpq_set_ui(qF1[POINTS + i*2], (i+1), 4);
    mpq_canonicalize(qF1[POINTS + i*2]);
    mpq_set_ui(qF1[POINTS + i*2+1], (i+1), 4);
    mpq_canonicalize(qF1[POINTS + i*2+1]);
  }

  //The constraint generator computes the necessary intermediate proof values
  ConstraintGenerator cg(prime);
  cg.init_p(qF1);

  proof.circlepack_us_proof(cg, m);

  convert_to_z(num_variables, F1, qF1, prime);
  /* 
  for(int i = 0; i < num_variables; i++){
    gmp_printf("%Zd\n", F1[i]); 
  }
  */

  //Compute F2
  int index = 0;
  for (int i = 0; i < num_variables; i++){
    for(int j = 0; j < i; j++){
      mpz_set(F2[index], F2[j*num_variables + i]);
      index++;
    }
    for(int j = i; j < num_variables; j++){
      mpz_mul(F2[index], F1[i], F1[j]);
      index++;
    }
  }
}


//PROVER's CODE
void CirclePackUSProver::
prover_computation_commitment()
{
  // execute the computation
  load_vector(expansion_factor*num_variables, f1_commitment, (char *)"f1_commitment_query", FOLDER_WWW_DOWNLOAD);
  load_vector(expansion_factor*num_variables2, f2_commitment, (char *)"f2_commitment_query", FOLDER_WWW_DOWNLOAD);
  
  for (int i=batch_start; i<=batch_end; i++)
  {
    m_comp.begin_with_init(); 

    //The first input_file_size elements of qF1 are filled with the content of the input file.
    int input_file_size = m; //TODO: Fill this with the correct number of numbers in the input
    snprintf(scratch_str, BUFLEN-1, "input_b_%d", i);
    load_vector(input_file_size, qF1 + 0, scratch_str, FOLDER_WWW_DOWNLOAD);

    computation_circlePacking();

    // start saving the state

    //TODO: only output the actual points, not the whole F1 assignment.
    int output_file_size = m*2;
    snprintf(scratch_str, BUFLEN-1, "output_b_%d", i); 
    dump_vector(output_file_size, qF1 + input_file_size, scratch_str, FOLDER_WWW_DOWNLOAD);

    snprintf(scratch_str, BUFLEN-1, "outputz_b_%d", i); 
    dump_vector(output_file_size, F1 + input_file_size, scratch_str, FOLDER_WWW_DOWNLOAD);
    m_comp.end();
    
    snprintf(scratch_str, BUFLEN-1, "f1_assignment_vector_b_%d", i); 
    dump_vector(num_variables, F1, scratch_str, FOLDER_WWW_DOWNLOAD);
    
    snprintf(scratch_str, BUFLEN-1, "f2_assignment_vector_b_%d", i); 
    dump_vector(num_variables2, F2, scratch_str, FOLDER_WWW_DOWNLOAD);
  }

  for (int i=batch_start; i<=batch_end; i++)
  { 
    if (i == 0)
      m_proof_work.begin_with_init();
    else
      m_proof_work.begin_with_history();

    snprintf(scratch_str, BUFLEN-1, "f1_assignment_vector_b_%d", i); 
    load_vector(num_variables, F1, scratch_str, FOLDER_WWW_DOWNLOAD);
    
    snprintf(scratch_str, BUFLEN-1, "f2_assignment_vector_b_%d", i); 
    load_vector(num_variables2, F2, scratch_str, FOLDER_WWW_DOWNLOAD);

    //if (crypto_in_use == CRYPTO_ELGAMAL)
    v->dot_product_enc(num_variables, f1_commitment, F1, output[0], output[1]);
    
    snprintf(scratch_str, BUFLEN-1, "f1_commitment_answer_b_%d", i); 
    dump_vector(expansion_factor, output, scratch_str, FOLDER_WWW_DOWNLOAD);
  
    //if (crypto_in_use == CRYPTO_ELGAMAL)
    v->dot_product_enc(num_variables2, f2_commitment, F2, output[0], output[1]);
    
    snprintf(scratch_str, BUFLEN-1, "f2_commitment_answer_b_%d", i); 
    dump_vector(expansion_factor, output, scratch_str, FOLDER_WWW_DOWNLOAD);
    m_proof_work.end();
  }

}

void CirclePackUSProver::deduce_answers()
{
  //q1, q2, q4 => q3. See circlepack_us_v.cpp, which never sends q3
  mpz_init_set_ui(f_answers[Q3], 0);
  mpz_t tmp;
  mpz_init_set_ui(tmp, 1);
  mpz_mul(tmp, f_answers[Q1], f_answers[Q2]);
  mpz_add(f_answers[Q3], tmp, f_answers[Q4]);
}

