#include <apps/knn_v.h>
#define NUM_BITS_PRIME 128
#define NUM_BITS_INPUT 32

KNNVerifier::KNNVerifier(int batch, int reps, int
                         ip_size, int optimize_answers, char *prover_url)
  : Verifier(batch, reps, ip_size, optimize_answers, prover_url, NAME_PROVER) {
  // convert input size into 2 clusters: each of size m vectors of size
  // n and space of one fingerprint vector of size n
  m = 2*ip_size+1;
  n = 32;
  init_state();
}

void KNNVerifier::init_state() {
  cout<<"m is "<<m<<endl;
  num_bits_in_prime = NUM_BITS_PRIME;
  num_bits_in_input = NUM_BITS_INPUT;
  crypto_in_use = CRYPTO_ELGAMAL;
  png_in_use = PNG_CHACHA;
  cout<<"Running verifier with a prime of size "<<num_bits_in_prime<<endl;

  hadamard_code_size = m * m * n;
  num_vars2 = 83; // F3 & F4 (80 vars for bits of difference, one for D1, another for D2)
  num_cons2 = 83;
  hadamard_code_size2 = num_vars2 * num_vars2;
  num_lin_pcp_queries = NUM_LIN_PCP_QUERIES_F1 + NUM_LIN_PCP_QUERIES_F2 + NUM_LIN_PCP_QUERIES_F3 + NUM_LIN_PCP_QUERIES_F4;


  Verifier::init_state();


  alloc_init_vec(&A, m * n);
  Fin = &A[(m-1)*n];

  alloc_init_vec(&C, 3);
  alloc_init_vec(&f1_commitment, expansion_factor*hadamard_code_size);
  alloc_init_vec(&f1_consistency, hadamard_code_size);
  alloc_init_vec(&f1_q1, hadamard_code_size);
  alloc_init_vec(&f1_q2, hadamard_code_size);
  alloc_init_vec(&f1_q3, hadamard_code_size);
  alloc_init_vec(&f2_q1, m*n);
  alloc_init_vec(&f2_q2, m*n);

  alloc_init_vec(&f3_commitment, expansion_factor*num_vars2);
  alloc_init_vec(&f3_consistency, num_vars2);
  alloc_init_vec(&f3_q1, num_vars2);
  alloc_init_vec(&f3_q2, num_vars2);
  alloc_init_vec(&f3_q3, num_vars2);

  alloc_init_vec(&f4_commitment, expansion_factor*hadamard_code_size2);
  alloc_init_vec(&f4_consistency, hadamard_code_size2);
  alloc_init_vec(&f4_q1, hadamard_code_size2);
  alloc_init_vec(&f4_q2, hadamard_code_size2);
  alloc_init_vec(&f4_q3, hadamard_code_size2);

  alloc_init_vec(&gamma, 2 + num_cons2);
  alloc_init_vec(&f1_con_coins, num_repetitions * NUM_LIN_PCP_QUERIES_F2);
  alloc_init_vec(&f3_con_coins, num_repetitions * NUM_LIN_PCP_QUERIES_F3);
  alloc_init_vec(&f4_con_coins, num_repetitions * NUM_LIN_PCP_QUERIES_F4);

  alloc_init_vec(&f_answers, num_repetitions * num_lin_pcp_queries);
  alloc_init_vec(&f1_answers, num_repetitions * NUM_LIN_PCP_QUERIES_F2);
  alloc_init_vec(&f3_answers, num_repetitions * NUM_LIN_PCP_QUERIES_F3);
  alloc_init_vec(&f4_answers, num_repetitions * NUM_LIN_PCP_QUERIES_F4);

  alloc_init_vec(&ckt_answers, 6);
  alloc_init_vec(&temp_arr, expansion_factor);
  alloc_init_vec(&temp_arr2, expansion_factor);
  alloc_init_vec(&temp_arr3, expansion_factor);

  alloc_init_scalar(a1);
  alloc_init_scalar(a2);
  alloc_init_scalar(a3);
  alloc_init_scalar(a4);
  alloc_init_scalar(a5);
  alloc_init_scalar(f1_s);
  alloc_init_scalar(temp);
  alloc_init_scalar(temp2);

  // To create consistency and commitment queries.
  commitment_query_sizes.clear();
  commitment_query_sizes.push_back(hadamard_code_size);
  commitment_query_sizes.push_back(num_vars2);
  commitment_query_sizes.push_back(hadamard_code_size2);

  f_commitment_ptrs.clear();
  f_commitment_ptrs.push_back(f1_commitment);
  f_commitment_ptrs.push_back(f3_commitment);
  f_commitment_ptrs.push_back(f4_commitment);

  f_consistency_ptrs.clear();
  f_consistency_ptrs.push_back(f1_consistency);
  f_consistency_ptrs.push_back(f3_consistency);
  f_consistency_ptrs.push_back(f4_consistency);

  con_coins_ptrs.clear();
  con_coins_ptrs.push_back(f1_con_coins);
  con_coins_ptrs.push_back(f3_con_coins);
  con_coins_ptrs.push_back(f4_con_coins);

  temp_arr_ptrs.clear();
  temp_arr_ptrs.push_back(temp_arr);
  temp_arr_ptrs.push_back(temp_arr2);
  temp_arr_ptrs.push_back(temp_arr3);

  scalar_s_ptrs.clear();
  scalar_s_ptrs.push_back(&f1_s);
  scalar_s_ptrs.push_back(&f3_s);
  scalar_s_ptrs.push_back(&f4_s);

  scalar_a_ptrs.clear();
  scalar_a_ptrs.push_back(&a1);
  scalar_a_ptrs.push_back(&a4);
  scalar_a_ptrs.push_back(&a5);

  answers_rfetch_ptrs.clear();
  answers_rfetch_ptrs.push_back(f1_answers);
  answers_rfetch_ptrs.push_back(f3_answers);
  answers_rfetch_ptrs.push_back(f4_answers);

  answers_ptrs.clear();
  answers_ptrs.push_back(f1_answers);
  answers_ptrs.push_back(f3_answers);
  answers_ptrs.push_back(f4_answers);

  Q_list.clear();
  Q_list.push_back(Q1);
  Q_list.push_back(Q2);
  Q_list.push_back(Q3);
  Q_list.push_back(Q4);
  Q_list.push_back(Q5);
  Q_list.push_back(Q6);
  Q_list.push_back(Q7);
  Q_list.push_back(Q8);
  Q_list.push_back(Q9);
  Q_list.push_back(Q10);
  Q_list.push_back(Q11);

  pcp_queries.clear();
  pcp_queries.push_back(NUM_LIN_PCP_QUERIES_F2);
  pcp_queries.push_back(NUM_LIN_PCP_QUERIES_F1);
  pcp_queries.push_back(NUM_LIN_PCP_QUERIES_F3);
  pcp_queries.push_back(NUM_LIN_PCP_QUERIES_F4);
}

void KNNVerifier::create_input() {
  v->get_random_vec((m-1) * n, A, num_bits_in_input);
  dump_vector((m-1) * n, A, (char *)"input0");
  send_file(scratch_str);

  // as many computations as inputs
  for (int k=0; k<batch_size; k++) {
    v->get_random_vec(n, Fin, num_bits_in_input);
    snprintf(scratch_str, BUFLEN-1, "input1_b_%d", k);
    dump_vector(n, Fin, scratch_str);
    send_file(scratch_str);
  }
}

void KNNVerifier::create_plain_queries() {
  // keeps track of #filled coins
  int f1_con_filled = -1;
  int f3_con_filled = -1;
  int f4_con_filled = -1;

  for (int rho=0; rho<num_repetitions; rho++) {
    if (rho == 0) m_plainq.begin_with_init();
    else m_plainq.begin_with_history();

    // f1_q1 = q3
    // f1_q2 = q4
    // f2_q1 = q1
    // f2_q2 = q2
    v->create_corr_test_queries_vproduct2(m, n, f2_q1, f2_q2, f1_q1, f1_q2,
                                          f1_consistency, f1_con_filled, f1_con_coins, prime);

    snprintf(scratch_str, BUFLEN-1, "q3_qquery_r_%d", rho);
    dump_vector(hadamard_code_size, f1_q1, scratch_str);
    send_file(scratch_str);

    snprintf(scratch_str, BUFLEN-1, "q4_qquery_r_%d", rho);
    dump_vector(hadamard_code_size, f1_q2, scratch_str);
    send_file(scratch_str);

    f1_con_filled += 2;

    v->create_corr_test_queries(num_vars2, f3_q1, num_vars2, f3_q2,
                                f4_q1, f4_q2, f3_consistency, f3_consistency, f4_consistency,
                                f3_con_filled, f3_con_coins, f3_con_filled+1, f3_con_coins,
                                f4_con_filled, f4_con_coins, prime, false);

    f3_con_filled += 2;
    f4_con_filled += 2;

    snprintf(scratch_str, BUFLEN-1, "q6_qquery_r_%d", rho);
    dump_vector(num_vars2, f3_q1, scratch_str);
    send_file(scratch_str);

    snprintf(scratch_str, BUFLEN-1, "q7_qquery_r_%d", rho);
    dump_vector(num_vars2, f3_q2, scratch_str);
    send_file(scratch_str);

    snprintf(scratch_str, BUFLEN-1, "q9_qquery_r_%d", rho);
    dump_vector(hadamard_code_size2, f4_q2, scratch_str);
    send_file(scratch_str);

    snprintf(scratch_str, BUFLEN-1, "q8_qquery_r_%d", rho);
    dump_vector(hadamard_code_size2, f4_q1, scratch_str);
    send_file(scratch_str);

    m_plainq.end();

    if (rho == 0)
      m_runtests.begin_with_init();
    else
      m_runtests.begin_with_history();

    // compute answers to f1(q1) and f1(q2) locally now itself
    if (rho == 0) m_runtests.begin_with_init();
    load_vector((m-1)*n, A, "input0");
    // NOTE: this part can be made very efficient since most of matrix A
    // remains the same across the loop iterations. Only one row of A
    // changes between loop iterations.
    for (int b=0; b<batch_size; b++) {
      mpz_set_ui(a1, 0);
      mpz_set_ui(a2, 0);

      snprintf(scratch_str, BUFLEN-1, "input1_b_%d", b);
      load_vector(n, Fin, scratch_str);

      int index;
      mpz_set_ui(a3, 0);
      for (int k=0; k<n; k++) {
        // dot product of k^th col of A with k^th col of f2_q1
        //\sum_{j=1}{m}{A[k][j] \cdot f2_q1[k][j]}
        mpz_set_ui(a1, 0);
        mpz_set_ui(a2, 0);

        for (int j=0; j<m; j++) {
          index = j*n+k;
          mpz_mul(temp, A[index], f2_q1[index]);
          mpz_add(a1, a1, temp);
        }

        for (int i=0; i<m; i++) {
          index = k*m+i;
          // transpose of A
          mpz_mul(temp, A[i*n+k], f2_q2[index]);
          mpz_add(a2, a2, temp);
        }

        mpz_mul(temp, a1, a2);
        mpz_add(a3, a3, temp);
        mpz_mod(a3, a3, prime);
      }

      snprintf(scratch_str, BUFLEN-1, "corr_answer_b_%d_r_%d", b, rho);
      dump_scalar(a3, scratch_str);
    }
    m_runtests.end();

    // circuit test
    m_plainq.begin_with_history();
    v->get_random_vec(2, gamma, prime);

    for (int i=0; i<hadamard_code_size; i++)
      mpz_set_ui(f1_q1[i], 0);

    int index, index2;
    for (int i=0; i<(m-1)/2; i++) {
      for (int j=0; j<n; j++) {
        // -2 \cdot A_{i,j} \cdot B_{j, m-1}
        index = (i*m+m-1)*n+j;
        mpz_mul_ui(temp, gamma[0], 2);
        mpz_add(f1_q1[index], f1_q1[index], temp);

        // A_{i,j} \cdot B_{j,i}
        index = (i*m+i)*n+j;
        mpz_neg(temp, gamma[0]);
        mpz_add(f1_q1[index], f1_q1[index], temp);

        // A_{m-1,j} \cdot B_{j, m-1}
        index = ((m-1)*m + m-1)*n + j;
        mpz_add(f1_q1[index], f1_q1[index], temp);
      }
    }

    for (int i=(m-1)/2; i<(m-1); i++) {
      for (int j=0; j<n; j++) {
        // -2 \cdot A_{i,j} \cdot B_{j, m-1}
        index = (i*m+m-1)*n+j;
        mpz_mul_ui(temp, gamma[1], 2);
        mpz_add(f1_q1[index], f1_q1[index], temp);

        // A_{i,j} \cdot B_{j,i}
        index = (i*m+i)*n+j;
        mpz_neg(temp, gamma[1]);
        mpz_add(f1_q1[index], f1_q1[index], temp);

        // A_{m-1,j} \cdot B_{j, m-1}
        index = ((m-1)*m + m-1)*n + j;
        mpz_add(f1_q1[index], f1_q1[index], temp);
      }
    }

    v->create_ckt_test_queries(hadamard_code_size, f1_q1, f1_q3, f1_q2, f1_consistency, f1_con_filled, f1_con_coins, prime);

    snprintf(scratch_str, BUFLEN-1, "q5_qquery_r_%d", rho);
    dump_vector(hadamard_code_size, f1_q3, scratch_str);
    send_file(scratch_str);

    f1_con_filled += 1;

    // LAYOUT: B_1, ..., B_80, D1, D2, IDX
    for (int i=0; i<num_vars2; i++)
      mpz_set_ui(f3_q2[i], 0);

    // parsing D1 - <distance formula>
    mpz_add(f3_q2[num_vars2-3], f3_q2[num_vars2-3], gamma[0]);

    // parsing D2 -<distance formula>
    mpz_add(f3_q2[num_vars2-2], f3_q2[num_vars2-2], gamma[1]);

    // parsing \sum 2^i B_i = IDX (D1-D2) + (1-IDX) (D2-D1)
    // parsing \sum 2^i B_i - 2 IDX D1 + 2 IDX D2 - D2 + D1
    for (int i=0; i<num_vars2-3; i++) {
      mpz_ui_pow_ui(temp, 2, i);
      mpz_mul(temp, temp, gamma[2]);
      mpz_add(f3_q2[i], f3_q2[i], temp);
    }

    mpz_add(f3_q2[num_vars2-3], f3_q2[num_vars2-3], gamma[2]);

    mpz_neg(temp, gamma[2]);
    mpz_add(f3_q2[num_vars2-2], f3_q2[num_vars2-2], temp);

    // parsing IDX - IDX^2
    mpz_add(f3_q2[num_vars2-1], f3_q2[num_vars2-1], gamma[3]);

    // parsing idx - IDX
    mpz_neg(temp, gamma[4]);
    mpz_add(f3_q2[num_vars2-1], f3_q2[num_vars2-1], temp);

    // parsing B_i - B_i^2
    for (int i=0; i<num_vars2-3; i++) {
      mpz_add(f3_q2[i], f3_q2[i], gamma[5+i]);
    }

    v->create_ckt_test_queries(num_vars2, f3_q2, f3_q3, f3_q1, f3_consistency, f3_con_filled, f3_con_coins, prime);

    snprintf(scratch_str, BUFLEN-1, "q10_qquery_r_%d", rho);
    dump_vector(num_vars2, f3_q3, scratch_str);
    send_file(scratch_str);

    f3_con_filled += 1;

    // gamma_4
    // LAYOUT: B_1, ..., B_80, D1, D2, IDX
    for (int i=0; i<num_vars2*num_vars2; i++)
      mpz_set_ui(f4_q1[i], 0);

    // parsing \sum 2^i B_i = IDX (D1-D2) + (1-IDX) (D2-D1)
    // parsing \sum 2^i B_i - 2 IDX D1 + 2 IDX D2 - D2 + D1

    //   -2 IDX D1
    int index1 = num_vars2-1;
    index2 = num_vars2-3;
    index = index1 * num_vars2 + index2;
    mpz_mul_si(temp, gamma[2], -2);
    mpz_add(f4_q1[index], f4_q1[index], temp);


    //   2 IDX D2
    index1 = num_vars2-1;
    index2 = num_vars2-2;
    index = index1 * num_vars2 + index2;
    mpz_mul_ui(temp, gamma[2], 2);
    mpz_add(f4_q1[index], f4_q1[index], temp);


    // parsing IDX - IDX^2
    index1 = num_vars2-1;
    index2 = num_vars2-1;
    index = index1 * num_vars2 + index2;
    mpz_neg(temp, gamma[3]);
    mpz_add(f4_q1[index], f4_q1[index], temp);

    // parsing B_i - B_i^2
    for (int i=0; i<num_vars2-3; i++) {
      index1 = i;
      index2 = i;
      index = index1 * num_vars2 + index2;
      mpz_neg(temp, gamma[5+i]);
      mpz_add(f4_q1[index], f4_q1[index], temp);
    }

    v->create_ckt_test_queries(num_vars2*num_vars2, f4_q1, f4_q3, f4_q2, f4_consistency, f4_con_filled, f4_con_coins, prime);

    snprintf(scratch_str, BUFLEN-1, "q11_qquery_r_%d", rho);
    dump_vector(num_vars2*num_vars2, f4_q3, scratch_str);
    send_file(scratch_str);

    f4_con_filled += 1;

    m_plainq.end();

    m_runtests.begin_with_history();
    // finally compute c
    for (int i=0; i<batch_size; i++) {
      snprintf(scratch_str, BUFLEN-1, "output_b_%d", i);
      load_vector(1, C, scratch_str);

      int c_index = i * num_repetitions + rho;

      mpz_mul(temp, gamma[4], C[0]);
      mpz_set(c_values[c_index], temp);

      //mpz_mul(temp, gamma[1], C[1]);
      //mpz_add(c_values[c_index], c_values[c_index], temp);

    }
    m_runtests.end();
  }

  dump_vector(hadamard_code_size, f1_consistency, (char *)"f1_consistency_query");
  send_file((char *)"f1_consistency_query");

  dump_vector(num_vars2, f3_consistency, (char *)"f2_consistency_query");
  send_file((char *)"f2_consistency_query");

  dump_vector(hadamard_code_size2, f4_consistency, (char *)"f3_consistency_query");
  send_file((char *)"f3_consistency_query");
}

void KNNVerifier::populate_answers(mpz_t *f_answers, int rho, int num_repetitions, int beta) {
  uint32_t i = rho * num_lin_pcp_queries;

  mpz_set_ui(f_con_coins[i+Q1], 0);
  mpz_set_ui(f_con_coins[i+Q2], 0);

  mpz_set(f_con_coins[i+Q3], f1_con_coins[i+0]);
  mpz_set(f_con_coins[i+Q4], f1_con_coins[i+1]);
  mpz_set(f_con_coins[i+Q5], f1_con_coins[i+2]);

  mpz_set(f_con_coins[i+Q6], f3_con_coins[i+0]);
  mpz_set(f_con_coins[i+Q7], f3_con_coins[i+1]);
  mpz_set(f_con_coins[i+Q10], f3_con_coins[i+2]);

  mpz_set(f_con_coins[i+Q8], f4_con_coins[i+0]);
  mpz_set(f_con_coins[i+Q9], f4_con_coins[i+1]);
  mpz_set(f_con_coins[i+Q11], f4_con_coins[i+2]);
}

void KNNVerifier::run_correction_and_circuit_tests(uint32_t beta) {
  for (int rho=0; rho<num_repetitions; rho++) {
    // Quad Correction test and Circuit test
    mpz_set_ui(temp, 1);
    mpz_t ans;
    mpz_init_set_ui(ans, 0);
    snprintf(scratch_str, BUFLEN-1, "corr_answer_b_%d_r_%d", beta, rho);
    load_scalar(ans, scratch_str);
    bool cor1 = v->corr_test(ans /*f2_answers[rho*NUM_LIN_PCP_QUERIES + Q1]*/, temp,
                             f_answers[rho*num_lin_pcp_queries + Q3],
                             f_answers[rho*num_lin_pcp_queries + Q4], prime);

    if (false == cor1)
      cout<<"LOG: F1, F2 failed the correction test"<<endl;
    else
      cout<<"LOG: F1, F2 passed correction test"<<endl;

    bool cor2 = v->corr_test(f_answers[rho*num_lin_pcp_queries+Q6], f_answers[rho*num_lin_pcp_queries+Q7], f_answers[rho*num_lin_pcp_queries + Q8],
                             f_answers[rho*num_lin_pcp_queries + Q9], prime);

    if (false == cor1 || false == cor2)
      cout<<"LOG: F1, F2 failed the correction test"<<endl;
    else
      cout<<"LOG: F1, F2 passed correction test"<<endl;

    mpz_set(ckt_answers[0], f_answers[rho*num_lin_pcp_queries + Q5]);
    mpz_set(ckt_answers[1], f_answers[rho*num_lin_pcp_queries + Q4]);

    mpz_set(ckt_answers[2], f_answers[rho*num_lin_pcp_queries + Q10]);
    mpz_set(ckt_answers[3], f_answers[rho*num_lin_pcp_queries + Q6]);
    mpz_set(ckt_answers[4], f_answers[rho*num_lin_pcp_queries + Q11]);
    mpz_set(ckt_answers[5], f_answers[rho*num_lin_pcp_queries + Q9]);

    bool ckt2 = v->ckt_test(6, ckt_answers,
                            c_values[beta * num_repetitions + rho], prime);

    if (false == ckt2)
      cout <<"LOG: F1 failed the circuit test"<<endl;
    else
      cout <<"LOG: F1 passed the circuit test"<<endl;
  }
}
