#ifndef CODE_PEPPER_APPS_IMAGE_FILTER_P_H_
#define CODE_PEPPER_APPS_IMAGE_FILTER_P_H_

#include <libv/prover.h>
#include <common/mpnvector.h>

#ifndef INTERFACE_MPI
bool MICROBENCHMARKS = false;
#endif

class ImageFilterProver : public Prover {
  private:
    MPZVector A, B, C;
    MPZVector F2;       // F0 == A, F1 == B
    MPZVector commitments[3];
    MPZVector queries[3];

    int k;

  public:
    ImageFilterProver();
    ImageFilterProver(int ph, int b_size, int num_r, int input_size);
    void init_state();
    void prover_computation_commitment();
    void compute_commitment();
    void compute();
};
#endif  // CODE_PEPPER_APPS_IMAGE_FILTER_P_H_
