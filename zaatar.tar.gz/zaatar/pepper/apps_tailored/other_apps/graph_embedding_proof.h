#ifndef CODE_PEPPER_APPS_GRAPH_EMBEDDING_PROOF_H_
#define CODE_PEPPER_APPS_GRAPH_EMBEDDING_PROOF_H_
#include <common/constraint_gen.h>

class GraphEmbeddingProof{
public:
  GraphEmbeddingProof();
  void graph_embedding_proof(ConstraintGenerator& cg, int m);
private:
  mpz_t one, neg1;
  mpq_t maxValue, zeroq;
};

#endif  //CODE_PEPPER_APPS_GRAPH_EMBEDDING_PROOF_H_
