#ifndef CODE_PEPPER_APPS_%TEMPLATE%_PROOF_H_
#define CODE_PEPPER_APPS_%TEMPLATE%_PROOF_H_
#include <common/constraint_gen.h>

class %Template%Proof{
public:
  %Template%Proof();
  void %template%_proof(ConstraintGenerator& cg, int m);
private:
};

#endif  //CODE_PEPPER_APPS_%TEMPLATE%_PROOF_H_
