#!/usr/bin/perl
use strict;
use warnings;
use autodie;

if (not -e -d "apps") {
  die "Please run appgen from code/pepper" 
}

print "Venezia Application Generator \n";
print "Please enter in a name for your application: ";
chomp(my $app_name = <STDIN>);
my $APP_NAME = "\U$app_name";
my @app_name_words = split(/_/, $app_name);
for my $word (@app_name_words)
{
 $word = "\u$word"; 
}
my $AppName = join("", @app_name_words);

#print "$app_name $APP_NAME $AppName \n";

for my $filename qw(.cpp _p.cpp _p.h _v.cpp _v.h _proof.cpp _proof.h)
{
  my $template_file = "appgen/template$filename";
  my $app_file = "apps/$app_name$filename";
  if (-e $app_file)
  {
    print "Skipping $app_file", "\n";
  } else {
    open my $input, "<", $template_file; 
    open my $output, ">", $app_file;
    while (<$input>)
    {
      #Don't chomp the line, we want to preserve the new lines.
      s/%template%/$app_name/g;
      s/%Template%/$AppName/g;
      s/%TEMPLATE%/$APP_NAME/g;
      print $output $_;
    }
    close $input;
    close $output; 
    print "Created $app_file", "\n";
  }
}

#create the run script
{
  my $template_file = "appgen/template.sh";
  my $app_file = "run/$app_name.sh";
  if (-e $app_file)
  {
    print "Skipping $app_file", "\n";
  } else {
    open my $input, "<", $template_file; 
    open my $output, ">", $app_file;
    while (<$input>)
    {
      #Don't chomp the line, we want to preserve the new lines.
      s/%template%/$app_name/g;
      s/%Template%/$AppName/g;
      s/%TEMPLATE%/$APP_NAME/g;
      print $output $_;
    }
    close $input;
    close $output; 
    print "Created $app_file", "\n";
  }
}
