#include<apps/%template%_proof.h>
#include<common/utility.h>
#include<gmp.h>

%Template%Proof::%Template%Proof()
{
  //TODO: implement me
}

void %Template%Proof::%template%_proof(ConstraintGenerator& cg, int m){
  //TODO: Implement me
}
