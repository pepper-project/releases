#ifndef CODE_PEPPER_APPS_%TEMPLATE%_P_H_
#define CODE_PEPPER_APPS_%TEMPLATE%_P_H_
#include <libv/prover.h>
#include <apps/%template%_proof.h>

#define PROVER_NAME "/%template%_p"
#define NUM_LIN_PCP_QUERIES 6
#define Q1 0 
#define Q2 1
#define Q3 2
#define Q4 3
#define Q5 4
#define Q6 5

class %Template%Prover : public Prover {
  
  private:
    mpz_t *output, *f1_commitment, *f2_commitment, *f1_q1, *f1_q2, *f2_q1, *f2_q2, *F1, *F2;
    mpq_t *qF1;
    int num_variables, num_variables2, input_file_size, output_file_size;

    %Template%Proof proof;    

  public:
    %Template%Prover(int, int, int, int);
    void init_state();
    void find_cur_qlengths();
    void prover_computation_commitment();
    void computation_%template%();
    void deduce_answers();
};
#endif  
