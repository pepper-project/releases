#include <apps/sample_p.h>

SampleProver::SampleProver(int ph,
int b_size, int num_r, int in_size, int out_size, int num_v, int num_c): ComputationProver(ph, b_size, num_r, in_size, out_size,
  num_v, num_c, (char *) PROVER_NAME)
{
}

void SampleProver::computation() {
	// TODO: add code to read input and write to output array
  mpz_set_ui(temp, 10);
  mpz_mul(temp, temp, input[0]);
  mpz_mul(output[0], temp, input[4]);
  
  mpz_mul(temp, input[1], input[5]);
  mpz_add(output[0], output[0], temp);
  mpz_neg(output[0], output[0]);
}

void SampleProver::compute_assignment_vectors() {
	// TODO: add code to fill in vectors F1
  for (int i=0; i<input_size; i++)
  {
    mpz_set(F1[i], input[i]);
  }

  // code to fill in F2 using entries in F1
  int index;
  for (int i=0; i<num_vars; i++) {
    for (int j=0; j<=i; j++) {
      index = i*num_vars+j;
      mpz_mul(F2[index], F1[i], F1[j]);
      mpz_mod(F2[index], F2[index], prime);
    }
  }
  
  for (int i=0; i<num_vars; i++) {
    for (int j=i+1; j<num_vars; j++) {
      index = i*num_vars+j;
      mpz_set(F2[index], F2[j*num_vars+i]);
    }
  }
}
