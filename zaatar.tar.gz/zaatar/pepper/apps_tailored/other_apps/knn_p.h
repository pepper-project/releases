#ifndef CODE_PEPPER_APPS_MATRIX_CUBICP_P_H_ 
#define CODE_PEPPER_APPS_MATRIX_CUBICP_P_H_

#include <libv/prover.h>

#define PROVER_NAME "/lt"
#define NUM_LIN_PCP_QUERIES 11 
#define Q1 0 
#define Q2 1
#define Q3 2
#define Q4 3
#define Q5 4
#define Q6 5
#define Q7 6
#define Q8 7
#define Q9 8
#define Q10 9
#define Q11 10


class KNNProver : public Prover {
  
  private:
    mpz_t *Fin, *A, *C, *F1, *F3, *F4, *output, *f1_commitment, *f1_q1, *f1_q2, *f1_q3, *f2_q1, *f2_q2;
    mpz_t *f3_commitment, *f3_consistency;
    mpz_t *f4_commitment, *f4_consistency;
    mpz_t *gamma;
    mpz_t temp;
    mpz_t *f3_q, *f4_q, *f3_q2, *f4_q2, *f3_q3, *f4_q3;
    int hadamard_code_size, hadamard_code_size2;
    int num_vars2;
    int m, n;

  public:
    KNNProver(int, int, int, int);
    void init_state();
    void find_cur_qlengths();
    void prover_computation_commitment();
    void computation_matrixmult();
    void deduce_queries();
    void computation_assignment();
};
#endif  // CODE_PEPPER_APPS_MATRIX_CUBICP_P_H_
