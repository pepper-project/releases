#include "image_filter_p.h"

ImageFilterProver::
ImageFilterProver(): Prover()
{
  init_state();
}

ImageFilterProver::
ImageFilterProver(int ph, int b_size, int num_r, int input_size):
    Prover(ph, b_size, num_r, input_size)
{
  init_state();
}

void ImageFilterProver::
init_state()
{
  num_bits_in_prime = 192;
  num_bits_in_input = 32;
  crypto_in_use = CRYPTO_ELGAMAL;
  png_in_use = PNG_CHACHA;

  //TODO: Pass in somehow?
  // k is hardwired for now, since it doesn't fit into the current API.
  k = 7;

  Prover::init_state();

  int sizes[] = { m*m, k*k, m*m*k*k };

  A.resize(sizes[0]);
  B.resize(sizes[1]);
  C.resize(sizes[2]);
  F2.resize(sizes[2]);

  for (unsigned i = 0; i < NUM_OF(sizes); i++)
  {
    commitments[i].resize(expansion_factor * sizes[i]);
    queries[i].resize(sizes[i]);
  }
}

void ImageFilterProver::
compute()
{
  int a_index, b_index, c_index, a_i, a_j, shift;
  mpz_t temp;
  mpz_init(temp);
  shift = (k - 1) / 2;

  for (int i = 0; i < m; i++)
  {
    for (int j = 0; j < m; j++)
    {
      c_index = i * m + j;
      mpz_set_ui(C[c_index], 0);

      for (int x = 0; x < k; x++)
      {
        for (int y = 0; y < k; y++)
        {
          a_i = i + x - shift;
          a_j = j + y - shift;

          a_index = m * a_i + a_j;
          b_index = x * k + y;

          // Edge Condition.
          if ((a_i >= 0) && (a_i < m) && (a_j >= 0) && (a_j < m))
          {
            mpz_mul(temp, A[a_index], B[b_index]);
            mpz_add(C[c_index], C[c_index], temp);
          }

          // Also compute F3 at the same time.
          mpz_mul(temp, A[c_index], B[b_index]);
          mpz_set(F2[c_index * B.size() + b_index], temp);
        }
      }
    }
  }
}

void ImageFilterProver::
prover_computation_commitment()
{
  // Placeholder awaiting refactoring.
  compute_commitment();
}

void ImageFilterProver::
compute_commitment()
{
  char buf[BUFLEN];

  //cout << "\nPROVER COMPUTATION COMMITMENT" << endl;
  load_array(NUM_OF(commitments), commitments, "commitment_query", FOLDER_WWW_DOWNLOAD);

  // The three functions. Here for ease of use.
  MPZVector* F[] = { &A, &B, &F2 };
  MPZVector outputs[NUM_OF(commitments)];
  MPZVector::resize_array(outputs, expansion_factor, NUM_OF(outputs));

  for (int batch = 0; batch < batch_size; batch++)
  {
    sprintf(buf, "input0_b_%d", batch); 
    A.load_file(buf, FOLDER_WWW_DOWNLOAD);

    sprintf(buf, "input1_b_%d", batch); 
    B.load_file(buf, FOLDER_WWW_DOWNLOAD);

    compute();

    // start saving the state
    sprintf(buf, "output0_b_%d", batch); 
    C.dump_file(buf, FOLDER_WWW_DOWNLOAD);

    for (unsigned i = 0; i < NUM_OF(F); i++)
    {
      sprintf(buf, "f%d_assignment_vector_b_%d", i, batch);
      F[i]->dump_file(buf, FOLDER_WWW_DOWNLOAD);
    }

    for (unsigned i = 0; i < NUM_OF(commitments); i++)
    {
      if (crypto_in_use == CRYPTO_PAILLIER)
      { 
        v->dot_product_enc(commitments[i].size(), commitments[i].raw_vec(),
                           F[i]->raw_vec(), outputs[i][0]);
      }
      else if (crypto_in_use == CRYPTO_ELGAMAL)
      {
        v->dot_product_enc(commitments[i].size(), commitments[i].raw_vec(),
                           F[i]->raw_vec(), outputs[i][0], outputs[i][1]);
      }
    }

    sprintf(buf, "commitment_answer_b_%d", batch); 
    dump_array(NUM_OF(outputs), outputs, buf, FOLDER_WWW_DOWNLOAD);
  }
}

#ifndef INTERFACE_MPI

int
main(int argc, char **argv)
{
  int phase;
  int batch_size;
  int num_repetitions;
  int input_size;

  if (argc > 2)
  {
    parse_args(argc, argv, &phase, &batch_size, &num_repetitions, &input_size, NULL);
    ImageFilterProver prover(phase, batch_size, num_repetitions, input_size);
    prover.handle_terminal_request();
  }
  else
  {
    ImageFilterProver prover;
    prover.handle_http_requests();
  }
  return 0;
}

#endif
