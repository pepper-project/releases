#ifndef CODE_PEPPER_APPS_BISECT_V_H_
#define CODE_PEPPER_APPS_BISECT_V_H_

#include <libv/verifier.h>

#define NAME_PROVER "bisect"
#define NUM_LIN_PCP_QUERIES_F1 3
#define NUM_LIN_PCP_QUERIES_F2 3 

#define Q1 0 
#define Q2 1
#define Q3 2
#define Q4 3
#define Q5 4
#define Q6 5

#ifdef INTERFACE_MPI
#include <apps/bisect_p.h>
#endif

class BisectVerifier : public Verifier {
  private:
    mpz_t *X_in, *Y_in, *X_out, *Y_out, *coefficients;
    int L; //the number of iterations of bisection method
    int num_coefficients;

    mpz_t *f1_q1, *f1_q2, *f1_q3, *f1_commitment, *f1_consistency;
    mpz_t *f2_q1, *f2_q2, *f2_q3, *f2_commitment, *f2_consistency;
    mpz_t *f1_con_coins, *f2_con_coins;
    mpz_t *f1_answers, *f2_answers, *ckt_answers;
    mpz_t *alpha;
    mpz_t neg, neg_i;
    mpz_t temp;
    mpz_t a1, a2, f1_s, f2_s;
    mpz_t *temp_arr, *temp_arr2;
    mpz_t c_init_val;
    int m;

  public:
    BisectVerifier(int batch, int reps, int ip_size, int optimize_answers, char *prover_url);
    void init_state();
    void create_input();
    void create_plain_queries();
    void run_correction_and_circuit_tests(uint32_t beta);
    void populate_answers(mpz_t *f_answers, int rho, int num_repetitions, int beta);
};
#endif  // CODE_PEPPER_APPS_BISECT_V_H_
