#include <crypto/crypto.h>
#include <common/measurement.h>
#include <common/utility.h>

#define BASELINE_PLAIN_SIZE 32

int crypto_in_use = CRYPTO_ELGAMAL;
int png_in_use = PNG_CHACHA;
gmp_randstate_t state;

bool MICROBENCHMARKS = 1;
int NUM_RUNS = 100;


// ===== Timing functions =====

double get_spent_us(struct rusage *ru_start, struct rusage *ru_end) {
  double ret;

  // Code time
  struct timeval start_time = ru_start->ru_utime;
  struct timeval end_time = ru_end->ru_utime;

  double ts = start_time.tv_sec*1000000 + (start_time.tv_usec);
  double te = end_time.tv_sec*1000000  + (end_time.tv_usec);
  ret = (te-ts);

  // System time
  start_time = ru_start->ru_stime;
  end_time = ru_end->ru_stime;

  ts = start_time.tv_sec*1000000 + (start_time.tv_usec);
  te = end_time.tv_sec*1000000  + (end_time.tv_usec);
  ret += (te-ts);

  return ret;
}

void print_stats(const char *operation, vector<double> s) {
  double min = 0, max = 0;
  double avg = 0;

  sort(s.begin(), s.begin()+s.size());

  int start_index = 0;
  int end_index = s.size();
  int count = 0;

  for (long i=start_index; i<end_index; i++) {
    if (s[i] < min || min == 0)
      min = s[i];

    if (s[i] > max)
      max = s[i];

    avg = avg + s[i];
    count = count + 1;
  }

  avg = avg/count;

  double sd = 0;
  for (long i=start_index; i<end_index; i++) {
    sd = sd + (s[i] - avg) * (s[i] - avg);
  }

  sd = sqrt(sd/count);
  cout<<"* "<<operation<<"_min "<<min<<endl;
  cout<<"* "<<operation<<"_max "<<max<<endl;
  cout<<"* "<<operation<<"_avg "<<avg<<endl;
  cout<<"* "<<operation<<"_sd "<<sd<<endl<<endl;
}

void print_rslt_stats(const char *operation, vector<double> s) {
  double min = 0, max = 0;
  double avg = 0;

  sort(s.begin(), s.begin()+s.size());

  int start_index = 0;
  int end_index = s.size();
  int count = 0;

  for (long i=start_index; i<end_index; i++) {
    if (s[i] < min || min == 0)
      min = s[i];

    if (s[i] > max)
      max = s[i];

    avg = avg + s[i];
    count = count + 1;
  }

  avg = avg/count;

  double sd = 0;
  for (long i=start_index; i<end_index; i++) {
    sd = sd + (s[i] - avg) * (s[i] - avg);
  }

  sd = sqrt(sd/count);
  cout<<"* "<<operation<<"_min "<<min<<endl;
  cout<<"* "<<operation<<"_max "<<max<<endl;
  cout<<"* "<<operation<<" "<<avg<<endl;
  cout<<"* "<<operation<<"_sd "<<sd<<endl<<endl;
}

// ===== Microbenchmark Functions =====
void measure_p3(int num_runs, int m, int batch_size) {
  mpz_t *F1, *F2, *F3, *coefficients, temp, *variables, output, temp2;
  mpz_init(temp);
  mpz_init(temp2);
  mpz_init(output);

  struct rusage ru1, ru2;
  char buf[BUFLEN];
  vector<double> samples(num_runs, 0);
  int num_coefficients = (m*m*m + 3*m*m + 2*m)/6 + (m * m + 3*m)/2 + 1;

  alloc_init_vec(&F1, m);
  alloc_init_vec(&variables, batch_size * m);
  alloc_init_vec(&F2, m*m);
  alloc_init_vec(&F3, m*m*m);
  alloc_init_vec(&coefficients, num_coefficients);

  for (int w=0; w<num_runs; w++) {
    for (int i=0; i<num_coefficients; i++) {
      mpz_urandomb(coefficients[i], state, BASELINE_PLAIN_SIZE);
    }

    double total_time = 0;
    int variables_index = 0;
    for (int o=0; o<batch_size; o++) {
      // not couting the input creation
      for (int i=0; i<m; i++)
        mpz_urandomb(variables[variables_index+i], state, BASELINE_PLAIN_SIZE);

      getrusage(RUSAGE_SELF, &ru1);
      int index = 0, index2 = 0, index3 = 0;
      int count = 0;
      for (int i=0; i<m; i++) {
        mpz_set(F1[i], variables[i]);
      }

      for (int i=0; i<m; i++) {
        for (int j=0; j<=i; j++) {
          index = m*i+j;
          mpz_mul(F2[index], variables[variables_index+i], variables[variables_index+j]);
          count++;
        }
      }

      for (int i=0; i<m; i++) {
        for (int j=i+1; j<m; j++) {
          index = m*i + j;
          index2 = m*j+i;
          mpz_set(F2[index], F2[index2]);
        }
      }

      index2 = 0;
      for (int i=0; i<m; i++) {
        for (int j=0; j<=i; j++) {
          index = m*i + j;
          for (int k=0; k<=j; k++) {
            index2 = (i*m+j)*m+k;
            mpz_mul(F3[index2], F2[index], variables[variables_index+k]);
          }
        }
      }

      mpz_set_ui(output, 0);
      index3 = 0;
      for (int i=0; i<m; i++) {
        for (int j=0; j<=i; j++) {
          index = m*i + j;
          for (int k=0; k<=j; k++) {
            index2 = (i*m+j)*m+k;
            mpz_mul(temp2, coefficients[index3], F3[index2]);
            mpz_add(output, output, temp2);
            index3++;
          }
        }
      }

      // now compute the output;
      for (int i=0; i<m; i++) {
        for (int j=0; j<=i; j++) {
          int index = m*i+j;
          mpz_mul(temp, coefficients[index3], F2[index]);
          mpz_add(output, output, temp);
          index3++;
        }
      }

      // now the linear term
      for (int i=0; i<m; i++) {
        mpz_mul(temp, coefficients[index3+i], F1[i]);
        mpz_add(output, output, temp);
        count = count +2;
      }

      index3 += m;

      // now the constant term
      mpz_add(output, output, coefficients[index3]);
      variables_index += m;

      getrusage(RUSAGE_SELF, &ru2);

      total_time += get_spent_us(&ru1, &ru2);

      // move to the next instance
    }
    samples[w] = (double)(total_time);
  }
  cout<<"poly d3"<<endl;
  snprintf(buf, BUFLEN-1, "computation_%d", m);
  print_rslt_stats(buf, samples);
}


void measure_mm(int num_runs, int m) {
  mpz_t A[m][m], B[m][m], C[m][m], *F1, temp;
  mpz_init(temp);

  struct rusage ru1, ru2;
  int inner_loop = 50;
  char buf[BUFLEN];

  vector<double> samples(num_runs, 0);

  for (int i=0; i<m; i++) {
    for (int j=0; j<m; j++) {
      mpz_init(A[i][j]);
      mpz_urandomb(A[i][j], state, 32);
      mpz_init(B[i][j]);
      mpz_urandomb(B[i][j], state, 32);
      mpz_init(C[i][j]);
    }
  }

  for (int w=0; w<num_runs; w++) {
    getrusage(RUSAGE_SELF, &ru1);
    for (int o=0; o<inner_loop; o++) {
      int count = 0;
      for (int i=0; i<m; i++) {
        for (int j=0; j<m; j++) {
          mpz_set_ui(C[i][j], 0);
          for (int k=0; k<m; k++) {
            mpz_mul(temp, A[i][k], B[k][j]);
            mpz_add(C[i][j], C[i][j], temp);
            count++;
          }
        }
      }
    }
    getrusage(RUSAGE_SELF, &ru2);
    samples[w] = (double)(get_spent_us(&ru1, &ru2));
  }
  snprintf(buf, BUFLEN-1, "computation", m);
  print_rslt_stats(buf, samples);
}

void measure_load_store_vector(int num_runs, int n) {
  struct rusage ru1, ru2;
  int inner_loop = 5000;
  mpz_t *q;
  alloc_init_vec(&q, n);
  char buf[BUFLEN];

  vector<double> samples(num_runs, 0);

  for (int j=0; j<num_runs; j++) {
    getrusage(RUSAGE_SELF, &ru1);
    for (int i=0; i<inner_loop; i++)
      load_vector(n, q, "f3_consistency_query", "/mnt");
    getrusage(RUSAGE_SELF, &ru2);
    samples[j] = (double)(get_spent_us(&ru1, &ru2)/inner_loop);
  }
  snprintf(buf, BUFLEN-1, "load_%d", n);
  print_stats(buf, samples);

  for (int j=0; j<num_runs; j++) {
    getrusage(RUSAGE_SELF, &ru1);
    for (int i=0; i<inner_loop; i++)
      dump_vector(n, q, "temp_query", "/mnt");
    getrusage(RUSAGE_SELF, &ru2);
    samples[j] = (double)(get_spent_us(&ru1, &ru2)/inner_loop);
  }
  snprintf(buf, BUFLEN-1, "store_%d", n);
  print_stats(buf, samples);
}

void measure_encryption(Crypto *v, double *enc, double *dec, double *hadd,
                        double *smul, mpz_t m, mpz_t n, mpz_t scalar) {
  struct rusage ru1, ru2;
  int inner_loop = 1000;
  int long_inner_loop = 100000;

  // variables used in the measurements
  mpz_t enc_m1, enc_m2, enc_n1, enc_n2, result1, result2;
  mpz_init(enc_m1);
  mpz_init(enc_m2);
  mpz_init(enc_n1);
  mpz_init(enc_n2);
  mpz_init(result1);
  mpz_init(result2);

  // variables used to check correct functioning of crypto
  mpz_t gen, mod,mn, sm;
  mpz_init(gen);
  mpz_init(mod);
  mpz_init(mn);
  mpz_init(sm);

  v->elgamal_get_generator(&gen);
  v->elgamal_get_public_modulus(&mod);


  // encryption
  getrusage(RUSAGE_SELF, &ru1);
  for (int j = 0; j < inner_loop; j++)
    v->elgamal_enc(enc_m1, enc_m2, m);
  getrusage(RUSAGE_SELF, &ru2);
  *enc = (double)(get_spent_us(&ru1, &ru2)/inner_loop);

  // decryption
  getrusage(RUSAGE_SELF, &ru1);
  for (int j = 0; j < inner_loop; j++)
    v->elgamal_dec(result1, enc_m1, enc_m2);
  getrusage(RUSAGE_SELF, &ru2);
  *dec = (double)(get_spent_us(&ru1, &ru2)/inner_loop);

  // check
  mpz_powm(result2, gen, m, mod);
  if (mpz_cmp(result1, result2) != 0) {
    cout << "ERROR: ELGAMAL ENC/DEC ERROR" << endl;
    exit(1);
  }

  // homomorphic addition
  v->elgamal_enc(enc_n1, enc_n2, n);

  getrusage(RUSAGE_SELF, &ru1);
  for (int j = 0; j < long_inner_loop; j++)
    v->elgamal_hadd(result1, result2, enc_m1, enc_m2, enc_n1, enc_n2);
  getrusage(RUSAGE_SELF, &ru2);
  *hadd = (double)(get_spent_us(&ru1, &ru2)/(long_inner_loop));

  // check
  v->elgamal_dec(result1, result1, result2);
  mpz_add(mn, m, n);
  mpz_powm(result2, gen, mn, mod);
  if (mpz_cmp(result1, result2) != 0) {
    cout << "ERROR: ELGAMAL HADD ERROR" << endl;
    exit(1);
  }


  // scalar multiplication
  getrusage(RUSAGE_SELF, &ru1);
  for (int j = 0; j < inner_loop; j++)
    v->elgamal_smul(result1, result2, enc_m1, enc_m2, scalar);
  getrusage(RUSAGE_SELF, &ru2);
  *smul = (double)(get_spent_us(&ru1, &ru2)/(inner_loop));

  // check
  v->elgamal_dec(result1, result1, result2);
  mpz_mul(sm, m, scalar);
  mpz_powm(result2, gen, sm, mod);
  if (mpz_cmp(result1, result2) != 0) {
    cout << "ERROR: ELGAMAL SMUL ERROR" << endl;
    exit(1);
  }
  return;
}

void measure_mult(double *mul, mpz_t a, mpz_t b) {
  int inner_loop = 1000000;

  struct rusage ru1, ru2;
  mpz_t c;
  mpz_init(c);

  getrusage(RUSAGE_SELF, &ru1);
  for (long j = 0; j < inner_loop; j++)
    mpz_mul(c, a, b);
  getrusage(RUSAGE_SELF, &ru2);

  *mul = (double)(get_spent_us(&ru1, &ru2)/(inner_loop));

  return;
}

void measure_mod_mult(double *mul, mpz_t a, mpz_t b, Crypto *v) {
  int inner_loop = 1000000;

  struct rusage ru1, ru2;
  mpz_t c, mod;
  mpz_init(c);
  mpz_init(mod);

  v->elgamal_get_public_modulus(&mod);

  getrusage(RUSAGE_SELF, &ru1);
  for (long j = 0; j < inner_loop; j++) {
    mpz_mul(c, a, b);
    mpz_mod(c, c, mod);
  }
  getrusage(RUSAGE_SELF, &ru2);

  *mul = (double)(get_spent_us(&ru1, &ru2)/(inner_loop));

  return;
}

void measure_exp(double *exp, mpz_t a, mpz_t b, Crypto *v) {
  int inner_loop = 500;

  struct rusage ru1, ru2;
  mpz_t c, mod;
  mpz_init(c);
  mpz_init(mod);

  v->elgamal_get_public_modulus(&mod);

  getrusage(RUSAGE_SELF, &ru1);
  for (long j = 0; j < inner_loop; j++)
    mpz_powm(c, a, b, mod);
  getrusage(RUSAGE_SELF, &ru2);

  *exp = (double)(get_spent_us(&ru1, &ru2)/(inner_loop));

  return;
}


void measure_rand(double *rand, int size, Crypto *v) {
  int inner_loop = 10000000;

  struct rusage ru1, ru2;
  mpz_t r;
  mpz_init(r);

  getrusage(RUSAGE_SELF, &ru1);
  for (long j = 0; j < inner_loop; j++)
    v->get_randomb(r, size);
  getrusage(RUSAGE_SELF, &ru2);

  *rand = (double)(get_spent_us(&ru1, &ru2)/(inner_loop));

  return;
}

// ===== Experimental Functions =====

// move bits bits from m to n
// ensure last limb in m is full
void split(mpz_t source, mpz_t target, int bits) {
  long long_inner_loop = 10000000;
  int limbs = ceil(((double)bits)/mp_bits_per_limb);
  int diff=limbs*mp_bits_per_limb - bits;

  // alloc number of limbs
  _mpz_realloc(target, limbs);

  for (int i = limbs-1; i>=0; i--) {
    target->_mp_d[i] = source->_mp_d[source->_mp_size-1];
    source->_mp_size--;
  }

  // remove me
  source->_mp_size += limbs;

  if (diff != 0)
    mpn_rshift(&target->_mp_d[limbs-1], &target->_mp_d[limbs-1], 1, diff);

  target->_mp_size = limbs;
}


// ===== Main Function =====

int main() {
  Crypto *v = new Crypto(CRYPTO_TYPE_PRIVATE, crypto_in_use, png_in_use, true, 704);
  Crypto *v2 = new Crypto(CRYPTO_TYPE_PRIVATE, crypto_in_use, png_in_use, true, 512);
  Crypto *v3 = new Crypto(CRYPTO_TYPE_PRIVATE, crypto_in_use, png_in_use, true, 1280);
  Crypto *v4 = new Crypto(CRYPTO_TYPE_PRIVATE, crypto_in_use, png_in_use, true, 1024);
  Crypto *v6 = new Crypto(CRYPTO_TYPE_PRIVATE, crypto_in_use, png_in_use, true, 704);
  Crypto *v7 = new Crypto(CRYPTO_TYPE_PRIVATE, crypto_in_use, png_in_use, true, 704);

  int num_runs = NUM_RUNS;


  // Not getting microbenchmarks? Bools are probably set to 0
  // shortcuts to skip parts for faster testing
  bool do_enc = 1;
  bool do_mult = 1;
  bool do_rand = 1;
  bool do_experimental = 0;
  bool do_print = 1;
  bool do_load_store = 0;


  // set state stuff
  gmp_randinit_default (state);


  // sample vectors
  // encryption
  vector<double> samples_enc_128_k_512(num_runs, 0);
  vector<double> samples_dec_128_k_512(num_runs, 0);
  vector<double> samples_hadd_128_k_512(num_runs, 0);
  vector<double> samples_smul_128_k_512(num_runs, 0);

  vector<double> samples_enc_128_k_704(num_runs, 0);
  vector<double> samples_dec_128_k_704(num_runs, 0);
  vector<double> samples_hadd_128_k_704(num_runs, 0);
  vector<double> samples_smul_128_k_704(num_runs, 0);

  vector<double> samples_enc_192_k_704(num_runs, 0);
  vector<double> samples_dec_192_k_704(num_runs, 0);
  vector<double> samples_hadd_192_k_704(num_runs, 0);
  vector<double> samples_smul_192_k_704(num_runs, 0);

  vector<double> samples_enc_128_k_1024(num_runs, 0);
  vector<double> samples_dec_128_k_1024(num_runs, 0);
  vector<double> samples_hadd_128_k_1024(num_runs, 0);
  vector<double> samples_smul_128_k_1024(num_runs, 0);

  vector<double> samples_enc_192_k_1024(num_runs, 0);
  vector<double> samples_dec_192_k_1024(num_runs, 0);
  vector<double> samples_hadd_192_k_1024(num_runs, 0);
  vector<double> samples_smul_192_k_1024(num_runs, 0);

  vector<double> samples_enc_128_k_1280(num_runs, 0);
  vector<double> samples_dec_128_k_1280(num_runs, 0);
  vector<double> samples_hadd_128_k_1280(num_runs, 0);
  vector<double> samples_smul_128_k_1280(num_runs, 0);

  vector<double> samples_enc_192_k_1280(num_runs, 0);
  vector<double> samples_dec_192_k_1280(num_runs, 0);
  vector<double> samples_hadd_192_k_1280(num_runs, 0);
  vector<double> samples_smul_192_k_1280(num_runs, 0);


  // multiplication
  vector<double> samples_mul(num_runs, 0);
  vector<double> samples_mul_x64(num_runs, 0);
  vector<double> samples_mul_40(num_runs, 0);
  vector<double> samples_mul_64(num_runs, 0);
  vector<double> samples_mul_80(num_runs, 0);
  vector<double> samples_mul_128(num_runs, 0);
  vector<double> samples_mul_192(num_runs, 0);
  vector<double> samples_mul_512(num_runs, 0);
  vector<double> samples_exp_512(num_runs, 0);


  // random
  vector<double> samples_rand_chacha_192(num_runs, 0);
  vector<double> samples_rand_chacha_128(num_runs, 0);

  // experimental
  vector<double> samples_rand_stream(num_runs, 0);
  vector<double> samples_rand_import(num_runs, 0);
  vector<double> samples_rand_fast_import(num_runs, 0);
  vector<double> samples_rand_import_big(num_runs, 0);
  vector<double> samples_rand_fast_import_big(num_runs, 0);
  vector<double> samples_rand_shift_big(num_runs, 0);
  vector<double> samples_rand_fast_shift_big(num_runs, 0);

  // run tests
  if (do_load_store) {
    measure_load_store_vector(num_runs, 1);
    measure_load_store_vector(num_runs, 10);
    measure_load_store_vector(num_runs, 100);
    measure_load_store_vector(num_runs, 1000);
    measure_load_store_vector(num_runs, 10000);
    measure_load_store_vector(num_runs, 100000);
  }

  measure_mm(5, 200);
  measure_p3(1, 200, 350);

  for (int i = 0; i < num_runs; i++) {
    if (do_enc) {
      mpz_t m, n, scalar;
      mpz_init(m);
      mpz_init(n);
      mpz_init(scalar);

      int smul_exp_128 = 64;
      int smul_exp_192 = 96;
      int prime_size;

      // 192 bit plain, 1280 bit encryption
      prime_size = 192;
      mpz_urandomb(m, state, prime_size);
      mpz_urandomb(n, state, prime_size);
      mpz_urandomb(scalar, state, smul_exp_192);
      measure_encryption(v3, &samples_enc_192_k_1280[i], &samples_dec_192_k_1280[i],
                         &samples_hadd_192_k_1280[i],  &samples_smul_192_k_1280[i],
                         m, n, scalar);

      // 128 bit plain, 1280 bit encryption
      prime_size = 128;
      mpz_urandomb(m, state, prime_size);
      mpz_urandomb(n, state, prime_size);
      mpz_urandomb(scalar, state, smul_exp_128);
      measure_encryption(v3, &samples_enc_128_k_1280[i], &samples_dec_128_k_1280[i],
                         &samples_hadd_128_k_1280[i],  &samples_smul_128_k_1280[i],
                         m, n, scalar);


      // 192 bit plain, 1024 bit encryption
      prime_size = 192;
      mpz_urandomb(m, state, prime_size);
      mpz_urandomb(n, state, prime_size);
      mpz_urandomb(scalar, state, smul_exp_192);
      measure_encryption(v4, &samples_enc_192_k_1024[i], &samples_dec_192_k_1024[i],
                         &samples_hadd_192_k_1024[i],  &samples_smul_192_k_1024[i],
                         m, n, scalar);

      prime_size = 128;
      mpz_urandomb(m, state, prime_size);
      mpz_urandomb(n, state, prime_size);
      mpz_urandomb(scalar, state, smul_exp_128);
      measure_encryption(v4, &samples_enc_128_k_1024[i], &samples_dec_128_k_1024[i],
                         &samples_hadd_128_k_1024[i],  &samples_smul_128_k_1024[i],
                         m, n, scalar);



      // 192 bit plain, 704 bit encryption
      prime_size = 192;
      mpz_urandomb(m, state, prime_size);
      mpz_urandomb(n, state, prime_size);
      mpz_urandomb(scalar, state, smul_exp_192);
      measure_encryption(v, &samples_enc_192_k_704[i], &samples_dec_192_k_704[i],
                         &samples_hadd_192_k_704[i],  &samples_smul_192_k_704[i],
                         m, n, scalar);

      // 128 bit plain, 704 bit encryption
      prime_size = 128;
      mpz_urandomb(m, state, prime_size);
      mpz_urandomb(n, state, prime_size);
      mpz_urandomb(scalar, state, smul_exp_128);
      measure_encryption(v, &samples_enc_128_k_704[i], &samples_dec_128_k_704[i],
                         &samples_hadd_128_k_704[i],  &samples_smul_128_k_704[i],
                         m, n, scalar);

      // 128 bit plain, 512 bit encryption
      prime_size = 128;
      mpz_urandomb(m, state, prime_size);
      mpz_urandomb(n, state, prime_size);
      mpz_urandomb(scalar, state, smul_exp_128);
      measure_encryption(v2, &samples_enc_128_k_512[i], &samples_dec_128_k_512[i],
                         &samples_hadd_128_k_512[i],  &samples_smul_128_k_512[i],
                         m, n, scalar);
    }

    if (do_mult) {
      mpz_t a, b;
      mpz_init(a);
      mpz_init(b);

      // 40 bit gmp
      mpz_urandomb(a, state, 40);
      mpz_urandomb(b, state, 40);
      measure_mult(&samples_mul_40[i], a, b);


      // 80 bits gmp
      mpz_urandomb(a, state, 80);
      mpz_urandomb(b, state, 80);
      measure_mult(&samples_mul_80[i], a, b);


      // 64 bit gmp
      mpz_urandomb(a, state, 64);
      mpz_urandomb(b, state, 64);
      measure_mult(&samples_mul_64[i], a, b);


      // 128 bit gmp
      mpz_urandomb(a, state, 128);
      mpz_urandomb(b, state, 128);
      measure_mult(&samples_mul_128[i], a, b);


      // 192 bit gmp
      mpz_urandomb(a, state, 192);
      mpz_urandomb(b, state, 192);
      measure_mult(&samples_mul_192[i], a, b);


      // 512 bit gmp
      mpz_urandomb(a, state, 512);
      mpz_urandomb(b, state, 512);
      measure_mod_mult(&samples_mul_512[i], a,b, v);


      // 512 bit gmp
      measure_exp(&samples_exp_512[i], a, b, v);
    }

    Prng *prng = new Prng(PNG_CHACHA);
    if (do_rand) {
      // 192 bit Chacha
      prng->chacha_refill_randomness();
      measure_rand(&samples_rand_chacha_192[i], 192, v7);

      prng->chacha_refill_randomness();
      measure_rand(&samples_rand_chacha_128[i], 128, v7);
    }

    if (do_experimental) {
      struct rusage ru1, ru2;

      mpz_t rand;
      mpz_init(rand);
      uint64_t rs, re;

      int rand_inner_loop = 1000;
      int small_inner_loop = 10000;
      int long_inner_loop = 1000000;


      // Chacha generate stream
      prng->chacha_refill_randomness();
      getrusage(RUSAGE_SELF, &ru1);
      for (long j = 0; j < rand_inner_loop*10; j++) {
        prng->chacha_refill_randomness();
      }
      getrusage(RUSAGE_SELF, &ru2);
      double scaling_factor = 24.0/RANDOM_STATE_SIZE;
      samples_rand_stream[i] = (double)(get_spent_us(&ru1, &ru2)/(rand_inner_loop*10));
      samples_rand_stream[i] *= scaling_factor;


      // 192 bit mpz_init
      int rand_size = 24; // 24 bytes = 192 bits
      u8 buffer[rand_size];
      mpz_t t;
      mpz_init(t);
      for (int j=0; j<rand_size; j++)
        buffer[j] = (u8)random();
      getrusage(RUSAGE_SELF, &ru1);
      for (long j = 0; j < long_inner_loop; j++)
        mpz_import(t, rand_size, 1, sizeof(buffer[0]), 0, 0, buffer);
      getrusage(RUSAGE_SELF, &ru2);
      samples_rand_import[i] = (double)(get_spent_us(&ru1, &ru2)/long_inner_loop);


      // 192 bit fast_import
      getrusage(RUSAGE_SELF, &ru1);
      for (long j = 0; j < long_inner_loop*10; j++)
        fast_mpz_import(t, buffer, rand_size);
      getrusage(RUSAGE_SELF, &ru2);
      samples_rand_fast_import[i] = (double)(get_spent_us(&ru1, &ru2)/long_inner_loop/10);


      // // mpz bit shift
      mpz_t t2;
      mpz_init(t2);


      //  big mpz_init
      int big_size = RANDOM_STATE_SIZE;
      int scale = big_size/24;
      u8 buffer2[big_size];
      for (int j=0; j<big_size; j++)
        buffer2[j] = (u8)random();
      getrusage(RUSAGE_SELF, &ru1);
      for (long j = 0; j < small_inner_loop; j++)
        mpz_import(t, big_size, 1, sizeof(buffer2[0]), 0, 0, buffer2);
      getrusage(RUSAGE_SELF, &ru2);
      samples_rand_import_big[i] = (double)(get_spent_us(&ru1, &ru2)/(small_inner_loop*scale));


      //  fast big mpz_init
      getrusage(RUSAGE_SELF, &ru1);
      for (long j = 0; j < small_inner_loop; j++)
        fast_mpz_import(t, buffer2, big_size);
      getrusage(RUSAGE_SELF, &ru2);
      samples_rand_fast_import_big[i] = (double)(get_spent_us(&ru1, &ru2)/(small_inner_loop*scale));


      // big mpz bit shift
      getrusage(RUSAGE_SELF, &ru1);
      for (long j = 0; j < long_inner_loop; j++)
        mpz_fdiv_q_2exp(t2, t, 192);
      getrusage(RUSAGE_SELF, &ru2);
      samples_rand_shift_big[i] = (double)(get_spent_us(&ru1, &ru2)/long_inner_loop);


      // big fast bit shift
      getrusage(RUSAGE_SELF, &ru1);
      for (long j = 0; j < long_inner_loop*10; j++)
        split(t, t2, 192);
      getrusage(RUSAGE_SELF, &ru2);
      samples_rand_fast_shift_big[i] = (double)(get_spent_us(&ru1, &ru2)/long_inner_loop/10);
    }
  }


  if (do_print) {
    cout<<"* public_modulus_size "<<v->get_public_modulus_size()<<endl;
    cout<<"* elgamal_priv_rand_bits "<<v->get_elgamal_priv_key_size()<<endl;

    // encryption
    if (do_enc) {
      print_stats("enc_128_k_1280", samples_enc_128_k_1280);
      print_stats("dec_128_k_1280", samples_dec_128_k_1280);
      print_stats("hadd_128_k_1280", samples_hadd_128_k_1280);
      print_stats("smul_128_k_1280", samples_smul_128_k_1280);

      print_stats("enc_192_k_1280", samples_enc_192_k_1280);
      print_stats("dec_192_k_1280", samples_dec_192_k_1280);
      print_stats("hadd_192_k_1280", samples_hadd_192_k_1280);
      print_stats("smul_192_k_1280", samples_smul_192_k_1280);


      print_stats("enc_128_k_1024", samples_enc_128_k_1024);
      print_stats("dec_128_k_1024", samples_dec_128_k_1024);
      print_stats("hadd_128_k_1024", samples_hadd_128_k_1024);
      print_stats("smul_128_k_1024", samples_smul_128_k_1024);

      print_stats("enc_192_k_1024", samples_enc_192_k_1024);
      print_stats("dec_192_k_1024", samples_dec_192_k_1024);
      print_stats("hadd_192_k_1024", samples_hadd_192_k_1024);
      print_stats("smul_192_k_1024", samples_smul_192_k_1024);

      print_stats("enc_128_k_704", samples_enc_128_k_704);
      print_stats("dec_128_k_704", samples_dec_128_k_704);
      print_stats("hadd_128_k_704", samples_hadd_128_k_704);
      print_stats("smul_128_k_704", samples_smul_128_k_704);

      print_stats("enc_192_k_704", samples_enc_192_k_704);
      print_stats("dec_192_k_704", samples_dec_192_k_704);
      print_stats("hadd_192_k_704", samples_hadd_192_k_704);
      print_stats("smul_192_k_704", samples_smul_192_k_704);

      print_stats("enc_128_k_512", samples_enc_128_k_512);
      print_stats("dec_128_k_512", samples_dec_128_k_512);
      print_stats("hadd_128_k_512", samples_hadd_128_k_512);
      print_stats("smul_128_k_512", samples_smul_128_k_512);
    }


    // multiplication
    if (do_mult) {
      print_stats("mul_40", samples_mul_40);
      print_stats("mul_64", samples_mul_64);
      print_stats("mul_80", samples_mul_80);
      print_stats("mul_128", samples_mul_128);
      print_stats("mul_192",samples_mul_192);
      print_stats("mul_mod_512", samples_mul_512);
      print_stats("exp_512", samples_exp_512);
    }

    // random
    if (do_rand) {
      print_stats("chacha_192", samples_rand_chacha_192);
      print_stats("chacha_128", samples_rand_chacha_128);
    }

    // experimental
    if (do_experimental) {
      print_stats("chacha_stream_cost", samples_rand_stream);
      print_stats("mpz_import_cost", samples_rand_import);
      print_stats("mpz_fast_import_cost", samples_rand_fast_import);
      print_stats("mpz_import_cost_big", samples_rand_import_big);
      print_stats("mpz_fast_import_cost_big", samples_rand_fast_import_big);
      print_stats("mpz_shift_cost_big", samples_rand_shift_big);
      print_stats("mpz_fast_shift_cost_big", samples_rand_fast_shift_big);
    }
  }
  return 0;
}
