#include <apps/bisect_p.h>

BisectProver::
BisectProver(int ph, int b_size, int num_r, int input_size)
  : Prover(ph, b_size, num_r, input_size, PROVER_NAME)
{
  L = 10;
  init_state();
}

void BisectProver::
init_state()
{
  num_bits_in_prime = 128;
  num_bits_in_input = 32;
  crypto_in_use = CRYPTO_ELGAMAL;
  png_in_use = PNG_CHACHA;
  
  num_lin_pcp_queries = NUM_LIN_PCP_QUERIES;
 
  // initialize prover's state
  Prover::init_state();
 
  num_vars = 4*m + 2*m*L + 1 * L; // modify that 1 and add all variables of < gate
  
  alloc_init_vec(&F1, num_vars);
  alloc_init_vec(&F2, num_vars*num_vars);
 
  alloc_init_vec(&f1_commitment, expansion_factor*num_vars);
  alloc_init_vec(&f1_consistency, expansion_factor*num_vars);
  alloc_init_vec(&f1_q, num_vars);
  alloc_init_vec(&f1_q2, num_vars);
  alloc_init_vec(&f1_q3, num_vars);

  alloc_init_vec(&f2_commitment, expansion_factor*num_vars*num_vars);
  alloc_init_vec(&f2_consistency, expansion_factor*num_vars*num_vars);
  alloc_init_vec(&f2_q, num_vars*num_vars);
  alloc_init_vec(&f2_q2, num_vars*num_vars);
  alloc_init_vec(&f2_q3, num_vars*num_vars);
  
  alloc_init_vec(&f_answers, num_lin_pcp_queries);
  alloc_init_vec(&dotp, expansion_factor);
  alloc_init_scalar(answer);

  F_ptrs.clear();
  F_ptrs.push_back(F1);
  F_ptrs.push_back(F2);
  f_q_ptrs.clear();
  f_q_ptrs.push_back(f1_q);
  f_q_ptrs.push_back(f2_q);

  f_q2_ptrs.clear();
  f_q2_ptrs.push_back(f1_q2);
  f_q2_ptrs.push_back(f2_q2);
  
  find_cur_qlengths();
  
  // initialize computation state
  alloc_init_vec(&B, num_vars*num_vars);
  alloc_init_vec(&Y, num_vars);
}

void BisectProver::
find_cur_qlengths()
{
  sizes.clear();
  sizes.push_back(num_vars);
  sizes.push_back(num_vars*num_vars);  

  qquery_sizes.clear();
  qquery_sizes.push_back(num_vars);
  qquery_sizes.push_back(num_vars);
  qquery_sizes.push_back(num_vars*num_vars);
  qquery_sizes.push_back(num_vars*num_vars);
  qquery_sizes.push_back(num_vars);
  qquery_sizes.push_back(num_vars*num_vars);
  qquery_f_ptrs.clear();
  qquery_f_ptrs.push_back(f1_q);
  qquery_f_ptrs.push_back(f1_q);
  qquery_f_ptrs.push_back(f2_q);
  qquery_f_ptrs.push_back(f2_q);
  qquery_f_ptrs.push_back(f1_q);
  qquery_f_ptrs.push_back(f2_q);
  qquery_F_ptrs.clear();
  qquery_F_ptrs.push_back(F1);
  qquery_F_ptrs.push_back(F1);
  qquery_F_ptrs.push_back(F2);
  qquery_F_ptrs.push_back(F2);
  qquery_F_ptrs.push_back(F1);
  qquery_F_ptrs.push_back(F2);
  
  qquery_q_ptrs.clear();
  qquery_q_ptrs.push_back(Q1);
  qquery_q_ptrs.push_back(Q2);
  qquery_q_ptrs.push_back(Q3);
  qquery_q_ptrs.push_back(Q4);
  qquery_q_ptrs.push_back(Q5);
  qquery_q_ptrs.push_back(Q6);
}

// COMPUTATION
void BisectProver::
computation()
{

  for (int i=0; i<num_vars; i++)
  {
    mpz_set_ui(F1[i], 10);
  }
/*  for (int i=0; i<m; i++)
    mpz_set_ui(Y[i], 0);
  
  for (int i=0; i<m; i++) {
    for (int j=0; j<m; j++) {
      if (mpz_cmp(F1[j], B[i*m+j]) == 0) {
        mpz_set_ui(F3[i*m+j], 0);
        mpz_set_ui(F2[i*m+j], 0);
      } else {
        mpz_add_ui(Y[i], Y[i], 1);
        mpz_set_ui(F3[i*m+j], 1);
        mpz_sub(F2[i*m+j], F1[j], B[i*m+j]);
        mpz_mod(F2[i*m+j], F2[i*m+j], prime);
        int ret= mpz_invert(F2[i*m+j], F2[i*m+j], prime);
       }
    }
  }
*/
}

//PROVER's CODE
void BisectProver::
prover_computation_commitment()
{
  // init prover
  load_vector(expansion_factor*num_vars, f1_commitment, (char *)"f1_commitment_query", FOLDER_WWW_DOWNLOAD);
  load_vector(expansion_factor*num_vars*num_vars, f2_commitment, (char *)"f2_commitment_query", FOLDER_WWW_DOWNLOAD);

  // execute the computation
  m_comp.begin_with_init();
  //load_vector(num_vars*num_vars, B, (char *)"input0", FOLDER_WWW_DOWNLOAD);
  m_comp.end();

  for (int i=batch_start; i<=batch_end; i++)
  {
    m_comp.begin_with_history();
    snprintf(scratch_str, BUFLEN-1, "input1_b_%d", i); 
    //load_vector(num_vars, F1, scratch_str, FOLDER_WWW_DOWNLOAD);

    computation();

    snprintf(scratch_str, BUFLEN-1, "output_b_%d", i); 
    //dump_vector(num_vars, Y, scratch_str, FOLDER_WWW_DOWNLOAD);
    m_comp.end();

    // start saving the state
    for (int ii=0; ii<num_vars; ii++) 
    {
      mpz_mod(F1[ii], F1[ii], prime);
      for (int jj=0; jj<num_vars; jj++)
      {
        mpz_mul(F2[ii*num_vars+jj], F1[ii], F1[jj]);
        mpz_mod(F2[ii*num_vars+jj], F2[ii*num_vars+jj], prime);
      }
    }
    snprintf(scratch_str, BUFLEN-1, "f1_assignment_vector_b_%d", i); 
    dump_vector(num_vars, F1, scratch_str, FOLDER_WWW_DOWNLOAD);
   
    snprintf(scratch_str, BUFLEN-1, "f2_assignment_vector_b_%d", i); 
    dump_vector(num_vars*num_vars, F2, scratch_str, FOLDER_WWW_DOWNLOAD);
  }
  
  for (int i=batch_start; i<=batch_end; i++)
  { 
    if (i == 0)
      m_proof_work.begin_with_init();
    else
      m_proof_work.begin_with_history();

    snprintf(scratch_str, BUFLEN-1, "f1_assignment_vector_b_%d", i); 
    load_vector(num_vars, F1, scratch_str, FOLDER_WWW_DOWNLOAD);
    
    snprintf(scratch_str, BUFLEN-1, "f2_assignment_vector_b_%d", i); 
    load_vector(num_vars*num_vars, F2, scratch_str, FOLDER_WWW_DOWNLOAD);
 
    if (crypto_in_use == CRYPTO_ELGAMAL)
      v->dot_product_enc(num_vars, f1_commitment, F1, dotp[0], dotp[1]);
    
    if (crypto_in_use == CRYPTO_ELGAMAL)
      v->dot_product_enc(num_vars*num_vars, f2_commitment, F2, Y[0], Y[1]);
    
    v->add_enc(dotp[0], dotp[1], dotp[0], dotp[1], Y[0], Y[1]);

    snprintf(scratch_str, BUFLEN-1, "f_commitment_answer_b_%d", i); 
    dump_vector(expansion_factor, dotp, scratch_str, FOLDER_WWW_DOWNLOAD);
    
    m_proof_work.end();
  }
}

void BisectProver::deduce_queries()
{
}
