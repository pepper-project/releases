#include <apps/bisect_v.h>

BisectVerifier::BisectVerifier(int batch, int reps, int ip_size,
  int optimize_answers, char *prover_url)
  : Verifier(batch, reps, ip_size, optimize_answers, prover_url, NAME_PROVER)
{
  m = ip_size; // move this to base class and change it in every app
  L = 10;
  init_state();
}

void BisectVerifier::init_state()
{
  num_bits_in_prime = 128;
  num_bits_in_input = 32;
  crypto_in_use = CRYPTO_ELGAMAL;
  png_in_use = PNG_CHACHA;
  
  // input and output of the computation
  num_coefficients = (m*m + 3*m)/2 + 1;
  alloc_init_vec(&coefficients, num_coefficients);
  alloc_init_vec(&X_in, m);
  alloc_init_vec(&Y_in, m);
  alloc_init_vec(&X_out, m);
  alloc_init_vec(&Y_out, m);

  num_cons = 4*m + 2*m*L + 1 * L; 
  num_vars = 4*m + 2*m*L + 1 * L; // modify that 1 and add all variables of < gate

  // state of the verifier
  num_lin_pcp_queries = NUM_LIN_PCP_QUERIES_F1 + NUM_LIN_PCP_QUERIES_F2;
  Verifier::init_state();
  
  alloc_init_vec(&f1_commitment, expansion_factor*num_vars);
  alloc_init_vec(&f2_commitment, expansion_factor*num_vars*num_vars);
 
  alloc_init_vec(&f1_consistency, expansion_factor*num_vars);
  alloc_init_vec(&f2_consistency, expansion_factor*num_vars*num_vars);
  
  alloc_init_vec(&f1_con_coins, num_repetitions * NUM_LIN_PCP_QUERIES_F1);
  alloc_init_vec(&f2_con_coins, num_repetitions * NUM_LIN_PCP_QUERIES_F2);

  alloc_init_vec(&f1_q1, num_vars);
  alloc_init_vec(&f1_q2, num_vars);
  alloc_init_vec(&f1_q3, num_vars);

  alloc_init_vec(&f2_q1, num_vars*num_vars);
  alloc_init_vec(&f2_q2, num_vars*num_vars);
  alloc_init_vec(&f2_q3, num_vars*num_vars);
  
  alloc_init_vec(&alpha, num_cons); 
  alloc_init_vec(&f_answers, num_repetitions * num_lin_pcp_queries);
  alloc_init_vec(&f1_answers, num_repetitions * NUM_LIN_PCP_QUERIES_F1);
  alloc_init_vec(&f2_answers, num_repetitions * NUM_LIN_PCP_QUERIES_F2);
  alloc_init_vec(&ckt_answers, 4);
  
  alloc_init_vec(&temp_arr, expansion_factor);
  alloc_init_vec(&temp_arr2, expansion_factor);

  alloc_init_scalar(c_init_val);
  alloc_init_scalar(a1);
  alloc_init_scalar(a2);
  alloc_init_scalar(f1_s);
  alloc_init_scalar(f2_s);
  mpz_init(temp);
  mpz_init(neg);
  mpz_init(neg_i);

  // To create consistency and commitment queries.
  commitment_query_sizes.clear();
  commitment_query_sizes.push_back(num_vars);
  commitment_query_sizes.push_back(num_vars*num_vars);
  
  f_commitment_ptrs.clear();
  f_commitment_ptrs.push_back(f1_commitment);
  f_commitment_ptrs.push_back(f2_commitment);
  
  f_consistency_ptrs.clear();
  f_consistency_ptrs.push_back(f1_consistency);
  f_consistency_ptrs.push_back(f2_consistency);
  
  con_coins_ptrs.clear();
  con_coins_ptrs.push_back(f1_con_coins);
  con_coins_ptrs.push_back(f2_con_coins);
  
  temp_arr_ptrs.clear();
  temp_arr_ptrs.push_back(temp_arr);
  temp_arr_ptrs.push_back(temp_arr2);
  
  scalar_s_ptrs.clear();
  scalar_s_ptrs.push_back(&f1_s);
  scalar_s_ptrs.push_back(&f2_s);
  
  scalar_a_ptrs.clear();
  scalar_a_ptrs.push_back(&a1);
  scalar_a_ptrs.push_back(&a2);
  
  answers_rfetch_ptrs.clear();
  answers_rfetch_ptrs.push_back(f1_answers);
  answers_rfetch_ptrs.push_back(f2_answers);
  
  answers_ptrs.clear();
  answers_ptrs.push_back(f1_answers);
  answers_ptrs.push_back(f2_answers);
  
  Q_list.clear();
  Q_list.push_back(Q1);
  Q_list.push_back(Q2);
  Q_list.push_back(Q3);
  Q_list.push_back(Q4);
  Q_list.push_back(Q5);
  Q_list.push_back(Q6);
  
  pcp_queries.clear();
  pcp_queries.push_back(NUM_LIN_PCP_QUERIES_F1);
  pcp_queries.push_back(NUM_LIN_PCP_QUERIES_F2);
}

void BisectVerifier::create_input()
{
  v->get_random_vec(num_coefficients, coefficients, num_bits_in_input);
  dump_vector(num_coefficients, coefficients, (char *)"input0");
  send_file((char *)"input0");

  // as many computations as inputs
  for (int k=0; k<batch_size; k++)
  {
    // need logic here to generate these such that they enclose a root
    v->get_random_vec(m, X_in, num_bits_in_input);
    snprintf(scratch_str, BUFLEN-1, "input1_b_%d", k); 
    dump_vector(m, X_in, scratch_str);
    send_file(scratch_str);
 
    v->get_random_vec(m, Y_in, num_bits_in_input);
    snprintf(scratch_str, BUFLEN-1, "input2_b_%d", k); 
    dump_vector(m, Y_in, scratch_str);
    send_file(scratch_str); 
  }
}

void BisectVerifier::create_plain_queries()
{
  cout<<"Creating plain queries "<<endl;
  // keeps track of #filled coins
  int f1_con_filled = -1;
  int f2_con_filled = -1;
  
  for (int rho=0; rho<num_repetitions; rho++)
  {
    if (rho == 0) m_plainq.begin_with_init();
    else m_plainq.begin_with_history();
    v->create_corr_test_queries(num_vars, f1_q1, num_vars, f1_q2,
        f2_q2, f2_q1, f1_consistency, f1_consistency, f2_consistency,
        f1_con_filled, f1_con_coins, f1_con_filled+1, f1_con_coins,
        f2_con_filled, f2_con_coins, prime, false);

    f1_con_filled += 2;
    f2_con_filled += 2;
  
    cout<<"Creating corr plain queries "<<endl;
    
    snprintf(scratch_str, BUFLEN-1, "q1_qquery_r_%d", rho);
    dump_vector(num_vars, f1_q1, scratch_str);
    send_file(scratch_str);

    snprintf(scratch_str, BUFLEN-1, "q2_qquery_r_%d", rho);
    dump_vector(num_vars, f1_q2, scratch_str);
    send_file(scratch_str);
    
    snprintf(scratch_str, BUFLEN-1, "q3_qquery_r_%d", rho);
    dump_vector(num_vars*num_vars, f2_q2, scratch_str);
    send_file(scratch_str);
    
    snprintf(scratch_str, BUFLEN-1, "q4_qquery_r_%d", rho);
    dump_vector(num_vars*num_vars, f2_q1, scratch_str);
    send_file(scratch_str);
    
    // circuit test queries
    cout<<"Creating ckt plain queries "<<endl;
    snprintf(scratch_str, BUFLEN-1, "input0"); 
    load_vector(num_coefficients, coefficients, scratch_str);

    // start with generating a random alpha for each constraint
    v->get_random_vec(num_cons, alpha, prime);
 
    // start with \gamma_1
    for (int i=0; i<num_vars; i++) {
      mpz_set_ui(f1_q2[i], 0);
    }
    for (int i=0; i<num_vars*num_vars; i++) {
      mpz_set_ui(f2_q2[i], 0);
    }
    
    // xin -X^{0} m constraints
    mpz_t *X0 = &f1_q2[0];
    mpz_t *Y0 = &f1_q2[m];
    
    int con_id = 0;
    for (int i=0; i<m; i++) {
      mpz_neg(neg, alpha[con_id]);
      mpz_add(X0[i], X0[i], neg);
      con_id++;
    }

    // yin -Y^{0} m constraints
    con_id = m;
    for (int i=0; i<m; i++) {
      mpz_neg(neg, alpha[con_id]);
      mpz_add(Y0[i], Y0[i], neg);
      con_id++;
    }
    
    // -2 X^{k} + 2 X^{k-1}
    for (int k=1; k<=L; k++) {
      mpz_t *Xk = &f1_q2[k*2*m];
      mpz_t *Xk_1 = &f1_q2[k*(2*m) - 2*m];
      con_id = k*2*m; 
      for (int i=0; i<m; i++) {
        
        // -2 X^{k}
        mpz_mul_si(neg, alpha[con_id], -2);
        mpz_add(Xk[i], Xk[i], neg);
        
        
        // 2X^{k-1} m constraints 
        mpz_mul_ui(neg, alpha[con_id], 2);
        mpz_add(Xk_1[i], Xk_1[i], neg);
      
      
        con_id++;
      }
    }

    
    for (int k=1; k<=L; k++)
    {
      mpz_t *Xk_1 = &f1_q2[k*(2*m) - 2*m];
      mpz_t *Yk_1 = &f1_q2[k*(2*m) - m];
      mpz_t *Yk = &f1_q2[k*(2*m) + m];
      con_id = k* 2 * m + m; 
      for (int i=0; i<m; i++)
      {
        // X^{k-1} m constraints
        mpz_add(Xk_1[i], Xk_1[i], alpha[con_id]);
        
        // Y^{k-1} m constraints
        mpz_add(Yk[i], Yk[i], alpha[con_id]);
         
        // -2 Y^{-k}
        mpz_mul_si(neg, alpha[con_id], -2);
        mpz_add(Yk[i], Yk[i], neg); 
        con_id++;
      }
    }
  
    // output connstraints

  /*
    // xout -X^{L} m constraints
    mpz_t *XL = &f1_q2[L*2*m];
    mpz_t *YL = &f1_q2[L*2*m+m];
    
    con_id = (L+1) * 2 * m;
    for (int i=0; i<m; i++) {
      mpz_neg(neg, alpha[con_id]);
      mpz_add(XL[i], XL[i], neg);
      con_id++;
    }

    // yin -Y^{0} m constraints
    con_id = (L+1)*2*m + m;
    for (int i=0; i<m; i++) {
      mpz_neg(neg, alpha[con_id]);
      mpz_add(YL[i], YL[i], neg);
      con_id++;
    }
  */

    // B^{k} - 1 for k=1 to L
    con_id = 2*m + 2*m*L + 2*m;
    mpz_t *Bk = &f1_q2[2 *m * (L+2)];
    for (int i=0; i<L; i++)
    {
      mpz_neg(neg, alpha[con_id]);
      mpz_add(Bk[i], Bk[i], neg); 
      con_id++;
    }
    
    // second, formulate \gamma_2
    
    // -B^{k} \cdot X^{k-1} m constraints
    for (int k=1; k<=L; k++)
    {
      int row_id = (L+1)*(2*m) + (k-1);
      int col_id = k*(2*m) - 2*m;
      con_id = k*2*m; 
      for (int i=0; i<m; i++)
      {
        mpz_neg(neg, alpha[con_id]);
        mpz_add(f2_q2[row_id*num_vars + (col_id+i)], f2_q2[row_id*num_vars + (col_id+i)], neg);
        con_id++;
      }
    }
 
    // B^{k} \cdot Y^{k-1} m constraints
    for (int k=1; k<=L; k++)
    {
      int row_id = (L+1)*(2*m) + (k-1);
      int col_id = k*(2*m) - m;
      con_id = k*2*m; 
      for (int i=0; i<m; i++)
      {
        mpz_add(f2_q2[row_id*num_vars + (col_id+i)], f2_q2[row_id*num_vars + (col_id+i)], alpha[con_id]); 
        con_id++;
      }
    }

    // -B^{k} \cdot X^{k-1} m constraints
    for (int k=1; k<=L; k++)
    {
      int row_id = (L+1)*(2*m) + (k-1);
      int col_id = k*(2*m) - 2*m;
      con_id = k*2*m + m; 
      for (int i=0; i<m; i++)
      {
        mpz_neg(neg, alpha[con_id]);
        mpz_add(f2_q2[row_id*num_vars + (col_id+i)], f2_q2[row_id*num_vars + (col_id+i)], neg);
        con_id++;
      }
    }

    // B^{k} \cdot Y^{k-1} m constraints
    for (int k=1; k<=L; k++)
    {
      int row_id = (L+1)*(2*m) + (k-1);
      int col_id = k*(2*m) - m;
      con_id = k*2*m + m; 
      for (int i=0; i<m; i++)
      {
        mpz_add(f2_q2[row_id*num_vars + (col_id+i)], f2_q2[row_id*num_vars + (col_id+i)], alpha[con_id]); 
        con_id++;
      }
    }
   
    v->create_ckt_test_queries(num_vars, f1_q2, f1_q3, f1_q1,
      f1_consistency, f1_con_filled, f1_con_coins, prime);
    
    v->create_ckt_test_queries(num_vars*num_vars, f2_q2, f2_q3, f2_q1,
      f2_consistency, f2_con_filled, f2_con_coins, prime);
    
    cout<<"done Creating ckt plain queries "<<endl;
    
    snprintf(scratch_str, BUFLEN-1, "q5_qquery_r_%d", rho);
    dump_vector(num_vars, f1_q3, scratch_str);
    send_file(scratch_str);

    snprintf(scratch_str, BUFLEN-1, "q6_qquery_r_%d", rho);
    dump_vector(num_vars*num_vars, f2_q3, scratch_str);
    send_file(scratch_str);
    
    // compute a component of \gamma_0
    if (rho == 0) m_runtests.begin_with_init();
    else m_runtests.begin_with_history();

    // finally compute \gamma_0
    for (int b=0; b<batch_size; b++)
    {
      snprintf(scratch_str, BUFLEN-1, "input1_b_%d", b); 
      load_vector(m, X_in, scratch_str);
      
      snprintf(scratch_str, BUFLEN-1, "input2_b_%d", b); 
      load_vector(m, Y_in, scratch_str);

      int c_index = b * num_repetitions + rho; 
      mpz_set_ui(c_values[c_index], 0);
     
      con_id = 0;
      for (int i=0; i<m; i++) {
        mpz_mul(temp, X_in[i], alpha[con_id]);
        mpz_add(c_values[c_index], c_values[c_index], temp);
        con_id++;
      }

      con_id = m;
      for (int i=0; i<m; i++) {
        mpz_mul(temp, Y_in[i], alpha[con_id]);
        mpz_add(c_values[c_index], c_values[c_index], temp);
        con_id++;
      }
      mpz_mod(c_values[c_index], c_values[c_index], prime);
    }
    m_runtests.end();
    f1_con_filled += 1;
    f2_con_filled += 1;
  }
  dump_vector(num_vars, f1_consistency, (char *)"f1_consistency_query");
  send_file((char *)"f1_consistency_query");
    
  dump_vector(num_vars*num_vars, f2_consistency, (char *)"f2_consistency_query");
  send_file((char *)"f2_consistency_query");
}

void BisectVerifier::populate_answers(mpz_t *f_answers, int rho, int num_repetitions, int beta)
{ 
  uint32_t i = rho * num_lin_pcp_queries;
 
  mpz_set(f_con_coins[i+Q1], f1_con_coins[i+0]);
  mpz_set(f_con_coins[i+Q2], f1_con_coins[i+1]);
  mpz_set(f_con_coins[i+Q5], f1_con_coins[i+2]);
  
  mpz_set(f_con_coins[i+Q3], f2_con_coins[i+0]);
  mpz_set(f_con_coins[i+Q4], f2_con_coins[i+1]);
  mpz_set(f_con_coins[i+Q6], f2_con_coins[i+2]);
}

void BisectVerifier::run_correction_and_circuit_tests(uint32_t beta)
{
    for (int rho=0; rho<num_repetitions; rho++)
    {
      // Quad Correction test and Circuit test
      bool cor1 = v->corr_test(f_answers[rho*num_lin_pcp_queries + Q1],
          f_answers[rho*num_lin_pcp_queries + Q2],
          f_answers[rho*num_lin_pcp_queries + Q3],
          f_answers[rho*num_lin_pcp_queries + Q4],
          prime);

      
      if (false == cor1)
        cout<<"LOG: F1 failed the correction test"<<endl;
      else
        cout<<"LOG: F1 passed correction test"<<endl;

      mpz_set(ckt_answers[0], f_answers[rho*num_lin_pcp_queries + Q5]);
      mpz_set(ckt_answers[1], f_answers[rho*num_lin_pcp_queries + Q1]);
      
      mpz_set(ckt_answers[2], f_answers[rho*num_lin_pcp_queries + Q6]);
      mpz_set(ckt_answers[3], f_answers[rho*num_lin_pcp_queries + Q4]);
      
      bool ckt2 = v->ckt_test(4, ckt_answers, c_values[beta * num_repetitions + rho], prime);

      if (false == ckt2)
        cout <<"LOG: F1, F2 failed the circuit test"<<endl;
      else
        cout <<"LOG: F1, F2 passed the circuit test"<<endl;
    }
}
