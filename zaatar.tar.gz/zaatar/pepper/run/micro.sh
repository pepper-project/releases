rm -rf /tmp/computation_state/*
./bin/micro2
