#include <iostream>

#include "cmt_circuit.h"

using namespace std;

size_t CMTCircuit::
getInputSize() const
{
  return inGates.size();
}

size_t CMTCircuit::
getOutputSize() const
{
  return outGates.size();
}

size_t CMTCircuit::
getMagicSize() const
{
  return magicGates.size();
}

static void
setGates(vector<Gate*>& gates, const MPQVector& vec, const mpz_t prime)
{
  for (size_t i = 0; i < gates.size(); i++)
  {
    Gate* gate = gates[i];
    if (gate && i < vec.size())
      gate->setValue(vec[i], prime);
  }
}

void CMTCircuit::
initializeInputs(const MPQVector& inputs, const MPQVector& magic)
{
  setGates(inGates, inputs, prime);
  setGates(magicGates, magic, prime);
}

void CMTCircuit::
initializeOutputs(const MPQVector& outputs)
{
  setGates(outGates, outputs, prime);
}

static void
getGates(MPQVector& vec, const vector<Gate*>& gates, const mpz_t prime)
{
  for (size_t i = 0; i < gates.size(); i++)
  {
    Gate* gate = gates[i];
    gate->canonicalize(prime);
    if (gate && i < vec.size())
      mpq_set(vec[i], gate->valq);
  }
}

void CMTCircuit::
getInputs(MPQVector& inputs) const
{
  getGates(inputs, inGates, prime);
}

void CMTCircuit::
getOutputs(MPQVector& outputs) const
{
  getGates(outputs, outGates, prime);
}

void CMTCircuit::
getMagics(MPQVector& magics) const
{
  getGates(magics, magicGates, prime);
}

void CMTCircuit::
addGatesFromLevel(vector<Gate*>& gates, int level, int start, int end)
{
  CircuitLayer& layer = (*this)[level];
  for (int i = start; i < end; i++)
  {
    gates.push_back(&layer[i]);
  }
}

