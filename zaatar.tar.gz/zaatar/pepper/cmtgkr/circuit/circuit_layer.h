#ifndef CODE_PEPPER_CMTGKR_CIRCUIT_CIRCUIT_LAYER_H_
#define CODE_PEPPER_CMTGKR_CIRCUIT_CIRCUIT_LAYER_H_

#include <gmp.h>
#include <common/mpnvector.h>

typedef void (*mle_fn)(mpz_t rop, const mpz_t* r, int mi, int mip1, int ni, int nip1, const mpz_t prime);

class Gate
{
  public:
  int type;   //0 for add, 1 for mult, -1 for input gate, else this gate computes (in1)^{-type}
  int in1;
  int in2;
  mpz_t val;
  mpq_t valq;

  // TODO: Turn into enum.
  static const int add = 0;
  static const int mul = 1;
  static const int div_int = 2;

  public:
  Gate();
  Gate(const Gate& other);
  ~Gate();

  Gate& operator= (const Gate& other);

  bool shouldBeTreatedAs(int gateType);
  void canonicalize(const mpz_t prime);

  void computeGateValue(const Gate& op1, const Gate& op2, const mpz_t prime);
  void applyGateOperation(mpz_t rop, const mpz_t op1, const mpz_t op2, const mpz_t prime) const;

  void setValue(const mpq_t value, const mpz_t prime);
  void setValue(const mpz_t value);
  void setValue(int val);

  void mk_bin_gate(int op, int in1, int in2);
  void mk_pow_gate(int in, int exp);
};

class CircuitLayer
{
  int length;

  public:
  Gate* gates;

  mle_fn add_fn;
  mle_fn mul_fn;

  public:

  CircuitLayer(int size = 0);
  CircuitLayer(const CircuitLayer& other);
  ~CircuitLayer();

  CircuitLayer& operator= (const CircuitLayer& other);

  void resize(int size);

  void computeWirePredicates(mpz_t add_predr, mpz_t mul_predr, const MPZVector& rand, int inputLayerSize, const mpz_t prime) const;

  int size() const;
  int logSize() const;
  Gate& operator[] (int idx);
  const Gate& operator[] (int idx) const;
};

#endif

