#ifndef CODE_PEPPER_CMTGKR_CIRCUIT_CMT_CIRCUIT_H_
#define CODE_PEPPER_CMTGKR_CIRCUIT_CMT_CIRCUIT_H_

#include <vector>

#include <common/mpnvector.h>

#include "circuit.h"

class CMTCircuit : public Circuit
{
  protected:
  std::vector<Gate*> inGates;
  std::vector<Gate*> outGates;
  std::vector<Gate*> magicGates;

  public:
  virtual size_t getInputSize() const;
  virtual size_t getOutputSize() const;
  virtual size_t getMagicSize() const;

  virtual void construct() = 0;

  virtual void initializeInputs(const MPQVector& inputs, const MPQVector& magic = MPQVector(0));
  virtual void initializeOutputs(const MPQVector& outputs);

  void getInputs(MPQVector& inputs) const;
  void getOutputs(MPQVector& outputs) const;
  void getMagics(MPQVector& magics) const;

  protected:
  void addGatesFromLevel(std::vector<Gate*>& gates, int level, int start, int end);
};

#endif

