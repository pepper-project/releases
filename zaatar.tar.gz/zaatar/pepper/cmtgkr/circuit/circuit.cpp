#include <gmp.h>

#include <common/utility.h>

#include <cmtgkr/cmtgkr_env.h>
#include "circuit.h"

typedef vector<CircuitLayer>::iterator LayerIt;
typedef vector<CircuitLayer>::reverse_iterator ReverseLayerIt;

template<class T>
static void
tryToDelete(T* ptr)
{
  if (ptr)
    delete ptr;
}

Circuit::
Circuit()
{
  int default_prime_size = 128; // bits
  mpz_init(prime);
  mpz_init(psub1);
  
  char scratch_str[BUFLEN];
  snprintf(scratch_str, BUFLEN - 1, "prime_%d.txt", default_prime_size);
  load_txt_scalar(prime, scratch_str, "static_state");
  // DEBUG
  //mpz_set_ui(prime, 2305843009213693951);
  mpz_sub_ui(psub1, prime, 1);
}

Circuit::
Circuit(const Circuit& other)
{
  mpz_init(prime);
  mpz_init(psub1);

  *this = other;  
}

Circuit::
~Circuit()
{
  mpz_clear(prime);
  mpz_clear(psub1);
}

int Circuit::
depth()
{
  return layers.size();
}

Circuit& Circuit::
operator= (const Circuit& other)
{
  if (this != &other)
  {
    mpz_set(prime, other.prime);
    mpz_set(psub1, other.psub1);

    current_lvl = other.current_lvl;

    // No deep copying.
    layers = other.layers;
  }

  return *this;
}

const CircuitLayer& Circuit::
operator[] (int lvl) const
{
  return layers[lvl];
}

CircuitLayer& Circuit::
operator[] (int lvl)
{
  return layers[lvl];
}

const CircuitLayer& Circuit::
getInputLayer() const
{
  return layers.back();
}

CircuitLayer& Circuit::
getInputLayer()
{
  return layers.back();
}

void Circuit::
evaluate()
{
  if (depth() < 2)
    return;

  ReverseLayerIt it = layers.rbegin();

  // Evaluate from the top down.
  while (it != --layers.rend())
  {
    CircuitLayer& prevLayer = *it;
    CircuitLayer& layer = *(++it);
    for(int j = 0; j < layer.size(); j++)
    {
      Gate& ropgate = layer[j];
      Gate& op1gate = prevLayer[ropgate.in1];
      Gate& op2gate = prevLayer[ropgate.in2];

      ropgate.computeGateValue(op1gate, op2gate, prime);

      if (false) { // DEBUG {
      gmp_printf("i: ?? | j: %d | ropgate.type: %d | ropgate.in1: %d | ropgate.in2: %d | ropgate: %Zd\n", j, ropgate.type, ropgate.in1, ropgate.in2, ropgate.val);
      }
    }
    // DEBUG cout << endl;

  }
}

void Circuit::
make_shell(int nlevels)
{
  layers.clear();
  layers.assign(nlevels, CircuitLayer());

  current_lvl = nlevels;
}

void Circuit::
make_level(int size, mle_fn add_ifn, mle_fn mul_ifn)
{
  make_level(current_lvl - 1, size, add_ifn, mul_ifn);
}

void Circuit::
make_level(int level, int size, mle_fn add_ifn, mle_fn mul_ifn)
{
  CircuitLayer& newLayer = layers[level];
  newLayer.resize(size);
  newLayer.add_fn = add_ifn;
  newLayer.mul_fn = mul_ifn;

  current_lvl = level;
}

void Circuit::
make_level(int level, int size)
{
  make_level(level, size, zero, zero);
}

Gate* Circuit::
cgates(int shift)
{
  return clayer(shift).gates;
}

int Circuit::
cgates_len(int shift)
{
  return clayer(shift).size();
}

CircuitLayer& Circuit::
clayer(int shift)
{
  return layers[current_lvl + shift];
}

void Circuit::
add_to_last_gate(int start, int end, int shift)
{
  for (int i = start; i < end; i++)
    cgates()[i].mk_bin_gate(Gate::add, shift + i, cgates_len(1) - 1);
}

template<int type> static void
make_gates(Gate *base, int start, int end, int shift, int stride)
{
  for (int i = start; i < end; i += stride)
    base[i].mk_bin_gate(type, i, shift + i);
}

void Circuit::
mul_gates(int start, int end, int shift, int stride)
{
  make_gates<Gate::mul>(cgates(), start, end, shift, stride);
}

void Circuit::
add_gates(int start, int end, int shift, int stride)
{
  make_gates<Gate::add>(cgates(), start, end, shift, stride);
}

void Circuit::
makeReduceLayer(int type, int start, int end)
{
  for (int i = start; i < end; i++)
    cgates()[i].mk_bin_gate(type, 2*i, 2*i + 1);
}

void Circuit::
make_flt_lvl2(int start, int end)
{
  for (int i = start; i < end; i++)
  {
    if (i & 1)
      cgates()[i].mk_bin_gate(Gate::mul, i >> 1, i >> 1);
    else
      cgates()[i].mk_bin_gate(Gate::add, i >> 1, cgates_len(1) - 1);
  }
}

void Circuit::
make_flt_general(int start, int end, int bit_num)
{
  for (int i = start; i < end; i++)
  {
    if (i & 1)
    {
      cgates()[i].mk_bin_gate(Gate::mul, i, i);
    }
    else
    {
      if (mpz_tstbit(psub1, bit_num))
        cgates()[i].mk_bin_gate(Gate::mul, i, i + 1);
      else
        cgates()[i].mk_bin_gate(Gate::add, i, cgates_len(1) - 1);

    }
  }
}

void Circuit::
make_flt_last(int start, int end)
{
  makeReduceLayer(Gate::mul, start, end);
}

int Circuit::
get_prime_nbits()
{
  return mpz_sizeinbase(prime, 2);
}

int Circuit::
get_flt_depth()
{
  mpz_t psub1;
  mpz_init(psub1);
  mpz_sub_ui(psub1, prime, 1);

  int depth = mpz_sizeinbase(psub1, 2);

  mpz_clear(psub1);
  return depth;
}

void Circuit::
print()
{
  int lvl = 0;
  for (LayerIt it = layers.begin(); it != layers.end(); ++it)
  {
    CircuitLayer& l = *it;

    for (int i = 0; i < l.size(); i++)
    {
      Gate *gate = &l.gates[i];
      gmp_printf("%02d | %02d | type: %d | in1: %02d | in2: %02d | val: %Zd\n",
                 lvl, i, gate->type, gate->in1,
                 gate->in2, gate->val);
    }
    cout << endl;
    lvl++;
  }
}

