#include <cmath>

#include <common/utility.h>

#include "../cmtgkr_env.h"
#include "circuit_layer.h"

Gate::
Gate() : type(0), in1(0), in2(0)
{
  mpz_init_set_ui(val, 0);
  mpq_init(valq);
  mpq_set_ui(valq, 0, 1);
}

Gate::
Gate(const Gate& other)
{
  mpz_init(val);
  mpq_init(valq);
  (*this) = other;
}

Gate::
~Gate()
{
  mpz_clear(val);
  mpq_clear(valq);
}

Gate& Gate::
operator= (const Gate& other)
{
  if (this != &other)
  {
    type = other.type;
    in1  = other.in1;
    in2  = other.in2;
    mpz_set(val, other.val);
    mpq_set(valq, other.valq);
  }
  return *this;
}

bool Gate::
shouldBeTreatedAs(int gateType)
{
  return gateType == type ||
         (gateType == Gate::mul && type == Gate::div_int) ||
         (gateType == Gate::div_int && type == Gate::mul);
}

static bool
modIfNeeded(mpz_t val, const mpz_t prime, int scale = 2)
{
  if (mpz_sizeinbase(val, 2) > scale * mpz_sizeinbase(prime, 2) - 1)
  {
    mpz_mod(val, val, prime);
    return true;
  }
  else
  {
    return false;
  }
}

static bool
modIfNeeded(mpq_t val, const mpz_t prime, int scale = 2)
{
  bool changed = false;
  changed = modIfNeeded(mpq_numref(val), prime, scale) || changed;
  changed = modIfNeeded(mpq_denref(val), prime, scale) || changed;

  if (changed)
    mpq_canonicalize(val);

  return changed;
}

void Gate::
canonicalize(const mpz_t prime)
{
  modIfNeeded(valq, prime);
  modIfNeeded(val, prime);
}

void Gate::
computeGateValue(const Gate& op1, const Gate& op2, const mpz_t prime)
{
  if (type == Gate::add)
  {
    if (mpq_sgn(op1.valq) == 0)
      mpq_set(valq, op2.valq);
    else if (mpq_sgn(op2.valq) == 0)
      mpq_set(valq, op1.valq);
    else
      mpq_add(valq, op1.valq, op2.valq);
  }
  else if (type == Gate::mul)
  {
    if ((mpq_sgn(op1.valq) == 0) || (mpq_sgn(op2.valq) == 0))
    {
      mpq_set_ui(valq, 0, 1);
      mpz_set_ui(val, 0);
      return;
    }
    else
    {
      mpq_mul(valq, op1.valq, op2.valq);
    }
  }
  else if (type == Gate::div_int)
  {
    // This requires special handling.
    MPZVector tmp(2);
    mpz_tdiv_q_2exp(tmp[0], prime, 1);

    mpz_invert(tmp[1], op2.val, prime);
    toTrueNumber(tmp[1], tmp[0], prime);

    MPQVector divisor(1);
    mpq_set_z(divisor[0], tmp[1]);
    mpq_div(valq, op1.valq, divisor[0]);
  }
  else
  {
    mpz_powm_ui(mpq_numref(valq), mpq_numref(op2.valq), -type, prime);
    mpz_powm_ui(mpq_denref(valq), mpq_denref(op2.valq), -type, prime);
    mpq_canonicalize(valq);
  }

  // Mod down the number if needed.
  modIfNeeded(valq, prime);

  applyGateOperation(val, op1.val, op2.val, prime);
}

void Gate::
applyGateOperation(mpz_t rop, const mpz_t op1, const mpz_t op2, const mpz_t prime) const
{
  if(type == Gate::add)
  {
    if (mpz_sgn(op1) == 0)
      mpz_set(rop, op2);
    else if (mpz_sgn(op2) == 0)
      mpz_set(rop, op1);
    else
      mpz_add(rop, op1, op2);
  }
  else if(type == Gate::mul || type == Gate::div_int)
  {
    if ((mpz_sgn(op1) == 0) || (mpz_sgn(op2) == 0))
      mpz_set_ui(rop, 0);
    else
      mpz_mul(rop, op1, op2);
  }
  else
  { 
    mpz_powm_ui(rop, op2, -type, prime);
  }

  modIfNeeded(rop, prime);
}

void Gate::
setValue(const mpq_t value, const mpz_t prime)
{
  mpq_set(valq, value);
  convert_to_z(val, valq, prime);
}

void Gate::
setValue(const mpz_t value)
{
  mpq_set_z(valq, value);
  mpz_set(val, value);
}

void Gate::
setValue(int value)
{
  mpq_set_si(valq, value, 1);
  mpz_set_si(val, value);
}

void Gate::
mk_bin_gate(int op, int in1, int in2)
{
  this->type = op;
  this->in1 = in1;
  this->in2 = in2;
}

void Gate::
mk_pow_gate(int in, int exp)
{
  type = -exp;
  in1 = 0; // Unused
  in2 = in;
}

CircuitLayer::
CircuitLayer(int size)
  : length(0), gates(NULL), add_fn(zero), mul_fn(zero)
{
  resize(size);
}

CircuitLayer::
CircuitLayer(const CircuitLayer& other)
  : gates(NULL)
{
  (*this) = other;
}

CircuitLayer::
~CircuitLayer()
{
  if (gates)
    delete[] gates;
}

CircuitLayer& CircuitLayer::
operator= (const CircuitLayer& other)
{
  if (this != &other)
  {
    resize(other.size());
    add_fn = other.add_fn;
    mul_fn = other.mul_fn;

    memcpy(gates, other.gates, size() * sizeof(Gate*));
  }
  return *this;
}

void CircuitLayer::
resize(int size)
{
  if (size < 0)
    return;

  if (gates)
    delete[] gates;

  if (size > 0)
    gates = new Gate[size];
  else
    gates = NULL;

  length = size;
}

void CircuitLayer::
computeWirePredicates(mpz_t add_predr, mpz_t mul_predr, const MPZVector& rand, int inputLayerSize, const mpz_t prime) const
{
  const int mi = logSize();
  const int ni = size();
  const int mip1 = log2i(inputLayerSize);
  const int nip1 = inputLayerSize;

  bool addDone = false;
  bool mulDone = false;

  mpz_set_ui(add_predr, 0);
  mpz_set_ui(mul_predr, 0);

  if (add_fn)
  {
    add_fn(add_predr, rand.raw_vec(), mi, mip1, ni, nip1, prime);
    addDone = true;
  }

  if (mul_fn)
  {
    mul_fn(mul_predr, rand.raw_vec(), mi, mip1, ni, nip1, prime);
    mulDone = true;
  }

  if (addDone && mulDone)
    return;

  // Here, no function was provided, so we compute by brute force.
  MPZVector pChi(ni);
  MPZVector w1Chi(nip1);
  MPZVector w2Chi(nip1);

  MPZVector pR(mi);
  MPZVector w1R(mip1);
  MPZVector w2R(mip1);

  pR.copy(rand, 0, mi);
  w1R.copy(rand, mi, mip1);
  w2R.copy(rand, mi + mip1, mip1);

  computeChiAll(pChi,  pR,  prime);
  computeChiAll(w1Chi, w1R, prime);
  computeChiAll(w2Chi, w2R, prime);

  mpz_t tmp;
  mpz_init(tmp);
  for (int i = 0; i < size(); i++)
  {
    Gate& gate = gates[i];
    if (!addDone && gate.shouldBeTreatedAs(Gate::add))
    {
      mpz_mul(tmp, pChi[i], w1Chi[gate.in1]);
      modmult(tmp, tmp, w2Chi[gate.in2], prime);
      mpz_add(add_predr, add_predr, tmp);
    }

    if (!mulDone && gate.shouldBeTreatedAs(Gate::mul))
    {
      mpz_mul(tmp, pChi[i], w1Chi[gate.in1]);
      modmult(tmp, tmp, w2Chi[gate.in2], prime);
      mpz_add(mul_predr, mul_predr, tmp);
    }
  }
  mpz_clear(tmp);

  if (!addDone)
    mpz_mod(add_predr, add_predr, prime);

  if (!mulDone)
    mpz_mod(mul_predr, mul_predr, prime);
}

int CircuitLayer::
size() const
{
  return length;
}

int CircuitLayer::
logSize() const
{
  return log2i(size());
}

Gate& CircuitLayer::
operator[] (int idx)
{
  return gates[idx];
}

const Gate& CircuitLayer::
operator[] (int idx) const
{
  return gates[idx];
}

