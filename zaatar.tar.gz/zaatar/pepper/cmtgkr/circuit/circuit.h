#ifndef CODE_PEPPER_CMTGKR_CIRCUIT_CIRCUIT_H_
#define CODE_PEPPER_CMTGKR_CIRCUIT_CIRCUIT_H_

#include <gmp.h>
#include <vector>

#include "circuit_layer.h"

class Circuit
{
  private:
  int current_lvl;

  public:
  std::vector<CircuitLayer> layers;

  mpz_t prime;
  mpz_t psub1;

  public:
  Circuit();
  Circuit(const Circuit& other);
  ~Circuit();

  Circuit& operator= (const Circuit& other);

  // Accessors
  int depth();
  CircuitLayer& operator[] (int lvl);
  const CircuitLayer& operator[] (int lvl) const;
  CircuitLayer& getInputLayer();
  const CircuitLayer& getInputLayer() const;

  virtual void evaluate();

  void make_shell(int nlevels);

  // Create the next level. If no level is specified
  // create the current_lvl-1 level.
  void make_level(int size, mle_fn add_fn, mle_fn mul_fn);
  void make_level(int level, int size, mle_fn add_fn, mle_fn mul_fn);

  // TODO: Remove. Exists for backwards compatibility with current matmul impl.
  void make_level(int level, int size);

  // Returns the current gate level, as set by make_level().
  Gate* cgates(int shift = 0);
  int cgates_len(int shift = 0);
  CircuitLayer& clayer(int shift = 0);

  // Some common circuit patterns. Uses the current_lvl variable.
  void add_to_last_gate(int start, int end, int shift = 0);
  void mul_gates(int start, int end, int shift, int stride = 1);
  void add_gates(int start, int end, int shift, int stride = 1);

  void makeReduceLayer(int type, int start, int end);

  // Related to FLT
  void make_flt_lvl2(int start, int end);
  void make_flt_general(int start, int end, int bit_num);
  void make_flt_last(int start, int end);

  int get_prime_nbits();
  int get_flt_depth();

  void print();
};
#endif

