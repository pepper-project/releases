
#include <string>
#include <vector>
#include <limits>
#include <iostream>

#include "../circuit/circuit.h"
#include "../circuit/pws_circuit_parser.h"

using namespace std;

struct CountStat
{
  size_t total;
  size_t min;
  size_t max;
  size_t num;

  CountStat() :
    total(0),
    min(numeric_limits<size_t>::max()),
    max(0),
    num(0)
  { }
};

static void
print(const string str, int val)
{
  cout << str << ": " << val << endl;
}

int main(int argc, char** argv)
{
  if (argc < 1)
  {
    cerr << "Missing PWS filename." << endl;
    return 1;
  }

  // Hacky way to come up with a prime.
  Circuit c;

  PWSCircuitParser p;
  p.parse(argv[1], c.prime);

  CountStat numGates;
  int numIn = p.inGates.size();
  int numOut = p.outGates.size();
  int numMagic = p.magicGates.size();
  int numInConsts = p.inConstants.size();
  int numOutConsts = 0;

  const CircuitDescription& desc = p.circuitDesc;
  typedef CircuitDescription::const_iterator LayerIt;
  typedef LayerDescription::const_iterator GateIt;
  numGates.num = desc.size();
  for (LayerIt lit = desc.begin(); lit != desc.end(); ++lit)
  {
    const LayerDescription& layer = *lit;
    numGates.total += layer.size();
    numGates.min = min(numGates.min, layer.size());
    numGates.max = max(numGates.max, layer.size());
  }
  numGates.min = min(numGates.min, numGates.max);

  map<string, vector<int> >& outConsts = p.outConstants;
  map<string, vector<int> >::const_iterator it;
  for (it = outConsts.begin(); it != outConsts.end(); ++it)
  {
    const vector<int>& gateNums = it->second;
    numOutConsts += gateNums.size();
  }

  print("Number of Inputs", numIn + numMagic + numInConsts);
  print("  Number of Input Variables", numIn);
  print("  Number of Implicit Variables", numMagic);
  print("  Number of Input Constants", numInConsts);

  cout << endl;
  print("Number of Outputs", numOut + numOutConsts);
  print("  Number of Outputs Variables", numOut);
  print("  Number of Outputs Constants", numOutConsts);

  cout << endl;
  print("Total Gates", numGates.total);
  print("  Number of Layers", numGates.num);
  print("  Average Gates per Layer", (double) numGates.total / numGates.num);
  print("  Minimum Gates per Layer", numGates.min);
  print("  Maximum Gates per Layer", numGates.max);
}
