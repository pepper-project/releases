
#include "../cmtgkr_env.h"
#include "hamdist_circuit.h"

using namespace std;

HamdistCircuit::
HamdistCircuit(int dd, bool cmtPP)
  : d(dd), useCmtPP(cmtPP)
{ }

void HamdistCircuit::
construct()
{
  int n = powi(2, d);
  int flt_depth = get_flt_depth();

  make_shell(flt_depth + d + 3);

  //set up input level
  make_level(2*n + 2, zero, zero);

  addGatesFromLevel(inGates, depth() - 1, 0, 2*n);
  addGatesFromLevel(outGates, depth() - 1, 2*n, 2*n + 1);

  // First, add the two vector
  make_level(n + 2,
             hamdist_add_wrap<hamdist_sum_vec>,
             zero);
  add_gates(0, n, n);
  add_to_last_gate(n, cgates_len(), n);

  // Now, FLT the summed vector

  // Square level
  make_level(n + 2,
             hamdist_add_last_two,
             hamdist_flt_mul_lvl1);
  mul_gates(0, n, 0);
  add_to_last_gate(n, cgates_len());

  // Second level
  make_level(2*n + 2,
             hamdist_add_wrap<hamdist_flt_add_lvl2>,
             hamdist_flt_mul_lvl2);
  make_flt_lvl2(0, 2*n);
  add_to_last_gate(2*n, cgates_len(), -n);

  // All but last level.
  for (int i = 2; i < flt_depth - 1; i++)
  {
    if (mpz_tstbit(psub1, i))
      make_level(2*n + 2,
                 hamdist_add_wrap< hamdist_flt_add<1> >,
                 hamdist_flt_mul<1>);
    else
      make_level(2*n + 2,
                 hamdist_add_wrap< hamdist_flt_add<0> >,
                 hamdist_flt_mul<0>);

    make_flt_general(0, 2*n, i);
    add_to_last_gate(2*n, cgates_len());
  }

  // Last level
  make_level(n + 2,
             hamdist_add_last_two,
             hamdist_reduce);
  make_flt_last(0, n);
  add_to_last_gate(n, cgates_len(), n);

  // Add up all of the FLT-ed sums
  for (int i = d - 1; i > 0; i--)
  {
    make_level((1 << i) + 2,
               hamdist_add_wrap<hamdist_reduce>,
               zero);
    makeReduceLayer(Gate::add, 0, 1 << i);
    add_to_last_gate(1 << i, cgates_len(), 1 << i);
  }

  make_level(2, reduce, zero);
  makeReduceLayer(Gate::add, 0, 2);

  // Add the FLT-ed sum and the claimed result.
  make_level(1, reduce, zero);
  makeReduceLayer(Gate::add, 0, 1);
}

void HamdistCircuit::
evaluate()
{
  CircuitLayer& inLayer = getInputLayer();

  int n = getInputSize() / 2;
  int hamdist = 0;
  for (int i = 0; i < n; i++)
  {
    if (mpz_cmp(inLayer[i].val, inLayer[n + i].val) != 0)
      hamdist++;
  }
  inLayer[2*n].setValue(-hamdist);

  CMTCircuit::evaluate();
}

void HamdistCircuit::
initializeInputs(const MPQVector& op, const MPQVector& magic)
{
  CMTCircuit::initializeInputs(op, magic);
  CircuitLayer& inLayer = getInputLayer();

  // Set the constant 0 gate.
  inLayer[inLayer.size() - 1].setValue(0);
}

void HamdistCircuit::
initializeOutputs(const MPQVector& op)
{
  CMTCircuit::initializeOutputs(op);
  (*this)[0][0].setValue(0);
}

#if 0
size_t HamdistCircuit::
getInputSize() const
{
  return powi(2, d) * 2;
}

size_t HamdistCircuit::
getOutputSize() const
{
  return 1;
}

void HamdistCircuit::
getOutputs(MPZVector& rop) const
{
  const CircuitLayer& inLayer = getInputLayer();
  mpz_set(rop[0], inLayer[inLayer.size() - 2].val);
}
#endif

HamdistCircuitBuilder::
HamdistCircuitBuilder(int dd, bool cmtPP)
  : d(dd), useCmtPP(cmtPP)
{ }

HamdistCircuit* HamdistCircuitBuilder::
buildCircuit()
{
  HamdistCircuit* c = new HamdistCircuit(d, useCmtPP);
  c->construct();
  return c;
}

