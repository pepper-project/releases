#ifndef CODE_PEPPER_LIBV_ZCOMPUTATION_P_H_
#define CODE_PEPPER_LIBV_ZCOMPUTATION_P_H_

#include <libv/computation_p.h>
#include <libv/zpcp.h>

class ZComputationProver : public ComputationProver {
  protected:
    int n, n_prime, chi;

    poly_compressed *poly_A, *poly_B, *poly_C;
    int num_aij, num_bij, num_cij;
    int num_levels;

    mpz_t *poly_A_pv, *poly_B_pv, *poly_C_pv;
    mpz_t *eval_poly_A, *eval_poly_B, *eval_poly_C;
    mpz_t *set_v_z;
    vec_ZZ_p qap_roots, qap_roots2, set_v, single_root, v_prime;
    vec_ZZ_p z_poly_A_pv, z_poly_B_pv, z_poly_C_pv;
    ZZ_pX z_poly_A_c, z_poly_B_c, z_poly_C_c;
    ZZ_pX z_poly_P_c;
    ZZ_pX z_poly_P_c2;
    ZZ_pX z_poly_D_c, z_poly_H_c;
    ZZ_pX *poly_tree, *interpolation_tree;

#if NONINTERACTIVE == 1
    int size_answer_G1, size_answer_G2;

#if GGPR == 1
    // EK
    element_t *f1_g_Ai_query, *f1_g_Bi_query, *f1_h_Bi_query, *f1_g_Ci_query, *f2_g_t_i_query;
    element_t *f1_g_alhpa_Ai_query, *f1_g_alhpa_Bi_query, *f1_g_alhpa_Ci_query, *f2_g_alpha_t_i_query;

    element_t *f1_g_beta_a_Ai_query, *f1_g_beta_b_Bi_query, *f1_g_beta_c_Ci_query;

    int size_f1_g_Ai_query, size_f1_g_Bi_query, size_f1_h_Bi_query, size_f1_g_Ci_query, size_f2_g_t_i_query;
    int size_f1_g_alhpa_Ai_query, size_f1_g_alhpa_Bi_query, size_f1_g_alhpa_Ci_query, size_f2_g_alpha_t_i_query;
    int size_f1_g_beta_a_Ai_query, size_f1_g_beta_b_Bi_query, size_f1_g_beta_c_Ci_query;

    // VK
    element_t h;
    element_t h_alpha, h_gamma, h_beta_a_gamma, h_beta_b_gamma, h_beta_c_gamma;
    element_t g_D;
    element_t g_A0, h_B0, g_C0;
    element_t* g_Ai_io;
#else
    // EK
    element_t *f1_g_a_Ai_query, *f1_g_b_Bi_query, *f1_h_b_Bi_query, *f1_g_c_Ci_query;
    element_t *f1_g_a_alhpa_a_Ai_query, *f1_g_b_alhpa_b_Bi_query, *f1_g_c_alhpa_c_Ci_query;
    element_t *f2_h_t_i_query;
    element_t *f1_beta_query;

    int size_f1_g_a_Ai_query, size_f1_g_b_Bi_query, size_f1_h_b_Bi_query, size_f1_g_c_Ci_query;
    int size_f1_g_a_alhpa_a_Ai_query, size_f1_g_b_alhpa_b_Bi_query, size_f1_g_c_alhpa_c_Ci_query;
    int size_f2_h_t_i_query;
    int size_f1_beta_query;
#endif
    // answers
    element_t *f_ni_answers_G1, *f_ni_answers_G2;

    pairing_t pairing;
#endif

  private:
    void compute_set_v(int size);
    void build_poly_tree(int level, int j, int index);
    void zcomp_interpolate(int level, int j, int index, vec_ZZ_p *);
    void init_state(const char *);
    //void init_noninteractive_state();
    void find_cur_qlengths();
    virtual void interpret_constraints() = 0;
    void compute_assignment_vectors();
    void init_qap(const char*);

    void prover_computation_commitment();
    void prover_do_computation();
#if NONINTERACTIVE == 1
    void prover_noninteractive();
#if GGPR == 1
    void prover_noninteractive_GGPR();
#endif
#else
    void prover_interactive();
#endif
    void deduce_queries();

  public:
    ZComputationProver(int ph, int b_size, int num_r, int size_input,
                       int size_output, int num_variables, int num_constraints,
                       const char *name_prover, int size_aij, int size_bij,
                       int size_cij, const char *file_name_qap, const char *file_name_f1_index);
    ~ZComputationProver();
};

#endif  // CODE_PEPPER_LIBV_ZCOMPUTATION_P_H_
