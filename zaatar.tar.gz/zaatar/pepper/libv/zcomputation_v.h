#ifndef CODE_PEPPER_APPS_ZCOMPUTATION_V_H_
#define CODE_PEPPER_APPS_ZCOMPUTATION_V_H_

#include <libv/verifier.h>
#include <libv/input_creator.h>
#include <libv/zpcp.h>

#ifdef INTERFACE_MPI
#include <libv/zcomputation_p.h>
#endif

class ZComputationVerifier : public Verifier {
  protected:
    int chi, n;
    int n_prime;

    poly_compressed *poly_A, *poly_B, *poly_C;
    mpz_t *eval_poly_A, *eval_poly_B, *eval_poly_C;
    int num_aij, num_bij, num_cij;
    mpz_t A_tau, B_tau, C_tau;

    mpz_t *d_star, *A_tau_io, *B_tau_io, *C_tau_io;
    mpz_t *set_v;
#if NONINTERACTIVE == 0
    mpz_t *f1_q1, *f1_q2, *f1_q3, *f1_q4, *f1_commitment, *f1_consistency;
    mpz_t *f2_q1, *f2_q2, *f2_q3, *f2_q4, *f2_commitment, *f2_consistency;
    mpz_t temp, temp2, temp3, lhs, rhs;
    mpz_t *temp_arr, *temp_arr2;
#endif
    InputCreator* input_creator;

#if NONINTERACTIVE == 1
    int size_vk_G1, size_vk_G2;
    int size_answer_G1, size_answer_G2;

#if GGPR == 1
    // EK
    element_t *f1_g_Ai_query, *f1_g_Bi_query, *f1_h_Bi_query, *f1_g_Ci_query;
    element_t *f1_g_alhpa_Ai_query, *f1_g_alhpa_Bi_query, *f1_g_alhpa_Ci_query;
    element_t *f1_g_beta_a_Ai_query, *f1_g_beta_b_Bi_query, *f1_g_beta_c_Ci_query;
    element_t *f2_g_t_i_query, *f2_g_alpha_t_i_query;

    int size_f1_g_Ai_query, size_f1_g_Bi_query, size_f1_h_Bi_query, size_f1_g_Ci_query;
    int size_f1_g_alhpa_Ai_query, size_f1_g_alhpa_Bi_query, size_f1_g_alhpa_Ci_query;
    int size_f1_g_beta_a_Ai_query, size_f1_g_beta_b_Bi_query, size_f1_g_beta_c_Ci_query;
    int size_f2_g_t_i_query, size_f2_g_alpha_t_i_query;

    // VK
    element_t h;
    element_t h_alpha, h_gamma;
    element_t h_beta_a_gamma, h_beta_b_gamma, h_beta_c_gamma;
    element_t h_D;
    element_t g_A0, h_B0, g_C0;
    element_t* g_Ai_io;
#else
    // EK
    element_t *f1_g_a_Ai_query, *f1_g_b_Bi_query, *f1_h_b_Bi_query, *f1_g_c_Ci_query;
    element_t *f1_g_a_alhpa_a_Ai_query, *f1_g_b_alhpa_b_Bi_query, *f1_g_c_alhpa_c_Ci_query;
    element_t *f2_h_t_i_query;
    element_t *f1_beta_query;

    int size_f1_g_a_Ai_query, size_f1_g_b_Bi_query, size_f1_h_b_Bi_query, size_f1_g_c_Ci_query;
    int size_f1_g_a_alhpa_a_Ai_query, size_f1_g_b_alhpa_b_Bi_query, size_f1_g_c_alhpa_c_Ci_query;
    int size_f2_h_t_i_query;
    int size_f1_beta_query;

    // VK
    element_t h;
    element_t h_alpha_a, h_alpha_b, h_alpha_c;
    element_t h_gamma, h_beta_gamma;
    element_t g_c_D;
    element_t g_a_A0, h_b_B0, g_c_C0;
    element_t* g_a_Ai_io;
#endif
    // answers
    element_t *f_ni_answers_G1, *f_ni_answers_G2;

    pairing_t pairing;
#endif

    void init_state();
    void init_qap(const char *);
    void create_input();
#if NONINTERACTIVE == 1
    void create_noninteractive_query();
    void test_noninteractive_protocol(uint32_t beta);
    void prepare_noninteractive_answers(uint32_t beta);
    bool run_noninteractive_tests(uint32_t beta);
#if GGPR == 1
    void create_noninteractive_GGPR_query();
    bool run_noninteractive_GGPR_tests(uint32_t beta);
#endif
#else
    bool run_interactive_tests(uint32_t beta);
#endif
    void create_plain_queries();
    void populate_answers(mpz_t *f_answers, int rho, int num_repetitions, int beta);
    bool run_correction_and_circuit_tests(uint32_t beta);
  public:
    ZComputationVerifier(int batch, int reps, int ip_size, int out_size,
                         int num_vars, int num_cons, int optimize_answers, char *prover_url,
                         const char *name_prover, int, int, int, const char *file_name_qap);
    ~ZComputationVerifier();
};
#endif  // CODE_PEPPER_APPS_POLYEVAL_D2_V_H_
