package ccomp;

public class CDatabaseFunctions {
  public final static String GETDB_NAME = "getdb",
                             PUTDB_NAME = "putdb";
}
