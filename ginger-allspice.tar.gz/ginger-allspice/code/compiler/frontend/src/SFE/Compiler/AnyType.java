package SFE.Compiler;

/**
 * Represents a primitive type.
 */
public class AnyType extends Type {
  public int size() {
    throw new RuntimeException("Not implemented");
  }
}
