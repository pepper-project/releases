package SFE.Compiler;

/**
 * A marker interface for objects that shoud be coerced to a polynomial in order to be printed into a circuit.
 */
public interface OutputsToPolynomial {

}
