#!/bin/bash
mkdir -p /tmp/$USER/
rm -f /tmp/$USER/computation_state/*
