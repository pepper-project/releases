#include<libv/exogenous_checker.h>

ExogenousChecker::ExogenousChecker() {
}
