#include<libv/input_creator.h>

InputCreator::InputCreator() {
}

