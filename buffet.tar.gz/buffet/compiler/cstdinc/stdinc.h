#ifndef _STDINC_H
#define _STDINC_H   1

#include <stdio.h>
//#include <stdlib.h> Eventually...

#endif /* stdinc.h */
