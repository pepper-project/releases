// ParentType.java.
// Copyright (C) 2004 Naom Nisan, Ziv Balshai, Amir Levy.
// See full copyright license terms in file ../GPL.txt

package SFE.Compiler;

import java.util.Vector;


/**
 * this class represents types that contain other types such as structs and
 * arrays
 */
public abstract class ParentType extends Type {
}
