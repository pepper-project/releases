package SFE.Compiler;

public abstract class StatementWithOutputLine extends Statement {
  public abstract int getOutputLine();
}
