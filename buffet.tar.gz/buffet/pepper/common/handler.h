void register_handler();

