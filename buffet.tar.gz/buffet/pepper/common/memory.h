size_t getPeakRSS();

size_t getCurrentRSS();

