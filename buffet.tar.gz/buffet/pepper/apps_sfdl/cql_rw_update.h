#include "student_db.h"

struct In {hash_t db_handle;};
struct Out {hash_t db_handle;uint32_t path_depth; uint32_t tree_path;};
