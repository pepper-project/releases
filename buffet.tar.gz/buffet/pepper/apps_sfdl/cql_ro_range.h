#include "student_db.h"

struct In {hash_t db_handle;};
struct Out {Student_result_t result[5];};

