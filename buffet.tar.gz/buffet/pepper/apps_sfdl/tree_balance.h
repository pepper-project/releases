#include "student_db.h"

struct In {hash_t root;uint32_t path_depth; uint32_t tree_path;};
struct Out {hash_t root;};

