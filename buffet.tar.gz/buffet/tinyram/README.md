# Lajos #
## an independent vnTinyRAM implementation ##

This is an independent reimplementation of ideas from vnTinyRAM, as
described in the following papers:

Ben-Sasson, E., Chiesa, A., Genkin, D., and Tromer, E.
"Fast reductions from RAMs to delegatable succinct constraint
satisfaction problems: extended abstract." ITCS 2013.
http://dl.acm.org/citation.cfm?id=2422481
ePrint also available: https://eprint.iacr.org/2012/071

Ben-Sasson, E., Chiesa, A., Genkin, D., Tromer, E., and Virza, M.
"SNARKs for C: Verifying program executions succinctly and in zero
knowledge." CRYPTO 2013.
ePrint also available: https://eprint.iacr.org/2013/507

Ben-Sasson, E., Chiesa, A., Tromer, E., and Virza, M.
"Succinct non-interactive zero knowledge for a von Neumann
architecture." USENIX Security 2014.
ePrint also available: https://eprint.iacr.org/2013/879

Ben-Sasson, E., Chiesa, A., Genkin, D., Tromer, E., and Virza, M.
"TinyRAM Architecture Specification v0.991."
http://www.scipr-lab.org/system/files/TinyRAM-spec-0.991.pdf

Note that the processor architecture we implement is somewhat different
from what's described in the above architecture spec.

If you have pandoc, LaTeX, and some ancillary packages available on your
system, you can `make` in the doc directory for an overview of our
architecture and a guide for using the executables.

To actually run verified computations on this system, you will need
[Pantry](https://github.com/pepper-project/pantry) or
[Buffet](https://github.com/pepper-project/buffet). (Note that this
git project is a submodule of both.)
