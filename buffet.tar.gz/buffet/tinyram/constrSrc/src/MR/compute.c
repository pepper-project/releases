
    if ($swap) {
        $out0 = $in1;
        $out1 = $in0;
    } else {
        $out0 = $in0;
        $out1 = $in1;
    }

