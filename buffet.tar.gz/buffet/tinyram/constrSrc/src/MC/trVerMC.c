
#include "trVerMC.h"

void compute (struct In *input, struct Out *output) {
#include "compute.c"
}

