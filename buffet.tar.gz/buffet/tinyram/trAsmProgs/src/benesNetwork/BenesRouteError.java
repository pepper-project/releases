package benesNetwork;

public class BenesRouteError extends Exception {
    public BenesRouteError( String s ) { super(s); }
}
