package benesNetwork;

public class BenesSizeError extends Exception {
    public BenesSizeError( String s ) { super(s); }
}
