#ifndef COMPUTE_STRUCT_OUT
#define COMPUTE_STRUCT_OUT 1

struct Out {
    bool correct;
    int failStep;
};
#define COMPUTE_STRUCT_OUT_FAILSTEP

#endif //COMPUTE_STRUCT_OUT
