To compile an SFDL file to constraints, run SFE.Compiler.SFECompiler.

To compile a C file to constraints, 

./run/ccomp.sh <c source file> 

Source code used in this project:
-the Fairplay compiler, specifically the 2004 public snapshot.
