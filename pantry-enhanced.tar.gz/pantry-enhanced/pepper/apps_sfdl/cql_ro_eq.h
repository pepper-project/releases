#include "student_db.h"

struct In {Student_handle_t handle;};
struct Out {Student_result_t result[5];};


