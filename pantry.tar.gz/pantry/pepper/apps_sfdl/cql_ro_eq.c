#include <stdint.h>
#include <db.h>
#include <avl_tree.h>

#include "cql_ro_eq.h"

int compute(struct In *input, struct Out *output) {
  tree_t Class_index;

  Class_index.root = input->handle.Class_index;

  CQL("SELECT * FROM Student WHERE Class = 2009 LIMIT 5", output->result);
  /*{*/
    /*int i;*/
    /*Student_t tempStudent;*/
    /*tree_result_set_t tempResult;*/
    /*tree_find_eq(&(Class_index), (2009), &(tempResult));*/
    /*for (i = 0; i < MAX_TREE_RESULTS; i++) {*/
      /*if (i < tempResult.num_results) {*/
        /*hashget(&(tempStudent), &(tempResult.results[i].value));*/
        /*output->result[i].KEY = tempStudent.KEY;*/
        /*output->result[i].Major = tempStudent.Major;*/
        /*output->result[i].LName = tempStudent.LName;*/
        /*output->result[i].State = tempStudent.State;*/
        /*output->result[i].Age = tempStudent.Age;*/
        /*output->result[i].Class = tempStudent.Class;*/
        /*output->result[i].FName = tempStudent.FName;*/
        /*output->result[i].Credits = tempStudent.Credits;*/
        /*output->result[i].Average = tempStudent.Average;*/
        /*output->result[i].PhoneNum = tempStudent.PhoneNum;*/
      /*} else {*/
        /*output->result[i].KEY = 0;*/
        /*output->result[i].Major = 0;*/
        /*output->result[i].LName = 0;*/
        /*output->result[i].State = 0;*/
        /*output->result[i].Age = 0;*/
        /*output->result[i].Class = 0;*/
        /*output->result[i].FName = 0;*/
        /*output->result[i].Credits = 0;*/
        /*output->result[i].Average = 0;*/
        /*output->result[i].PhoneNum = 0;*/
      /*}*/
    /*}*/
  /*}*/
  return 0;
}
