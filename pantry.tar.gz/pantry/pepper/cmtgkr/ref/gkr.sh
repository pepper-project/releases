g++ -o gkr sequentialGKR.cc && ./gkr $@
